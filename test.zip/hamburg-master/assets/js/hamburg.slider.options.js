;( function( $ ){

	/**
	 * Regular slider.
	 *
	 * Can be added via text widget.
	 * @link http://flexslider.woothemes.com/index.html
	 *
	 */
	$( hamburg.slider.selector ).flexslider( hamburg.slider.options );

	/**
	 * Carousel slider.
	 *
	 * Dynamically responds to window width.
	 * @link http://flexslider.woothemes.com/dynamic-carousel-min-max.html
	 *
	 */
	var $window = $(window);

	$( hamburg.carousel.selector ).flexslider( hamburg.carousel.options );

	$window.resize(function() {
		var gridSize = getGridSize(),
			flexcarousel = $( hamburg.carousel.selector ).data('flexslider');

		if ( flexcarousel ) {
			flexcarousel.vars.minItems = gridSize;
			flexcarousel.vars.maxItems = gridSize;
		}
	});

})(jQuery);


function getGridSize() {
	return ((window.innerWidth || document.documentElement.clientWidth) < 600)
			? 2
			: ((window.innerWidth || document.documentElement.clientWidth) < 900)
				? 3
				: 5;
}

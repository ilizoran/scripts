;(function ( $ ) {

    // Holds all callbacks
    var callbacks = [];

    // Reference to the last fired callback
    var lastCallback = {};

    $.respond = function () {

        // Set fixed arity
        if ( arguments.length !== 3 ) {
            throw 'Wrong function signature used for $.respond';
        }

        var minWidth = arguments[ 0 ];
        var maxWidth = arguments[ 1 ];
        var callback = arguments[ 2 ];

        // Add callback to list
        callbacks.push( callback );

        // Initial boundary check
        _check_boundaries( minWidth, maxWidth, callback );

        // Bind resize handler
        $( window ).on( 'resize', _check_boundaries_diff( minWidth, maxWidth, callback ) );
    };

    // Cross browser window width
    function _get_viewport_width() {

        var viewportWidth;

        if ( typeof window.innerWidth !== 'undefined' ) {
            viewportWidth = window.innerWidth;
        } else if ( typeof document.documentElement !== 'undefined' &&
            typeof document.documentElement.clientWidth !== 'undefined' &&
            document.documentElement.clientWidth !== 0 ) {

            viewportWidth = document.documentElement.clientWidth;
        } else {
            viewportWidth = document.getElementsByTagName( 'body' )[ 0 ].clientWidth;
        }

        return viewportWidth;
    }

    // Check viewport boundaries and fire callback if it matches
    function _check_boundaries( minWidth, maxWidth, callback ) {

        var viewportWidth = _get_viewport_width();

        if ( viewportWidth > minWidth && viewportWidth < maxWidth ) {
            callback.call( {}, viewportWidth );
            lastCallback = callback;
        }
    }

    // Only check for boundaries and fire its callback if it hasn't
    //  been fired immediately before.
    function _check_boundaries_diff( minWidth, maxWidth, callback ) {
        return function() {
            if ( callback !== lastCallback ) {
                _check_boundaries( minWidth, maxWidth, callback );
            }
        };
    }
})( jQuery );
/**
 * Initiate prettyPhoto lightbox for WooCommerce pages.
 * Custom zoom for smaller viewports.
 *
 */

jQuery( function( $ ) {

	/**
	 * Abstraction
	 */

	var $images = $( 'a[data-rel^="prettyPhoto"]' );
	var $big_image_wrapper = $( '.woocommerce-main-image' );
	var $big_image = $( 'img', $big_image_wrapper );
	var $thumbnails = $( 'a', '.thumbnails' );
	var loading = false;

	// Configure the responses
	$.respond( 0, 767, _execute_small_state );
	$.respond( 767, 2000, _execute_normal_state );

	// Setup for small screens
	function _execute_small_state() {
		_unbind_images();
		_prevent_default_clicks();
		_bind_thumbnails();
	}

	// Setup for normal screens
	function _execute_normal_state() {
		_unbind_images();
		_bind_lightbox();
	}


	/**
	 * Core
	 */

	function _bind_lightbox() {
		$images.prettyPhoto({
			hook: 'data-rel',
			social_tools: false,
			theme: 'pp_woocommerce',
			horizontal_padding: 40,
			opacity: 0.9,
			deeplinking: false
		});
	}

	function _unbind_images() {
		$images.off();
	}

	function _prevent_default_clicks() {
		$images.on( 'click', _prevent_default );
	}

	function _prevent_default( event ) {
		event.preventDefault();
	}

	function _bind_thumbnails() {
		$thumbnails.on( 'click', _on_thumbnail_click );
	}

	function _on_thumbnail_click() {
		if ( loading ) {
			return false;
		}

		var $thumbnail = $( this );
		var interval;

		// Set loading state
		loading = true;

		// Hide big image
		$big_image
			.css( 'visibility', 'hidden' );

		// Create the loading animation
		interval = _create_loading_animation();

		// Load image and react when finished
		$big_image
			.attr( 'src', $thumbnail.attr( 'href' ) )
			.load( _image_loaded( interval ) );
	}

	function _create_loading_animation() {
		// Show loader
		var $loader = $( '<span>' )
			.addClass( 'hamburg-wc-main-image-loader' )
			.appendTo( $big_image_wrapper );

		// Animate loader
		_loading_frame.call( $loader );
		return window.setInterval( _loading_frame.bind( $loader ), 120 );
	}

	function _loading_frame() {
		$loader = this;

		// Loading animation
		switch ( $loader.html() ) {
			case '.':
				$loader.html( '..' );
				break;
			case '..':
				$loader.html( '...' );
				break;
			case '...':
				$loader.html( '.' );
				break;
			default:
				$loader.html( '.' );
		}
	}

	function _image_loaded( interval) {
		return function() {

			// Stop loader
			window.clearInterval( interval );
			$big_image.siblings( '.hamburg-wc-main-image-loader' ).remove();

			// Show image and unbind load event
			$big_image
				.css( 'visibility', 'visible' )
				.off( 'load' );

			// Free loading state
			loading = false;
		};
	}

});

;Function.prototype.bind=(function(){}).bind||function(b){if(typeof this!=="function"){throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");}function c(){}var a=[].slice,f=a.call(arguments,1),e=this,d=function(){return e.apply(this instanceof c?this:b||window,f.concat(a.call(arguments)));};c.prototype=this.prototype;d.prototype=new c();return d;};
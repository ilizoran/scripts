<?php
/**
 * Template Name: Full Width
 *
 * @package    Hamburg
 * @subpackage Templates
 */

/* Add translation for template name. */
$template_name = __( 'Full Width', 'theme_hamburg_textdomain' );

get_header();
?>
	<div class="site-main">
		<div class="row">
			<div id="primary" class="content-area full-width">
				<main id="content" class="site-content" role="main">
				<?php

				/* Loop starts here. */
				while ( have_posts() ) :

					the_post();

						/* Include a template part specific to the Post Format. */
						get_template_part( 'parts/content', 'page' );

						/* When comments are open or we have at least one comment, load the comment template. */
						if ( comments_open() || 0 !== (int) get_comments_number() )
							comments_template( '', TRUE );

				/* Loop ends here. */
				endwhile;

				?>
				</main>
			</div>
			<?php

			/* Upwards link. */
			get_template_part( 'parts/navigation', 'up' );
			?>
		</div>
	</div>

<?php

get_footer();
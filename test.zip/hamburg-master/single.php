<?php
/**
 * Render post type 'post'
 *
 * @package    Hamburg
 * @subpackage Templates
 */

get_header();
$full_width = ! is_active_sidebar( 'sidebar-1' ) ? ' full-width' : '';
?>
	<div class="site-main">
		<div class="row">
			<div id="primary" class="content-area<?php echo $full_width; ?>">
				<main id="content" class="site-content" role="main">
				<?php

				/* To add custom content at this place, use
				 * add_action( 'hamburg_single_before_content', '...' ) in a Child Theme.
				 */
				do_action( 'hamburg_single_before_content' );

				/* Loop starts here. */
				while ( have_posts() ) :

					the_post();

						/* FALSE === get_post_format() addresses any standard post. */
						if ( FALSE === get_post_format() )
							get_template_part( 'parts/content', 'single' );
						else
							get_template_part( 'parts/content', get_post_format() );

						/* When comments are open or we have at least one comment, load the comment template. */
						if ( comments_open() || 0 !== (int) get_comments_number() )
							comments_template( '', TRUE );

				/* Loop ends here. */
				endwhile;

				do_action( 'hamburg_single_after_content' );
				?>
				</main>
			</div>
			<?php

			/* We skip sidebar.php and load our sidebar templates directly. */
			 get_template_part( 'parts/widgets', 'secondary' );

			/* Upwards link. */
			get_template_part( 'parts/navigation', 'up' );
			?>
		</div>
	</div>

<?php

get_footer();
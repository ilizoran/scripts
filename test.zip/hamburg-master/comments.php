<?php
/**
 * Comments template.
 *
 * Added to single posts and pages and to custom post types with comment support.
 *
 * @package    Hamburg
 * @subpackage Templates
 */
if ( ! have_comments() && ! comments_open() )
	return;

/*
 * Make sure this does not display on ANY of the WooCommerce shop pages.
 * See woocommerce/single-product/review.php instead.
 */
if ( hamburg_is_woo() )
	return;

/* Enqueue comment reply script here, so it gets loaded only when it is needed. */
wp_enqueue_script( 'comment-reply' );
?>
	<div id="comments">
	<?php
	if ( post_password_required() ) :
	?>
		<p class="nopassword">
			<?php
			_e(
				'This post is password protected. Enter the password to view any comments.',
				'theme_hamburg_textdomain'
			);
			?>
		</p>
	</div>
	<?php

	/*
	 * Stop the rest of comments.php from being processed,
	 * but don't kill the script entirely -- we still have
	 * to fully load the template.
	 */
		return;
	endif; // post_password_required

	/* We have comments, but the comment form has been closed. */
	if ( ! comments_open()
		&& 0 !== (int) get_comments_number()
		&& post_type_supports( get_post_type(), 'comments' )
		) :
	?>
		<p class="nocomments"><?php _e( 'Comments are closed.', 'theme_hamburg_textdomain' ); ?></p>
	<?php

	endif;

	/* Print existing comments. */
	?>
		<h2 id="comments-title">
			<?php
			printf(
				_nx( 'One comment', '%1$s comments', get_comments_number(), 'Comments title', 'theme_hamburg_textdomain' ),
				number_format_i18n( get_comments_number() )
			);
			?>
		</h2>

		<?php

		/*
		 * Paginated comments.
		 *
		 * There's one more navigation like this below the comment list.
		 */
		if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
		?>
		<div id="comment-nav-above" class="comment-navigation">
			<h3 class="visually-hidden">
			<?php $comment_nav_text = __(
				'Comment navigation',
				'theme_hamburg_textdomain'
			);
			echo $comment_nav_text;
			?>
			</h3>
			<?php

			/* Comments pagination. */
			get_template_part( 'parts/pagination', 'comments' );
			?>
		</div>
		<?php

		/* This ends paginted comments. For now. */
		endif;

		/* Comment list starts here. */
		?>
		<ol class="commentlist">
			<?php

			/* Custom callback function for comments applied.
			 * Pingbacks geht a custom callback, too, further below.
			 */
			wp_list_comments(
				array(
					'type'	   => 'comment',
					'style'	   => 'ul',
					'callback' => hamburg()->get_config( 'comment_callback' )
				)
			);
			?>
		</ol>

		<?php

		/* Paginated comments. Again. */
		if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
		?>
		<div id="comment-nav-below" class="comment-navigation">
			<h3 class="visually-hidden">
			<?php echo $comment_nav_text; ?>
			</h3>
			<?php get_template_part( 'parts/pagination', 'comments' ); ?>
		</div>
		<?php

		/* This ends paginted comments. */
		endif;

		/**
		 * Pings with favicons.
		 *
		 * @link http://wordpress.stackexchange.com/a/96596/23011
		 */
		if ( $num = hamburg_count_pings() ) :
		?>
		<h2 id="pingbacks"><?php
			printf(
				_nx(
					'One pingback',
					'%d pingbacks',
					$num,
					'Pingbacks title',
					'theme_hamburg_textdomain'
					),
				$num
			);
		?></h2>
		<ol class="pinglist">
			<?php

			/* Custom callback applied adding pings as URLs with favicon. */
			wp_list_comments(
				array (
					'type'	   => 'pings',
					'style'	   => 'ul',
					'callback' => 'hamburg_list_pings_callback'
				)
			);
			?></ol>
		<?php
		endif;

	/* Finally, it is time for a neat comment form. */
	if ( comments_open() )
		comment_form();
	?>
</div>
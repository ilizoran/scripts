<?php
/**
 * The Site Footer Area.
 *
 * Site footer containing 3 widget areas
 * and a line of info about this theme.
 */
?>
	<footer class="site-footer">

		<?php

		/* Footer Widget Areas. */
		get_template_part( 'parts/widgets', 'footer' );
		?>

		<section id="colophon" role="contentinfo">
			<div class="row">
			<?php

			$hamburg_theme_data = wp_get_theme( get_template() );

			/* Use add_filter('hamburg_site_footer_info','...') to replace this with your own pragraph. */
			echo apply_filters( 'hamburg_site_footer_info',
					'<p class="site-info">&#169; ' . date( 'Y' ) . ' <span class="sep icon-beaker fa-flask"></span> ' .
					sprintf( _x( 'A %1$s Theme', 'Theme author link', 'theme_hamburg_textdomain' ),
						'<a href="' . $hamburg_theme_data->get('AuthorURI') . '" rel="designer">' .  $hamburg_theme_data->get('Author') . '</a>' ) .
					'</p>'
			);
			 ?>
			 </div>
		</section>
	</footer>

<?php wp_footer(); ?>

</body>
</html>

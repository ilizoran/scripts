# Hamburg #
**Stable tag:** 1.1.9

A responsive, flat-design, WooCommerce-ready WordPress-Theme.

## Compatibility
Hamburg 1.1.9 supports WooCommerce 2.3.5+ and WooCommerce German Market 2.4.11+.

## Description

The Free and Hanseatic City of Hamburg stands for a rich tradition of international seafaring and trade. Subtle elegance and fair values would make ​​the ‹Northern Beauty› an appropriate namesake for a modern shop theme, we thought. As the result here is a theme with native WooCommerce support, responsive layout, retina-ready icons and smart options.

### Features

* Retina-ready
* HTML5 & CSS3
* Supports common browsers and IE8+
* Built for WordPress 3.8+
* Ready for WooCommerce 2.1+
* WordPress Coding Standards
* Child-Theme-ready


## Installation

### Requirements

* WordPress 4.0
* PHP 5.3

### WooCommerce-ready

* WooCommerce 2.3.5+
* WooCommerce German Market 2.4.11+

### Installation

* Upload and install via Appearance->Themes-Upload or via FTP upload.
* Activate the theme.
* Define a custom menu and set it to one of the available menu locations.
* Everything below this point is eye-candy. ;)
* Make sure to check out the WordPress Customizer as well as Apperance->Header for further customization.
* Check out theme docs for detailed info on how to invoke a custom slider and make use of the available widget areas.
* For any customizations please do consider setting up a [child theme](https://github.com/inpsyde/hamburg-child-starter).

## Screenshots & Demo

Screenshots & Demo are available at [MarketPress](https://marketpress.com/product/hamburg/).


## Languages

* English (default)
* German

## Changelog

### 1.1.10
* Fixed a misleading user message about theme compatibility

### 1.1.9

* _Updated:_
   * minimum supported plugin versions to:
      - WooCommerce 2.3.5+
      - WGM 2.4.11+
   * template compatibility for WC 2.3.5 + WGM 2.4.11:
      - woocommerce/cart/cart-totals.php
      - woocommerce-german-market/second-checkout2.php


### 1.1.8

* _Updated:_
   * minimum requirements for Hamburg 1.1.8 to:
      - WordPress 4.0+
      - WooCommerce 2.3+
      - WGM 2.4.9
   * FontAwesome 4.0.3 font files and class support (3.0.2 still supported)
   * various WooCommerce-related styles to support WooCommerce 2.3+ templates
   * language files
* _Added:_
   * template compatibility for WooCommerce 2.3+
   * new filters for `hamburg_best_selling_products()`:
      - `hamburg_best_selling_products_meta_query`
      - `hamburg_best_selling_products`
* _Removed:_
   * global var `$woocommerce` from templates, replaced with `WC()`
   * various templates that had become obsolete with WooCommerce 2.3+
   * custom styles for quantity increment buttons, falling back to browser defaults.
   * WooCommerce style options from email-header.php template (had been removed in WooCommerce 2.3)
* _Fixed:_
   * missing button in cart template when WooCommerce German Market was not active
   * missing clearing of form state checkout form fields
   * multi-level menus on touch devices

### 1.1.7

* _Added:_
   * template compatibility for WooCommerce 2.2.10
* _Removed:_
   * functions and filters related to tax formatting with WooCommerce German Market that would break compatibility with other tax related plugins:
      - function `hamburg_wgm_format_vat_output()`
      - function `hamburg_wgm_tax_text()`
      - function `hamburg_wgm_tax_label()`
      - function `hamburg_wgm_shop_page_shipping()`
      - function `hamburg_wgm_text_including_tax()`
      - function `hamburg_wgm_price_with_tax_hint_loop()`
      - function `hamburg_wgm_add_mwst_rate_to_product_order_item()`
      - filter `hamburg_wgm_is_email_order_items_template`
      - filter `hamburg_wgm_format_vat_output`
      - filter `hamburg_wgm_loop_price_before`
      - filter `hamburg_wgm_loop_price_after`
      - filter `hamburg_wgm_price_loop`
      - filter `hamburg_wgm_additional_tax_notice`
* _Fixed:_
   * a broken text string for WooCommerce result counts above the product loop
   * a bug where the WooCommerce mini cart would display net instead of gross prices with a certain configuration

### 1.1.6

* _Added:_
   * added permalink to post date to ensure accessibility with empty post titles
* _Improved:_
   * touch navigation for nested menues on larger mobile devices (tablets)
* _Fixed:_
   * a bug where submenus would switch to transparent background in Chrome/OSX (possibly browser-related)
   * a bug where very long submenus would not be displayed in full length on mobile devices

### 1.1.5

* _Added:_
   * support for WooCommerce German Market 2.4.4
   * support for WooCommerce 2.2.6, updated WooCommerce templates
   * theme version as query argument to stylesheets
   * translation for theme description
   * missing styles for states select box during checkout
* _Improved:_
   * markup and styling of product catalogue (“link inside of link” issue with WooCommerce German Market)
   * markup and styling of product widgets
   * styling for digital products with WooCommerce German Market
* _Removed:_
   * various redundant CSS selectors
   * redundant call of shortcode_atts()
* _Fixed:_
   * a bug where product gallery images would open as files
   * order of price, tax and additional information in product catalogue with WooCommerce German Market
   * a bug where pagination would not work with default permalink scheme

### 1.1.4

* __Added:__
    * WooCommerce German Market: new action hook `wgm_email_after_item_name` to e-mail templates.
    * WooCommerce German Market: extra CSS styles for legally relevant links.
    * WooCommerce German Market: extra CSS styles for digital products with variations.
* __Removed:__
    * WooCommerce German Market: globally visible delivery costs link.
* __Fixed:__
    * duplicated variable `$textarea` from `hamburg_move_comment_textarea`.
    * media query value in jquery.prettyPhoto.init.js that would cause images to open as image files instead as gallery items.
    * minor CSS enhancements.

### 1.1.3

* __Added:__
    * double tap support to trigger submenus on larger touch screens.
    * exclusion of post type `products` from default WordPress searches.
    * new filter `hamburg_mini_cart_count_html`.
    * support for WooCommerce German Market 2.4.
* __Removed:__
    * call of deprecated `get_settings()`.
    * all appearances of `extract()`, following [WordPress core standards](https://core.trac.wordpress.org/ticket/22400).
* __Fixed:__
    * encoding of post titles for social sharing links.
    * default browser styles for `input[type="number"]`.
    * formerly cut-off select element in Chrome/Win.
    * formerly broken CSS when slider was set to `fade`.
    * various minor CSS enhancements.

### 1.1.2

* __Added:__
    * a filter for social sharing links.
    * formerly hidden labels to product variations.
    * various filters to modify how prices and taxes are displayed.
* __Removed:__
    * styling for select elements other than in widgets and shop archives (sorting), because of inconsistent browser interpretation.
* __Fixed:__
    * empty search result page.
    * a bug where WooCommerce’s var `$columns` would be devided by zero and throw a warning.
    * taxonomies in breadcrumbs.
    * styling of select elements.
    * color-schemes.
    * upper margin of `.added_to_cart` button.
    * price tag for free products.
    * various minor CSS improvements.
* __Updated:__
    * various template files for WooCommerce 2.1.7 and WooCommerce German Market 2.3.2.

### 1.1.1

* Added missing :hover color for CSS class .special
* *[WooCommerce]* Fixed clearing in product loop
* *[WooCommerce German Market]* Added missing styles for KUR (small business regulation)

### 1.1

* added responsiveness for Secondary Meta Menu
* updated Modernizr vendor script
* updated FlexSlider vendor script

#### WooCommerce-related

* ensured general compatibility with WooCommerce 2.1+ and WooCommerce German Market 2.3.1+
* added styling for new WooCommerce feature "price suffix", including prices wrapped inside
* redesigned styling of product prices, including sales, variable products and variable products on sale
* added styling to e-mail header template according to the active color-scheme
* added javascript to responsively replace prettyPhoto lightbox for product images
* added filter hamburg_enqueue_style_google_fonts
* added filter hamburg_wc_cart_crosssells_orderby
* added filter hamburg_wc_product_upsells_posts_per_page
* added filter hamburg_wc_get_price_html
* removed function hamburg_wc_styles
* removed function hamburg_enqueue_stuff
* removed function hamburg_wgm_price_with_tax_hint_loop
* removed function hamburg_wgm_enqueue_scripts


### 1.0.2

* Removed front-page.php (backwards-compatible).
* Removed deprecated way of loading jQuery in the footer.
* Removed RSS icon from RSS widget as it did not link to a feed, but to a post.
* Corrected typo in inc/custom-header.php.
* Corrected top 10 products query for carousel.
* Corrected pagination on front page.
* Implemented Modernizr 2.7.1.
* *[WooCommerce German Market]* Improved display of tax and delivery notes link on product archive page.
* *[WooCommerce German Market]* Styled price per unit.
* *[wpSEO]* Added support for wpSEO plugin in `<title>` and meta tags.

### 1.0.1

* Fixed product loop "from" position for variable products.
* Fixed attachment image navigation.
* Fixed term archive titles and removed duplicated archive description.
* Fixed webkit appearance of form elements (affected iOS browsers before).
* Added translation support to breadcrumbs.
* Updated language files.
* Fixed CSS for prices in product loop.
* Added translation for page template names.
* Fixed missing price in single product view when WooCommerce German Market was not active. (headbang)
* Fixed CSS for shipping class radio buttons on checkout.
* Added CSS for WooCommerce German Market’s new feature “Kleinunternehmerregelung”.
* Various minor CSS fixes.
* Bumped version number to 1.0.1.

### 1.0

* Initial Release

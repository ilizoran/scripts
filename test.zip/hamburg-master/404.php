<?php
/**
 * 404 Template
 *
 * @package    Hamburg
 * @subpackage Templates
 */

get_header();
?>
	<div class="site-main">
		<div class="row">
			<div id="primary" class="content-area full-width">
				<main id="content" class="site-content" role="main">
					<?php get_template_part( 'parts/content', 'no-results' ); ?>
				</main>
			</div>
		</div>
	</div>
<?php

get_footer();
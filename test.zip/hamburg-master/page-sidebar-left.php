<?php
/**
 * Template Name: Sidebar Left
 *
 * @package    Hamburg
 * @subpackage Templates
 */

/* Add translation for template name. */
$template_name = __( 'Sidebar Left', 'theme_hamburg_textdomain' );

get_header();
?>
	<div class="site-main sidebar-left">
		<div class="row">
			<div id="primary" class="content-area<?php echo hamburg_content_area_class(); ?>">
				<main id="content" class="site-content" role="main">
				<?php

				/* Loop starts here. */
				while ( have_posts() ) :

					the_post();

						/* Include a template part specific to pages. */
						get_template_part( 'parts/content', 'page' );

						/* When comments are open or we have at least one comment, load the comment template. */
						if ( comments_open() || 0 !== (int) get_comments_number() )
							comments_template( '', TRUE );

				/* Loop ends here. */
				endwhile;

				?>
				</main>
			</div>
			<?php

			/* We skip sidebar.php and load our sidebar templates directly. */
			 get_template_part( 'parts/widgets', 'secondary' );

			/* Upwards link. */
			get_template_part( 'parts/navigation', 'up' );
			?>
		</div>
	</div>

<?php

get_footer();
<?php
/**
 * Add functions to after_setup_theme() hook seperately
 * in order to be able to remove them later on.
 */
add_action( 'after_setup_theme', 'hamburg_post_thumbnails' );
add_action( 'after_setup_theme', 'hamburg_editor_style' );
add_action( 'after_setup_theme', 'hamburg_menus' );
add_action( 'after_setup_theme', 'hamburg_add_custom_background' );
add_action( 'admin_notices',	 'hamburg_compatibility_notice' );

add_filter( 'script_loader_src', 'hamburg_remove_query_args', 15, 2 );
add_filter( 'style_loader_src',  'hamburg_remove_query_args', 15, 2 );

if ( ! is_admin() ) {
	add_action( 'after_setup_theme',  'hamburg_comments' );
	add_action( 'wp_enqueue_scripts', 'hamburg_enqueue_style_google_fonts' );
	add_action( 'wp_enqueue_scripts', 'hamburg_enqueue_style_icon_font' );
	add_action( 'wp_enqueue_scripts', 'hamburg_enqueue_style_ie' );
	add_action( 'wp_enqueue_scripts', 'hamburg_enqueue_style_style' );
	add_action( 'wp_enqueue_scripts', 'hamburg_enqueue_script_modernizr', 1 );
	add_action( 'wp_enqueue_scripts', 'hamburg_enqueue_script_jqueryselectionBox' );
	add_action( 'wp_enqueue_scripts', 'hamburg_enqueue_script_hamburg' );
	add_filter( 'style_loader_tag',   'hamburg_style_loader_tag',  10, 2 );
}


/**
 * Load translation.
 *
 * @wp-hook template_redirect
 * @return  boolean
 */
function hamburg_load_textdomain() {

	return load_theme_textdomain(
		'theme_hamburg_textdomain',
		get_template_directory() . '/languages'
	);
}

/**
 * Add theme support for post images.
 *
 * @wp-hook after_setup_theme
 * @return  void
 */
function hamburg_post_thumbnails() {
	global $content_width;

	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( $content_width, 9999 );
}

/**
 * Add theme support for custom menus.
 *
 * @wp-hook after_setup_theme
 * @return  void
 */
function hamburg_menus() {

	register_nav_menus(
		array(
			'primary'		 => __( 'Primary Site Menu',   'theme_hamburg_textdomain' ),
			'secondary'		 => __( 'Secondary Site Menu', 'theme_hamburg_textdomain' ),
			'meta-primary'	 => __( 'Primary Meta Menu',   'theme_hamburg_textdomain' ),
			'meta-secondary' => __( 'Secondary Meta Menu', 'theme_hamburg_textdomain' )
		)
	);
}

/**
 * Add theme support for editor styles.
 *
 * @wp-hook after_setup_theme
 * @return  void
 */
function hamburg_editor_style() {

	add_editor_style( 'assets/css/editor-style.css' );
}

/**
 * Add custom comment functions.
 *
 * See the documentation inside the file for further options.
 *
 * @wp-hook after_setup_theme
 * @return  void
 */
function hamburg_comments() {

	require_once 'comment.php';
}

/**
 * Remove file version query arguments from script/stylesheet URLs.
 *
 * Leaves http://fonts.googleapis.com/css?family=MyFont untouched.
 *
 * @link    http://wordpress.stackexchange.com/a/96325/
 * @link    http://wordpress.stackexchange.com/q/99842/
 * @wp-hook script_loader_src
 * @wp-hook style_loader_src
 * @param   string $url
 * @param   string $handle
 * @return  string
 */
function hamburg_remove_query_args( $url, $handle ) {

	$host = parse_url( $url, PHP_URL_HOST );

	if ( 'fonts.googleapis.com' === $host )
		return remove_query_arg( 'ver', $url );

	return $url;
}


/**
 * Enclose stylesheet element with IE conditional.
 *
 * @return string
 */
function hamburg_style_loader_tag( $tag, $handle ) {

	if ( 'style' === $handle )
		return "<!--[if gt IE 8]><!-->\n$tag<!--<![endif]-->\n";

	return $tag;
}

/**
 * Responsive, focusable slider and carousel.
 *
 * @link https://github.com/woothemes/Flexslider
 * @return void
 */
function hamburg_slider_init() {

	wp_enqueue_script(
		'flexslider',
		get_template_directory_uri() . '/assets/js/jquery.flexslider' . hamburg_min_suffix() . '.js',
		array( 'jquery' ),
		NULL
	);

	wp_enqueue_script(
		'hamburg-slider-options',
		get_template_directory_uri() . '/assets/js/hamburg.slider.options' . hamburg_min_suffix() . '.js',
		array( 'flexslider' ),
		NULL
	);

	$slider_args = array(
			'slider' => array(
				'selector'      => '.flex-slider',
				'options'       => array(
					'animation'         => 'slide',
					'animationLoop'     => TRUE,
					'multipleKeyboard'  => TRUE,
					'nextText'          => __( 'Next',		'theme_hamburg_textdomain' ),
					'prevText'          => __( 'Previous',	'theme_hamburg_textdomain' ),
					'slideshow'         => FALSE,
				)
			),
			'carousel' => array(
				'selector'   => '.flex-carousel',
				'options'    => array(
					'animation'         => 'slide',
					'animationLoop'     => FALSE,
					'controlNav'        => FALSE,
					/*
					If you change itemWidth, also change max-height for selector
					.flex-carousel .flex-item.has-featured-image.portrait .entry-image img!
					*/
					'itemWidth'         => 210,
					'itemMargin'        => 5,
					'minItems'          => "getGridSize()",
					'maxItems'          => "getGridSize()",
					'multipleKeyboard'  => TRUE,
					'nextText'          => __( 'Next',		'theme_hamburg_textdomain' ),
					'prevText'          => __( 'Previous',	'theme_hamburg_textdomain' ),
					'slideshow'         => FALSE,
				)
			)
		);

	wp_localize_script(
		'hamburg-slider-options',
		'hamburg',
		apply_filters( 'hamburg_slider_args', $slider_args )
	);
}

/**
 * Suffix for minified script/stylesheet versions.
 *
 * Adds a conditional ".min" suffix to the file name
 * when WP_DEBUG is NOT set to TRUE.
 *
 * @return string
 */
function hamburg_min_suffix() {

	return defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
}

/**
 * Suffix for extended WooCommerce stylesheets.
 *
 * Adds a conditional .plus.woo suffix to the file name
 * when WooCommerce is active.
 *
 * @return string
 */
function hamburg_woo_suffix() {

	return class_exists( 'WooCommerce' ) ? '.plus.woo' : '';
}

/**
 * Get theme version
 *
 * @return string
 */
function hamburg_theme_version() {

	$theme_data = wp_get_theme();
	$version    = $theme_data->Version;

	return $version;
}

/**
 * Google fonts stylesheet.
 *
 * To customize the font families loaded use
 * add_filter( 'hamburg_enqueue_style_google_fonts', 'your_font_function');
 * in your child theme.
 *
 * @wp-hook wp_enqueue_scripts
 * @return  void
 */
function hamburg_enqueue_style_google_fonts() {

	$protocol	= is_ssl() ? 'https' : 'http';
	$fonts		= apply_filters(
					'hamburg_enqueue_style_google_fonts',
					'Open+Sans:400,300,700|Roboto+Condensed:400,300,700'
					);
	$query_args = array( 'family' => $fonts );

	wp_enqueue_style(
		'webfonts',
		add_query_arg( $query_args, "$protocol://fonts.googleapis.com/css" ),
		array(),
		NULL
	);
}

/**
 * IE8 and below legacy stylesheet.
 *
 * @wp-hook wp_enqueue_scripts
 * @return  void
 */
function hamburg_enqueue_style_ie() {
	global $wp_styles;

	wp_enqueue_style(
		'lte8',
		get_template_directory_uri() . '/assets/css/style' . hamburg_woo_suffix() . '.ie' . hamburg_min_suffix() . '.css',
		array(),
		hamburg_theme_version()
	);

	$wp_styles->add_data( 'lte8', 'conditional', 'lte IE 8' );
}

/**
 * Main theme stylesheet.
 *
 * @wp-hook wp_enqueue_scripts
 * @return void
 */
function hamburg_enqueue_style_style() {

	wp_enqueue_style(
		'style',
		get_template_directory_uri() . '/style' . hamburg_woo_suffix() . hamburg_min_suffix() . '.css',
		array(),
		hamburg_theme_version()
	);
}

/**
 * FontAwesome Icon Font.
 *
 * @wp-hook wp_enqueue_scripts
 * @return void
 */
function hamburg_enqueue_style_icon_font() {

	// Latest FontAwesome version shipped with Hamburg.
	$fa_version     = '4.3.0';

	// Optional filter for legacy version.
	$version        = apply_filters( 'hamburg_icon_font_version', $fa_version );
	$fonts_dir_uri  = trailingslashit( get_template_directory_uri() . '/assets/fonts' );

	$fa = array(
		'fresh'  => 'font-awesome/css/font-awesome' . hamburg_min_suffix() . '.css',
		'legacy' => 'fontawesome-3.0.2' . hamburg_min_suffix() . '.css',
	);

	// Default: latest version.
	$stylesheet = $fa[ 'fresh' ];

	if ( $version !== $fa_version ) {
		add_filter( 'body_class', 'hamburg_legacy_icon_font_body_class' );
		$stylesheet = $fa[ 'legacy' ];
	}

	$stylesheet_uri = $fonts_dir_uri . $stylesheet;

	wp_enqueue_style(
		'fontawesome',
		$stylesheet_uri,
		array(),
		$version
	);
}

/**
 * Add body class when legacy icon font is loaded.
 *
 * @param mixed $classes
 * @return array
 */
function hamburg_legacy_icon_font_body_class( $classes ) {
	$classes[] = 'fa-legacy';
	return $classes;
}


/**
 * Modernizr.
 *
 * Custom modernizr build, adds classes to <html>
 * displaying browser support for CSS3 and HTML5 features.
 *
 * @wp-hook wp_enqueue_scripts
 * @return  void
 */
function hamburg_enqueue_script_modernizr() {

	wp_enqueue_script(
		'modernizr',
		get_template_directory_uri() . '/assets/js/modernizr' . hamburg_min_suffix() . '.js',
		array(),
		NULL
	);
}

/**
 * Selection Box.
 *
 * @wp-hook wp_enqueue_scripts
 * @return  void
 */
function hamburg_enqueue_script_jqueryselectionBox() {

	wp_enqueue_script(
		'jquery-selectionBox-js',
		get_template_directory_uri() . '/assets/js/jquery.selectionBox/jquery.selectionBox' . hamburg_min_suffix() . '.js',
		array( 'jquery' ),
		'0.1.0',
		TRUE
	);
}

/**
 * Custom theme javascript.
 *
 * @wp-hook wp_enqueue_scripts
 * @return  void
 */
function hamburg_enqueue_script_hamburg() {

	wp_enqueue_script(
		'hamburg-js',
		get_template_directory_uri() . '/assets/js/hamburg' . hamburg_min_suffix() . '.js',
		array( 'jquery', 'jquery-selectionBox-js' ),
		'1.1.2',
		TRUE
	);
}

/**
 * Check if WooCommerce is enabled.
 *
 * @return bool
 */
function hamburg_is_wc() {
	return class_exists( 'Woocommerce' ) ? TRUE : FALSE;
}

/**
 * Check if WooCommerce German Market is enabled.
 *
 * @return bool
 */
function hamburg_is_wgm() {
	return class_exists( 'WGM_Template' ) ? TRUE : FALSE;
}

/**
 * Add default value for custom background.
 *
 * @access public
 * @return void
 */
function hamburg_add_custom_background() {

	add_theme_support( 'custom-background', array( 'default-color' => '#f6f6f6' ) );
}

/**
 * Check for theme compatibility.
 *
 * Requirements:
 * PHP 5.3+
 * WordPress 3.7+
 * If WooCommerce, then 2.1+.
 * If WooCommerce German Market, then 2.3+.
 *
 * @return bool
 */
function hamburg_is_compatible() {

	global $woocommerce;

	/* values hard-coded in hamburg_compatibility_notice()!!! */
	if (
		version_compare( PHP_VERSION, '5.2', '<' )
		|| version_compare( get_bloginfo('version'), '4.0', '<' )
		|| ( $woocommerce && version_compare( @$woocommerce->version, '2.3.5', '<' ) )
 		|| (
			hamburg_is_wgm() && method_exists( 'Woocommerce_German_Market', 'get_version' )
			&& version_compare( Woocommerce_German_Market::get_version(), '2.4.11', '<' )
			)
		) {
			return FALSE;
	}

	return TRUE;
}

/**
 * Theme compatibility warning.
 *
 * Display a warning if hamburg_is_compatible() returns false.
 * @return string
 */
function hamburg_compatibility_notice() {

	if ( hamburg_is_compatible() === TRUE )
		return;

	$styles = "style='color:#dd3d36;font-size:2em;line-height:0.5;width:1em;'";
	$heading = sprintf(
					__( '%s Theme Compatibility Issue', 'theme_hamburg_textdomain' ),
					"<span class='dashicons dashicons-no' $styles></span>"
				);
	$msg1 = sprintf(
				__( '<strong>It looks like the active theme, %1$s, has detected a compatibility issue.</strong>', 'theme_hamburg_textdomain' ),
				'<a href="http://marketpress.com/product/hamburg/" target="_blank">Hamburg</a>'
			);
	$msg2 = sprintf(
				__( 'In its current version, %1$s requires at least <strong>%2$s</strong> and <strong>%3$s</strong>. Additionally, %4$s and %5$s are supported.', 'theme_hamburg_textdomain' ),
				'Hamburg',
				'PHP 5.2+',
				'WordPress 4.0+',
				'<a href="http://wordpress.org/plugins/woocommerce/" target="_blank">WooCommerce 2.3.5+</a>',
				'<a href="http://marketpress.de/product/woocommerce-german-market/" target="_blank">WooCommerce German Market 2.4.11+</a>'
			);
	$msg3 = sprintf(
				__( 'Please feel free to contact the %1$s support team for further advice.', 'theme_hamburg_textdomain' ),
				'<a href="http://marketpress.com/" target="_blank">MarketPress</a>'
			);

	printf(
		'<div class="error"><h3>%1$s</h3><p>%2$s</p><p>%3$s</p><p>%4$s</p></div>',
		$heading, $msg1, $msg2, $msg3
	);
}

/**
 * Configure auto-updater.
 *
 * @wp-hook wp_loaded
 * @return  void
 */
function hamburg_auto_updater() {

	if ( ! class_exists( 'Inpsyde_Autoupdate' ) )
		require_once 'inpsyde-theme-base/class-Inpsyde_Autoupdate.php';

	$messages = array (
		'license_deleted' => array (
			'text'  => __( 'License key has been deleted.', 'theme_hamburg_textdomain' ),
			'class' => 'updated'
		),
		'marketpress_product_activated' => array (
			'text'  => __( 'License activated successfully.', 'theme_hamburg_textdomain' ),
			'class' => 'updated'
		),
		'marketpress_wrong_key' => array (
			'text'  => sprintf( '<strong>%s</strong> ', __( 'License cannot be activated.', 'theme_hamburg_textdomain' ) ) . __( 'The license key you have entered is not correct.', 'theme_hamburg_textdomain' ),
			'class' => 'error'
		),
		'marketpress_wrong_url' => array (
			'text'  => sprintf( '<strong>%s</strong> ', __( 'License cannot be activated.', 'theme_hamburg_textdomain' ) ) . sprintf( __( 'You have reached the limit of URLs included in your license. Please update your license at %s.', 'theme_hamburg_textdomain' ), '<a href="http://marketpress.com/" target="_blank">MarketPress</a>' ),
			'class' => 'error'
		),
		'marketpress_wrong_anything' => array (
			'text'  => sprintf( '<strong>%s</strong> ', __( 'License cannot be activated.', 'theme_hamburg_textdomain' ) ) . sprintf( __( 'Something went wrong. Please try again later or contact the support staff at %s.', 'theme_hamburg_textdomain' ), '<a href="http://marketpress.com/support/" target="_blank">MarketPress</a>' ),
			'class' => 'error'
		),
		'marketpress_wrong_license' => array (
			'text'  => sprintf( '<strong>%s</strong> ', __( 'License cannot be activated.', 'theme_hamburg_textdomain' ) ) . sprintf( __( 'Your license does not appear to be valid for this theme. Please update your license at %s.', 'theme_hamburg_textdomain' ), '<a href="http://marketpress.com/" target="_blank">MarketPress</a>' ),
			'class' => 'error'
		),
		'activate' => array (
			'text' => __( 'Activate', 'theme_hamburg_textdomain' )
		),
		'license_invalid' => array (
			'text'  => __( 'Heads up! Your license for theme Hamburg is not valid.', 'theme_hamburg_textdomain' ),
		),
		'license_valid' => array (
			'text'  => __( 'All is well. Your license for theme Hamburg is valid.', 'theme_hamburg_textdomain' ),
		),
		'auto_update_disabled' => array (
			'text'  => __( 'Update messages for this theme have been deactivated.', 'theme_hamburg_textdomain' ),
		),
		'enter_valid_key' => array (
			'text'  => __( 'Please enter a valid license key.', 'theme_hamburg_textdomain' ),
		),
		'renew_key' => array (
			'text'  => __( 'You can renew the key at your MarketPress dashboard.', 'theme_hamburg_textdomain' ),
		),
		'enter_new_key' => array (
			'text'  => __( 'You can enter a new key in the form below.', 'theme_hamburg_textdomain' ),
		),
		'delete_key' => array (
			'text'  => __( 'Delete key.', 'theme_hamburg_textdomain' ),
		),
		'license_key' => array (
			'text'  => __( 'License key:', 'theme_hamburg_textdomain' ),
		)
	);

	$theme_data = (object) get_file_data(
		dirname( dirname(__FILE__) ) . '/style.css',
		array (
			'product' => 'Theme Name',
			'version' => 'Version'
		)
	);
	new Inpsyde_Autoupdate( $theme_data, $messages );
}

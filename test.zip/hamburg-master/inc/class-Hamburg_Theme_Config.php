<?php # -*- coding: utf-8 -*-
class Hamburg_Theme_Config extends Inpsyde_Property_List {

	protected $properties = array (
		'use_default_gallery_style' => FALSE,
		'element_html_id'           => 'hh',
		'excerpt_length'            => 20,
		'content_width'             => 745,
		'automatic_feed_links'      => TRUE,
		'fill_empty_wp_title'       => TRUE,
		'show_meta_charset'         => FALSE,
		'comment_callback'          => 'hamburg_comment',
		'custom_header'             => TRUE
	);
}
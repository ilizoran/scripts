<?php # -*- coding: utf-8 -*-
/**
 * Set up theme customizations.
 *
 * @author toscho
 * @since 2013.08.16
 */
class Hamburg_Customize {

	protected $default_color_scheme = 'blue';

	/**
	 * Constructor.
	 *
	 * Register callbacks
	 *
	 * @wp-hook init
	 */
	public function __construct() {

		add_action( 'customize_register', array ( $this, 'run_customizers' ) );
		add_filter( 'body_class', array ( $this, 'colorscheme_body_class' ) );
		add_filter( 'hamburg_ms_tile_color', array ( $this, 'ms_tile_color' ) );
	}

	/**
	 * Load classes and register sections.
	 *
	 * @wp-hook customize_register
	 * @param   WP_Customize_Manager $wp_customize
	 * @return  void
	 */
	public function run_customizers( WP_Customize_Manager $wp_customize ) {

		$this->load_classes();
		$this->setup_logo( $wp_customize );
		$this->setup_color_schemes( $wp_customize );
		$this->setup_contact_data( $wp_customize );
	}

	/**
	 * Logo section.
	 *
	 * @wp-hook customize_register
	 * @param   WP_Customize_Manager $wp_customize
	 * @return  void
	 */
	protected function setup_logo( WP_Customize_Manager $wp_customize ) {

		$section = 'logo_section';
		$key     = 'logo_url';
		$title   = __( 'Logo', 'theme_hamburg_textdomain' );

		$wp_customize->add_section(
			$section,
			array (
				'title'    => $title,
				'priority' => 5,
			)
		);

		$wp_customize->add_setting(
			$key,
			array (
				'default' => ''
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'logo',
				array (
					'label'    => $title,
					'section'  => $section,
					'settings' => $key,
					'get_url'  => array ( $this, 'customizer_logo_src' )

				)
			)
		);
	}
	/**
	 * Contact data section.
	 *
	 * @wp-hook customize_register
	 * @param   WP_Customize_Manager $wp_customize
	 * @return  void
	 */
	protected function setup_contact_data( WP_Customize_Manager $wp_customize ) {

		$section = 'contact_section';
		$key     = 'contact_text';
		$title   = __( 'Contact data', 'theme_hamburg_textdomain' );

		$wp_customize->add_section(
			$section,
			array (
				'title'    => $title,
				'priority' => 5,
			)
		);

		$wp_customize->add_setting(
			$key,
			array (
				'default'        => ''
			)
		);

		$wp_customize->add_control(
			new Inpsyde_Customizer_Textarea(
				$wp_customize,
				'contact_text',
				array (
					'label'    => $title,
					'section'  => $section,
					'settings' => $key,
					'placeholder' => __(
						'First line: phone number, second line email.',
						'theme_hamburg_textdomain'
					)

				)
			)
		);
	}

	/**
	 * Color scheme section.
	 *
	 * @wp-hook customize_register
	 * @param   WP_Customize_Manager $wp_customize
	 * @return  void
	 */
	protected function setup_color_schemes( WP_Customize_Manager $wp_customize ) {

		$schemes = $this->get_color_schemes();
		$section = 'color_scheme_section';
		$key     = 'color_scheme';
		$title   = __( 'Color scheme', 'theme_hamburg_textdomain' );

		$wp_customize->add_section(
			$section,
			array (
				'title'    => $title,
				'priority' => 5,
			)
		);

		$wp_customize->add_setting(
			$key,
			array (
				'default'        => $this->default_color_scheme
			)
		);

		$wp_customize->add_control(
			new Inpsyde_Customizer_Color_Scheme(
				$wp_customize,
				'color_scheme',
				array (
					'label'    => $title,
					'section'  => $section,
					'settings' => $key,
					'schemes'  => $schemes,
					'default'  => 'blue'
				)
			)
		);
	}

	/**
	 * Load required classes for the customizer.
	 *
	 * @wp-hook customize_register
	 * @return  void
	 */
	protected function load_classes() {

		$base = get_template_directory() . '/inc/inpsyde-theme-base';
		require_once "$base/class-Inpsyde_Customizer_Textarea.php";
		require_once "$base/class-Inpsyde_Customizer_Color_Scheme.php";
	}

	/**
	 * Get color schemes.
	 *
	 * @return array
	 */
	protected function get_color_schemes() {

		$schemes = array (
			'blue' => array (
				'background' => '2CC2E1',
				'foreground' => 'fff',
				'label'      => _x( 'Blue', 'Color scheme picker', 'theme_hamburg_textdomain' )
			),
			'yellow' => array (
				'background' => 'ffbc00',
				'foreground' => 'fff',
				'label'      => _x( 'Yellow', 'Color scheme picker', 'theme_hamburg_textdomain' )
			),
			'dark' => array (
				'background' => '616c7a',
				'foreground' => 'fff',
				'label'      => _x( 'Dark', 'Color scheme picker', 'theme_hamburg_textdomain' )
			)
		);

		return apply_filters( get_stylesheet() . '_color_schemes', $schemes );
	}

	/**
	 * Create proper URL for logo source in customizer.
	 *
	 * @param  string $src
	 * @return string
	 */
	public function customizer_logo_src( $src ) {

		if ( 0 !== stripos( $src, 'http' ) )
			return '';

		return esc_url( $src );
	}

	/**
	 * Add current color scheme to body classes.
	 *
	 * @wp-hook body_class
	 * @param   array $classes
	 * @return  array
	 */
	public function colorscheme_body_class( $classes ) {

		$scheme   = get_theme_mod( 'color_scheme' );
		$defaults = $this->get_color_schemes();

		if ( empty ( $scheme ) or ! isset ( $defaults[ $scheme ] ) )
			$classes[] = "color-scheme-" . $this->default_color_scheme;
		else
			$classes[] = "color-scheme-$scheme";

		return $classes;
	}

	/**
	 * Set current main color for msapplication-TileColor in head element.
	 *
	 * See header.php
	 *
	 * @wp-hook hamburg_ms_tile_color
	 * @param   string $color Something like #ffffff
	 * @return  string
	 */
	public function ms_tile_color( $color ) {

		$scheme   = get_theme_mod( 'color_scheme' );
		$defaults = $this->get_color_schemes();

		if ( isset ( $defaults[ $scheme ] ) )
			return '#' . $defaults[ $scheme ][ 'background' ];

		return $color;
	}
}
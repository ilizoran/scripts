<?php
/**
 * Plugin support: WooCommerce.
 *
 * @link http://wordpress.org/plugins/woocommerce/
 */
if ( ! hamburg_is_wc() ) {
	return;
}

/**
 * Add WooCommerce theme support.
 *
 * @link http://docs.woothemes.com/document/third-party-custom-theme-compatibility/
 */
add_theme_support( 'woocommerce' );

/* Unset WooCommerce default stylesheets. */
add_filter( 'woocommerce_enqueue_styles', 'hamburg_wc_filter_woocommerce_enqueue_styles_remove' );

/* Remove WooCommerce karma. */
remove_action( 'woocommerce_before_shop_loop', 				'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 				'woocommerce_catalog_ordering', 30 );
remove_action( 'woocommerce_before_main_content', 			'woocommerce_breadcrumb', 20 );
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
remove_action( 'woocommerce_single_product_summary',		'woocommerce_template_single_title', 5 );
remove_action( 'woocommerce_single_product_summary',		'woocommerce_template_single_excerpt', 20 );
remove_action( 'woocommerce_single_product_summary',		'woocommerce_template_single_meta', 40 );
remove_action( 'woocommerce_single_product_summary',		'woocommerce_template_single_sharing', 50 );
remove_action( 'woocommerce_after_shop_loop_item_title',	'woocommerce_template_loop_rating', 5 );
remove_action( 'wp_footer',									'woocommerce_demo_store' );

/* Add Hamburg adjustments. */
add_filter( 'loop_shop_per_page', 							'hamburg_wc_loop_shop_per_page' );
add_filter( 'woocommerce_breadcrumb_defaults',				'hamburg_wc_breadcrumb_defaults' );
add_filter( 'woocommerce_default_address_fields',			'hamburg_wc_sanitize_form_fields' );
add_filter( 'get_product_search_form',						'hamburg_wc_search_form' );
add_action( 'woocommerce_share',							'hamburg_social_sharing_bar' );
add_filter( 'add_to_cart_fragments', 						'hamburg_add_mini_cart_to_woocommerce_fragment' );
add_action( 'woocommerce_after_shop_loop_item_title',		'woocommerce_template_loop_rating', 11 );
add_filter( 'woocommerce_get_price_html',					'hamburg_wc_get_price_html', 10, 2 );
add_filter( 'woocommerce_free_price_html',                  'hamburg_wc_free_price_html', 10, 2 );
add_action( 'wp_enqueue_scripts',							'hamburg_wc_enqueue_scripts', 9 );
add_action( 'woocommerce_email_settings',					'hamburg_wc_set_email_styling' );
add_filter( 'hamburg_content_area_class',					'hamburg_wc_content_area_class' );

/**
 * Adjust posts per page value
 *
 * @wp-hook loop_shop_per_page
 * @return  int
 */
function hamburg_wc_loop_shop_per_page() {

	return ( is_product_category() || is_product_tag() ) ? 9 : 8;
}

/**
 * Replace Woo search form.
 *
 * @wp-hook get_product_search_form
 * @return  string
 */
function hamburg_wc_search_form() {

	ob_start();
		wc_get_template_part( 'hamburg', 'product-searchform' );
		$form = ob_get_contents();
	ob_end_clean();

	return $form;
}

/**
 * Improve checkout fields.
 *
 * @wp-hook woocommerce_checkout_fields
 * @wp-hook woocommerce_shipping_fields
 * @param   array $fields
 * @return  array
 */
function hamburg_wc_sanitize_form_fields( $fields ) {

	foreach ( $fields as $key => &$field ) {

		if ( $key !== 'country' && $key !== 'state' )
			continue;

		$field['class'] = empty ( $field['class'] ) ? array() : $field['class'];

			// Add class for select field container
		if (
			in_array( 'update_totals_on_change', $field['class'] )
			&& 'yes' == get_option( 'woocommerce_enable_chosen' )
			) {
			array_push( $field['class'], 'has-chosen' );
		} elseif (
			in_array( 'update_totals_on_change', $field['class'] )
		) {
			array_push( $field['class'], 'no-chosen' );
		}
	}

	return $fields;
}


/* Replace product thumbnails in the Loop. */
if ( ! function_exists( 'woocommerce_template_loop_product_thumbnail' ) ) :

	/**
	 * Get the product thumbnail for the loop.
	 *
	 * @return void
	 */
	function woocommerce_template_loop_product_thumbnail() {
		echo '<figure class="entry-image">' . woocommerce_get_product_thumbnail() . '</figure>';
	}
endif;


/* Replace term thumbnails. */
if ( ! function_exists( 'woocommerce_subcategory_thumbnail' ) ) {
	/**
	 * Show subcategory thumbnails.
	 *
	 * @param mixed $category
	 * @return bool|string
	 */
	function woocommerce_subcategory_thumbnail( $category ) {

		$small_thumbnail_size = apply_filters( 'single_product_small_thumbnail_size', 'shop_catalog' );
		$dimensions           = wc_get_image_size( $small_thumbnail_size );
		$thumbnail_id         = get_woocommerce_term_meta( $category->term_id, 'thumbnail_id', TRUE );

		if ( $thumbnail_id ) {
			$image = wp_get_attachment_image_src( $thumbnail_id, $small_thumbnail_size );
			$image = $image[0];
		} else {
			$image = woocommerce_placeholder_img_src();
		}

		if ( ! $image ) {
			return FALSE;
		}

		// Prevent esc_url from breaking spaces in urls for image embeds
		// Ref: http://core.trac.wordpress.org/ticket/23605
		$image = str_replace( ' ', '%20', $image );

		printf( '<figure class="entry-image"><img src="%1$s" alt="%2$s" width="%3$s" height="%4$s" /></figure>',
			$image,
			$category->name,
			$dimensions['width'],
			$dimensions['height']
		);
	}
}

/**
 * Adjust breadcrumbs.
 *
 * @return array
 */
function hamburg_wc_breadcrumb_defaults() {

	$seperator = _x(
		'<span class="sep"><span>/</span></span>',
		'WooCommerce breadcrumbs seperator',
		'theme_hamburg_textdomain'
	);

	$args = array (
		'delimiter'   => $seperator,
		'wrap_before' => '<nav class="woocommerce-breadcrumb" itemprop="breadcrumb">',
		'wrap_after'  => '</nav>',
		'before'      => '',
		'after'       => '',
		'home'        => _x( 'Home', 'breadcrumb', 'woocommerce' )
	);

	return $args;
}


/**
 * WooCommerce cart shortcode handler.
 *
 * @param array $args
 * @return string
 */
function hamburg_wc_mini_cart( $args ) {

	// Get cart contents
	$items = WC()->cart->get_cart();

	// Sum quantity of each item
	$count = 0;
	foreach ( $items as $item ) {
		$count += $item['quantity'];
	}

	if ( 1 > $count ) {
		return '';
	}

	$defaults = array(
		'before'    => '',
		'after'     => '',
		'separator' => ''
	);

	$args = wp_parse_args( $args, $defaults );

	// Markup added for quantity
	$count_html = sprintf( '<span class="quantity-mini-cart">%s</span>', $count );
	$count_html = apply_filters( 'hamburg_mini_cart_count_html', $count_html, $count );

	// Add a separator if the number of items is visible.
	if ( '' !== $count_html ) {
		$count_html = $args['separator'] . $count_html;
	}

	$output = WC()->cart->get_cart_subtotal() . $count_html;
	$output = $args['before'] . $output . $args['after'];

	return apply_filters( 'hamburg_wc_mini_cart', $output, $args, $count );
}

/**
 * Adds mini cart markup to the woocommerce ajax fragments
 *
 * @param  array $fragments
 * @return array $fragments
 */
function hamburg_add_mini_cart_to_woocommerce_fragment( $fragments ) {

	$fragments['hamburg_mini_cart'] = hamburg_wc_mini_cart(
		array(
			'before'    => '<div class="mini-cart">
							<a href="' . WC()->cart->get_cart_url() . '">',
			'after'     => '</a></div>',
			'separator' => '<i class="icon-shopping-cart fa-shopping-cart"></i>'
		)
	);

	return $fragments;
}

/**
 * List best selling products on sale.
 *
 * @param  array $args
 * @return string
 */
function hamburg_best_selling_products( $args ) {

	$default_meta_query = WC()->query->get_meta_query();
	$meta_query         = apply_filters( 'hamburg_best_selling_products_meta_query', $default_meta_query );

	$defaults = array (
		'post_type' => 'product',
		'post_status' => 'publish',
		'posts_per_page' => 10,
		'ignore_sticky_posts' => 1,
		'before' => '',
		'after' => '',
		'order' => 'DESC',
		'orderby' => 'meta_value_num',
		'meta_key' => 'total_sales',
		'meta_query' => array_filter( $meta_query ),
	);

	$args      = wp_parse_args( $args, $defaults );
	$products  = new WP_Query( $args );
	$start     = woocommerce_product_loop_start( FALSE );
	$end       = woocommerce_product_loop_end( FALSE );
	$content   = '';

	// User message for shop admins in case no products have been sold yet.
	$msg = sprintf( '<div class="alert-error"><h3>%1$s</h3><p>%2$s</p></div>',
		__( 'No products have been sold yet.', 'theme_hamburg' ),
		__( 'Make some purchases to see best selling products appear here.', 'theme_hamburg' )
	);

	// Product query.
	if ( $products->have_posts() ) {

		ob_start();
		while ( $products->have_posts() ) {

			$products->the_post();
			wc_get_template_part( 'content', 'product-related' );
		}

		// Store for later.
		$content = ob_get_clean();

		wp_reset_query();
	}

	$query_string = $args['before'] . $start . $content . $end . $args['after'];

	// Display message for logged-in shop admins only.
	$maybe_msg = current_user_can( 'manage_woocommerce' ) ? $msg : '';

	/* Output will be:
	   a. formatted query of best selling products if existent,
	   -OR-
	   b. user message if the logged-in user has woocommerce admin capabilities,
	   -OR-
	   c. nothing (an empty string).
	*/
	$output = $content ? $query_string : $maybe_msg;

	return apply_filters( 'hamburg_best_selling_products',
		$output,
		$args, $start, $end, $content, $msg
	);
}


/**
 * Adds full-width class to account page.
 *
 * @return string
 */
function hamburg_wc_content_area_class() {

	return is_account_page() ? ' full-width' : '';
}

/**
 * Turn product rating into width value.
 *
 * @return int
 */
function hamburg_wc_average_rating_to_width( $value ) {

	return round( ( $value * 2 ), 0 ) * 10;
}


/**
 * Returns the product rating in html format.
 *
 * @access public
 * @param  string $rating (default: '')
 * @uses   hamburg_wc_average_rating_to_width()
 * @return string
 */
function hamburg_wc_get_rating_html( $product, $rating = NULL ) {

	if ( ! is_numeric( $rating ) )
		$rating = $product->get_average_rating();

	if ( $rating <= 0 )
		return;

	$rating_html  = '<div class="rating-wrapper"><div class="star-rating" title="' . sprintf( __( 'Rated %s out of 5', 'woocommerce' ), $rating ) . '">';
	$rating_html .= '<span style="width:' . hamburg_wc_average_rating_to_width( $rating ) . '%">';
	$rating_html .= '<strong class="rating">' . $rating . '</strong> ' . __( 'out of 5', 'woocommerce' );
	$rating_html .= '</span></div></div>';

	return $rating_html;
}


/**
 * wpSEO support for WooCommerce.
 *
 * @link https://gist.github.com/sergejmueller/1716085
 * @link http://helpdesk.wpseo.de/manual/woocommerce-integration/
 * @return string
 */
if ( class_exists( 'wpSEO' ) ) :

	add_action('init', 'wpseo_set_title');
	function wpseo_set_title() {

		add_filter(
			'wpseo_set_title',
			'wpseo_set_title_callback'
		);
	}

	function wpseo_set_title_callback( $input ) {

		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return get_post_meta(
				get_option( 'woocommerce_shop_page_id' ),
				'_wpseo_edit_title',
				TRUE
			);
		}

		return $input;
	}

	add_action('init', 'wpseo_set_desc');
	function wpseo_set_desc() {

		add_filter(
			'wpseo_set_desc',
			'wpseo_set_desc_callback'
		);
	}

	function wpseo_set_desc_callback( $input ) {

		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return get_post_meta(
				get_option( 'woocommerce_shop_page_id' ),
				'_wpseo_edit_description',
				TRUE
			);
		}

		return $input;
	}

endif;


/**
 * Unset WooCommerce stylesheets including prettyPhoto.
 *
 * @param $styles (array)
 * @return void
 */
function hamburg_wc_filter_woocommerce_enqueue_styles_remove( $styles = array() ) {

	// unset woo-styles
	unset( $styles[ 'woocommerce-layout' ] );
	unset( $styles[ 'woocommerce-smallscreen' ] );
	unset( $styles[ 'woocommerce-general' ] );

	// we also don't need prettyPhoto
	wp_deregister_style( 'woocommerce_prettyPhoto_css' );
}

/**
 * Wrap product price in a div.
 *
 * @param mixed $price
 * @param mixed $product
 * @return string
 */
function hamburg_wc_get_price_html( $price, $product ) {
	return apply_filters( 'hamburg_wc_get_price_html', "<div class='price-tag'>$price</div>", $price, $product );
}

/**
 * Enqueue custom init for prettyPhoto.
 *
 * @return void
 */
function hamburg_wc_enqueue_scripts() {

	global $post;

	$prettyPhoto =	get_option( 'woocommerce_enable_lightbox' ) == 'yes' &&
					( is_product() || ( ! empty( $post->post_content ) && strstr( $post->post_content, '[product_page' ) ) );

	if( ! $prettyPhoto )
		return;

	// Remove default PP init.
	wp_dequeue_script( 'prettyPhoto-init' );

	// Add Hamburg PP init.
	wp_enqueue_script(
		'prettyPhoto-init',
		get_template_directory_uri() . '/assets/js/prettyPhoto/jquery.prettyPhoto.init' . hamburg_min_suffix() . '.js',
		array( 'jquery' ),
		NULL,
		TRUE
	);

	// Add Hamburg responser.
	wp_enqueue_script(
		'responser',
		get_template_directory_uri() . '/assets/js/responser' . hamburg_min_suffix() . '.js',
		array( 'jquery' ),
		NULL,
		TRUE
	);
}


/**
 * Set colors for email template.
 *
 * Only fires on WooCommerce E-Mail settings page.
 * Sets up a theme mod with the colors of any active default color scheme
 * and updates WooCommerce’s e-mail settings accordingly.
 * Applies various checks to not destroy any previously set colors.
 *
 * @wp-hook woocommerce_email_settings
 * @param mixed $settings
 * @return array
 */
function hamburg_wc_set_email_styling( $settings ) {

	/* Have gone through this once before? Then don’t do anything. */
	if( get_theme_mod( 'wc_email_styling' ) )
		return $settings;

	/* Retrieve WooCommerce default email colors. */
	$wc_defaults = array();

	$keys = array(
		'woocommerce_email_background_color',
		'woocommerce_email_body_background_color',
		'woocommerce_email_base_color',
		'woocommerce_email_text_color',
	);

	foreach( $settings as $setting ) {

		if(	in_array( $setting['id'], $keys )
			&& $setting['type'] == 'color'
			&& isset( $setting['default'] ) ) {
				$wc_defaults[$setting['id']] = $setting['default'];
			}
	}

	$wc_defaults = array(
		'woocommerce_email_background_color'		=> isset( $wc_defaults['woocommerce_email_background_color'] ) ? $wc_defaults['woocommerce_email_background_color'] : '#f5f5f5',
		'woocommerce_email_body_background_color'	=> isset( $wc_defaults['woocommerce_email_body_background_color'] ) ? $wc_defaults['woocommerce_email_body_background_color'] : '#fdfdfd',
		'woocommerce_email_base_color'				=> isset( $wc_defaults['woocommerce_email_base_color'] ) ? $wc_defaults['woocommerce_email_base_color'] : '#557da1',
		'woocommerce_email_text_color'				=> isset( $wc_defaults['woocommerce_email_text_color'] ) ? $wc_defaults['woocommerce_email_text_color'] : '#505050',
	);

	/* Retrieve currently set options for email colors. */
	$wc_options = array(
		'woocommerce_email_background_color'		=> get_option( 'woocommerce_email_background_color' ),
		'woocommerce_email_body_background_color'	=> get_option( 'woocommerce_email_body_background_color' ),
		'woocommerce_email_base_color'				=> get_option( 'woocommerce_email_base_color' ),
		'woocommerce_email_text_color'				=> get_option( 'woocommerce_email_text_color' ),
	);

	/* If user has set any email colors via options already,
	 * update theme mode and quit in order to preserve user settings. */
	if( $wc_options !== $wc_defaults ) {
		set_theme_mod( 'wc_email_styling', $wc_options );
		return $settings;
	}

	/* By now we’re pretty sure email colors have not been modified yet,
	 * so let’s set up our theme colors. */
	$scheme = get_theme_mod( 'color_scheme' );

	// Set up variable with default Hamburg colors.
	$email_styling = array(
		'woocommerce_email_background_color'		=> '#f6f6f6',
		'woocommerce_email_body_background_color'	=> '#ffffff',
		'woocommerce_email_base_color'				=> '#2cc2e1',
		'woocommerce_email_text_color'				=> '#49525d',
	);

	// Fill variable according to different color schemes.
	if( $scheme == 'yellow' )
		$email_styling['woocommerce_email_base_color'] = '#ffbc00';

	if( $scheme == 'dark' )
		$email_styling['woocommerce_email_base_color'] = '#616c7a';

	/* Set theme mod to check if we have been through the process already next time. */
	set_theme_mod( 'wc_email_styling', $email_styling );

	/* Update options according to theme mod. */
	foreach( $email_styling as $option => $value )
		update_option( $option, $value );

	// Call it a day.
	return $settings;
}

/**
 * Add visual price container to free products.
 *
 * @param mixed $price
 * @param mixed $obj
 * @return string
 */
function hamburg_wc_free_price_html( $price, $obj ) {

	return "<span class='amount amount-free'>$price</span>";
}

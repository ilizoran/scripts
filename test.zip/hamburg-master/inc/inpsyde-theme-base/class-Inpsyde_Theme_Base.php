<?php # -*- coding: utf-8 -*-
class Inpsyde_Theme_Base {

	protected $config;

	public function __construct( Inpsyde_Property_List $config ) {

		$this->config = $config;

		$this->register_hooks();
	}

	/**
	 * Set up hooks.
	 *
	 * @wp-hook after_setup_theme
	 * @return  void
	 */
	protected function register_hooks() {

		if ( $this->config->has( 'content_width' ) )
			$GLOBALS[ 'content_width' ] = $this->config->content_width;

		if ( $this->config->has( 'use_default_gallery_style' )
			and FALSE === $this->config->use_default_gallery_style ) {
			add_filter( 'use_default_gallery_style', '__return_false' );
		}

		if ( $this->config->has( 'excerpt_length' ) && ! has_filter( 'excerpt_length' ) )
			add_filter( 'excerpt_length', array( $this, 'excerpt_length' ) );

		if ( $this->config->has( 'automatic_feed_links' ) )
			add_theme_support( 'automatic-feed-links' );

		if ( $this->config->has( 'fill_empty_wp_title' ) && TRUE === $this->config->fill_empty_wp_title )
			add_filter( 'wp_title', array ( $this, 'fill_empty_wp_title' ), 1000, 2 );

		// Make sure the encoding is given very early.
		if ( $this->config->has( 'show_meta_charset' ) && TRUE === $this->config->show_meta_charset )
			add_action( 'wp_head', array ( $this, 'show_meta_charset' ), -1 );
	}

	/**
	 * Access configuration from the outside.
	 *
	 * @param string $name
	 * @return mixed
	 */
	public function get_config( $name ) {

		return $this->config->get( $name );
	}

	/**
	 * Print charset information.
	 *
	 * Technically, this is not necessary, and Pagespeed will lower the score if
	 * it is found. The browser has already choosen a charset to be able to read
	 * it. There is just one use case for it: When a document is saved to the
	 * hard disk, some browsers (Mozilla, Chrome?) do not insert the encoding
	 * into the saved HTML code.
	 * Online, the encoding will always be given by the HTTP headers sent by
	 * WordPress.
	 *
	 * @wp-hook wp_head
	 * @return  void
	 */
	public function show_meta_charset() {

		?><meta charset="<?php bloginfo( 'charset' ); ?>"><?php
	}

	/**
	 * Fills empty main title with blog name.
	 *
	 * In some cases, the title is blank.
	 *
	 * @wp-hook wp_title
	 * @param   string $title
	 * @param   string $sep
	 * @return  string
	 */
	public function fill_empty_wp_title( $title, $sep ) {

		$title = trim( $title, "\n\r\t $sep" );

		if ( '' !== $title )
			return $title;

		return get_bloginfo( 'name', 'display' );
	}

	/**
	 * Change excerpt length in words.
	 *
	 * @param  int $length Number of words.
	 * @return int
	 */
	function excerpt_length( $length ) {

		return $this->config->excerpt_length;
	}

	/**
	 * html5 start tag + language attribute + conditional tags for IE Win
	 * @link   http://toscho.de/2010/wordpress-internet-explorer-ohne-css-hacks-ansprechen/
	 * @param  bool $print
	 * @return string
	 */
	public function htmlstart( $print = TRUE ) {
		$out  = '<!DOCTYPE html>';
		$lang = $this->get_language_attributes();
		$ies  = array (
			6 => 'lte6 lte7 lte8',
			7 => 'lte7 lte8',
			8 => 'lte8',
			9 => 'lte9'
		);

		$id = $this->config->element_html_id;
		$id = empty ( $id ) ? '' : " id='$id'";

		foreach ( $ies as $n => $class )
			$out .= "<!--[if IE $n]><html $lang class='no-js ie ie$n $class'$id><![endif]-->";

		$out .= "<!--[if !IE]><!--><html $lang class='no-js realbrowser'$id><!--<![endif]-->";

		if ( $print )
			print $out;

		return $out;
	}

	/**
	 * Returns the language attributes.
	 *
	 * Unobstrusive copy from the core.
	 *
	 * @param  string $doctype The type of html document (xhtml|html).
	 * @return string
	 */
	function get_language_attributes( $doctype = 'html' ) {

		if ( function_exists( 'get_language_attributes' ) )
			return get_language_attributes();

		$output = is_rtl() ? 'dir="rtl"' : '';

		if ( $lang = get_bloginfo('language') ) {
			$output .= ( ( get_option('html_type') != 'text/html'
				|| $doctype == 'xhtml' )
				? ' xml:' : '' ) . 'lang="' . $lang . '"';
		}

		return apply_filters( 'language_attributes', $output );
	}
}
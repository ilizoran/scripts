<?php # -*- coding: utf-8 -*-
/**
 * Add a textarea to the theme customizer.
 *
 * Based on Frank Bueltge's class.
 *
 * @link  {https://github.com/bueltge/Wordpress-Theme-Customizer-Custom-Controls}
 * @since 1.0
 */
class Inpsyde_Customizer_Textarea extends WP_Customize_Control {

	/**
	 * @access public
	 * @var    string
	 */
	public $type = 'textarea';

	/**
	 * @access public
	 * @var    array
	 */
	public $statuses;

	protected $placeholder = '';

	/**
	 * Constructor.
	 *
	 * If $args['settings'] is not defined, use the $id as the setting ID.
	 *
	 * @param   WP_Customize_Manager $manager
	 * @param   string $id
	 * @param   array $args
	 * @return  void
	 */
	public function __construct( $manager, $id, $args = array() ) {

		$this->statuses = array( '' => __( 'Default' ) );

		if ( ! empty ( $args[ 'placeholder' ] ) )
			$this->placeholder = esc_html( $args[ 'placeholder' ] );
		parent::__construct( $manager, $id, $args );
	}

	/**
	 * Render the control's content.
	 *
	 * Allows the content to be overriden without having to rewrite the wrapper.
	 *
	 * @since   10/16/2012
	 * @return  void
	 */
	public function render_content() {
		?>
			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<textarea class="large-text" cols="20" rows="5" <?php $this->link(); ?> placeholder="<?php echo $this->placeholder; ?>">
					<?php echo esc_textarea( $this->value() ); ?>
				</textarea>
			</label>
			<?php
		}
}
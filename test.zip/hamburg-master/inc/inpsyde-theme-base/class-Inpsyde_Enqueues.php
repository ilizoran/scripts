<?php
/**
 * Enqueuing items
 * 
 * @author  Inpsyde GmbH
 * @since   02/01/2014
 */
class Inpsyde_Enqueues {
	
	protected $config;
	
	public function __construct( Inpsyde_Property_List $config ) {
		
		$this->config = $config;
		
		$this->register_hooks();
	}
	
	/**
	 * Set up hooks.
	 * 
	 * @since   02/01/2014
	 * @return  void
	 */
	protected function register_hooks() {
		
		if ( $this->config->has( 'wp_enqueue_scripts' ) )
			add_action( 'wp_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ) );

		if ( $this->config->has( 'admin_enqueue_scripts' ) )
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		
		if ( $this->config->has( 'wp_enqueue_scripts' ) )
			add_action( 'login_enqueue_scripts', array( $this, 'login_enqueue_scripts' ) );
	}
	
	/**
	 * Register a script and also enqueu the script.
	 * 
	 * @since   02/01/2014
	 * @return  void
	 */
	public function wp_enqueue_scripts() {
		
		foreach ( $handle = $this->config->wp_enqueue_scripts as $handle => $args ) {
			
			// set default parameters
			$defaults = array(
				'srv'        => get_template_directory_uri() . '/assets/js/' . $handle . $this->get_min_suffix() . '.js',
				'deps'       => array(),
				'ver'        => NULL,
				'in_footer'  => TRUE
			);
			
			$args = wp_parse_args(
				$args,
				apply_filters( 'theme_base_enqueue_scripts', $defaults )
			);
			
			/**
			 * Register a new script.
			 * 
			 * @param string      $handle    Name of the script. Should be unique.
			 * @param string      $src       Path to the script from the WordPress root directory. Example: '/js/myscript.js'.
			 * @param array       $deps      Optional. An array of registered script handles this script depends on. Set to false if there
			 *                               are no dependencies. Default empty array.
			 * @param string|bool $ver       Optional. String specifying script version number, if it has one, which is concatenated
			 *                               to end of path as a query string. If no version is specified or set to false, a version
			 *                               number is automatically added equal to current installed WordPress version.
			 *                               If set to null, no version is added. Default 'false'. Accepts 'false', 'null', or 'string'.
			 * @param bool        $in_footer Optional. Whether to enqueue the script before </head> or before </body>.
			 *                               Default 'false'. Accepts 'false' or 'true'.
			 */
			wp_register_script(
				$handle,
				$args['srv'],
				$args['deps'],
				$args['ver'],
				$args['in_footer']
			);
			
			// Enqueue a script.
			wp_enqueue_script(
				$handle
			);
			
		}
	}
	
	/*
	 * Suffix for minified script/stylesheet versions.
	 *
	 * Adds a conditional ".min" suffix to the file name
	 * when WP_DEBUG is NOT set to TRUE.
	 * 
	 * @since   02/01/2014
	 * @return  String
	 */
	public function get_min_suffix() {
		
		return defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	}
	
} // end class

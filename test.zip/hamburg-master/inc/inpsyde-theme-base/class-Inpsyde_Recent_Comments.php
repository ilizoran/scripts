<?php # -*- coding: utf-8 -*-
/**
 * Replace the default Recent Comments widget with an extended version.
 *
 * The main diffenerce is: you can choose the post type
 *
 * Other differences
 *
 * - The ul has the class 'recentcomments-list', not the id 'recentcomments',
 *   so you can use the widget multiple times on the same page without
 *   validation errors.
 *
 * @author toscho
 * @since  2013.08.16
 */
class Inpsyde_Recent_Comments extends WP_Widget {

	protected static $widget_id = 'widget_recent_comments';
	public function __construct() {
		$widget_ops = array (
			'classname'   => self::$widget_id,
			'description' => __(
				'The most recent comments for selected post types',
				'theme_hamburg_textdomain'
			)
		);
		parent::__construct(
			'recent-comments',
			__( 'Recent Comments', 'theme_hamburg_textdomain' ),
			$widget_ops
		);

		$this->alt_option_name = 'widget_recent_comments';

		add_action( 'comment_post', array ( $this, 'flush_widget_cache' ) );
		add_action( 'transition_comment_status', array ( $this, 'flush_widget_cache' ) );
	}

	public function flush_widget_cache() {
		wp_cache_delete( 'widget_recent_comments', 'widget' );
	}

	public function widget( $args, $instance ) {
		global $comments, $comment;

		$cache = wp_cache_get( 'widget_recent_comments', 'widget' );

		if ( ! is_array( $cache ) )
			$cache = array ();

		if ( ! isset ( $args[ 'widget_id' ] ) )
			$args['widget_id'] = $this->id;

		if ( isset ( $cache[ $args[ 'widget_id' ] ] ) ) {
			print $cache[ $args[ 'widget_id' ] ];
			return;
		}

 		$output = '';

		$title = ! empty ( $instance[ 'title' ] ) ? $instance[ 'title' ] : __( 'Recent Comments', 'theme_hamburg_textdomain' );
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ! empty( $instance[ 'number' ] ) ? absint( $instance[ 'number' ] ) : 5;
		$post_types = empty( $instance[ 'post_types' ] ) ? array ( 'post' ) : $instance[ 'post_types' ];

		if ( ! $number )
 			$number = 5;

		$comments = get_comments(
			apply_filters(
				'widget_comments_args',
				array(
					'number'      => $number,
					'status'      => 'approve',
					'post_status' => 'publish',
					'post_type'   => $post_types
				)
			)
		);

		$output .= $args['before_widget'];

		if ( $title )
			$output .= $args['before_title'] . $title . $args['after_title'];

		$output .= '<ul class="recentcomments-list">';
		if ( $comments ) {
			// Prime cache for associated posts. (Prime post term cache if we need it for permalinks.)
			$post_ids = array_unique( wp_list_pluck( $comments, 'comment_post_ID' ) );
			_prime_post_caches( $post_ids, strpos( get_option( 'permalink_structure' ), '%category%' ), false );

			foreach ( (array) $comments as $comment) {
				$output .=  '<li class="recentcomments">' . /* translators: comments widget: 1: comment author, 2: post link */ sprintf(_x('%1$s on %2$s', 'widgets'), get_comment_author_link(), '<a href="' . esc_url( get_comment_link($comment->comment_ID) ) . '">' . get_the_title($comment->comment_post_ID) . '</a>') . '</li>';
			}
 		}
		$output .= '</ul>';
		$output .= $args['after_widget'];

		echo $output;
		$cache[ $args[ 'widget_id' ] ] = $output;
		wp_cache_set( 'widget_recent_comments', $cache, 'widget' );
	}

	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		$instance[ 'title' ]      = strip_tags( $new_instance[ 'title' ] );
		$instance[ 'number' ]     = absint( $new_instance[ 'number' ] );
		$instance[ 'post_types' ] = array();

		$allowed = $this->get_post_types();

		foreach ( $allowed as $id => $value ) {
			if ( ! empty ( $new_instance[ "pt-$id" ] ) )
				$instance[ 'post_types' ][] = $id;
		}

		$this->flush_widget_cache();

		$alloptions = wp_cache_get( 'alloptions', 'options' );

		if ( isset ( $alloptions[ 'widget_recent_comments' ] ) )
			delete_option( 'widget_recent_comments' );

		return $instance;
	}

	public function form( $instance ) {

		$title  = isset( $instance[ 'title' ] ) ? esc_attr( $instance[ 'title' ] ) : '';
		$number = isset( $instance[ 'number' ] ) ? absint( $instance[ 'number' ] ) : 5;
		$post_types = isset( $instance[ 'post_types' ] ) ? $instance[ 'post_types' ] : array( 'post' );
?>
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>" /></p>

		<p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e( 'Number of comments to show:' ); ?></label>
		<input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo $number; ?>" size="3" /></p>

		<p><?php _e( 'Post types', 'theme_hamburg_textdomain' ); ?></p>
		<?php
		$comment_post_types = $this->get_post_types();

		print '<ul>';

		foreach ( $comment_post_types as $id => $post_type ) {
			printf(
				'<li><label for="%1$s"><input type="checkbox" name="%2$s" id="%1$s" value="1" %3$s> %4$s</label></li>',
				$this->get_field_id( $id ),
				$this->get_field_name( 'pt-' . $id ),
				( in_array( $id, $post_types ) ? ' checked' : ''),
				$post_type->labels->name
			);
		}
		print '</ul>';
		?>
<?php
	}

	protected function sanitize_post_types( $post_types ) {

		if ( empty ( $post_types ) or ! is_array( $post_types ) )
			return array ( 'post' );

		$possible = $this->get_post_types();
		$out      = array ();

		foreach ( $post_types as $pt ) {
			if ( in_array( $pt, $possible ) )
				$out[] = $pt;
		}

		return $out;
	}

	protected function get_post_types() {

		static $out = array();

		if ( ! empty ( $out ) )
			return $out;

		$post_types = get_post_types( array ( 'public' => TRUE ), 'objects' );

		/* We need an extra check, because get_post_types() cannot filter
		 * by support.
		 * @see http://core.trac.wordpress.org/ticket/17620
		 */
		foreach ( $post_types as $post_type => $properties ) {
			if ( post_type_supports( $post_type, 'comments' ) )
				$out[ $post_type ] = $properties;
		}

		uasort( $out, array ( $this, 'sort_cpts_by_label' ) );

		return $out;
	}

	protected function sort_cpts_by_label( $cpt1, $cpt2 ) {

		return strcasecmp(
			$cpt1->labels->name,
			$cpt2->labels->name
		);
	}

	/**
	 * Register this widget.
	 *
	 * @wp-hook widgets_init
	 * @return  boolean
	 */
	public static function register()
	{
		unregister_widget( 'WP_Widget_Recent_Comments' );

		register_widget( __CLASS__ );
	}
}

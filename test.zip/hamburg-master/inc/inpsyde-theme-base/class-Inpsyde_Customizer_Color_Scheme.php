<?php # -*- coding: utf-8 -*-
/**
 * Class to create a custom layout control
 */
class Inpsyde_Customizer_Color_Scheme extends WP_Customize_Control {

	protected $schemes, $default_scheme;

	/**
	 * Constructor.
	 *
	 * If $args['settings'] is not defined, use the $id as the setting ID.
	 *
	 * @param   WP_Customize_Manager $manager
	 * @param   string $id
	 * @param   array $args
	 */
	public function __construct( $manager, $id, $args = array() ) {

		//$this->statuses = array( '' => __( 'Default' ) );
		$this->schemes = $args[ 'schemes' ];
		$this->default_scheme = $args[ 'default' ];
		parent::__construct( $manager, $id, $args );
	}

	public function render_content() {

		$current = get_theme_mod( $this->id, $this->default_scheme );
		//echo $current;
		?>
			<ul>
			<?php
			foreach ( $this->schemes as $key => $values ) {
				print '<li>' . $this->get_radio( $key, $values, $current ) . '</li>';
			}
			?>
			</ul>
			<?php
	}

	protected function get_radio( $key, $values, $current ) {

		return sprintf(
			'<label for="%1$s" style="display:block;padding:5px 10px;font-weight:bold;color:#%2$s;background:#%3$s"><input type="radio" name="%4$s" id="%1$s" value="%7$s" %5$s %8$s> %6$s</label>',
			"$this->id-$key",
			$values[ 'foreground' ],
			$values[ 'background' ],
			$this->id,
			checked( $key, $current, FALSE ),
			esc_html( $values[ 'label' ] ),
			$key,
			$this->get_link()
		);
	}
}
<?php
/**
 * Implements an optional custom header for Hamburg Theme.
 * See http://codex.wordpress.org/Custom_Headers
 */

/**
 * Sets up the WordPress core custom header arguments and settings.
 *
 * @uses add_theme_support() to register support for 3.4 and up.
 * @uses hamburg_admin_header_style() to style wp-admin form.
 * @uses hamburg_admin_header_image() to add custom markup to wp-admin form.
 * @return void
 */
function hamburg_custom_header_setup() {
	$args = array(
		// Text color and image (empty to use none).
		'default-text-color'     => '#ffffff', // Needs value, otherwise display_header_text() does not work!
		'default-image'          => '',

		// Set height and width, with a maximum value for the width.
		'height'                 => 200,
		'width'                  => 1024,
		'max-width'              => 1024,

		// Support flexible height and width.
		'flex-height'            => TRUE,
		'flex-width'             => FALSE,

		// Random image rotation off by default.
		'random-default'         => FALSE,

		// Callbacks for styling the header and the admin preview.
		'admin-head-callback'    => 'hamburg_admin_header_style',
		'admin-preview-callback' => 'hamburg_admin_header_image',
	);

	add_theme_support( 'custom-header', $args );
}
add_action( 'after_setup_theme', 'hamburg_custom_header_setup' );

/**
 * Disable color selection in theme customizer.
 *
 * We do not use this setting, but we need the checkbox on
 * themes.php?page=custom-header
 *
 * @return void
 */
function hamburg_disable_header_text_temporary() {

	if ( empty ( $GLOBALS['wp_customize'] ) )
		return;

	global $_wp_theme_features;

	$_wp_theme_features['custom-header'][0]['header-text'] = FALSE;
}
add_action( 'admin_init', 'hamburg_disable_header_text_temporary' );

/**
 * Styles the header image displayed on the Appearance > Header admin panel.
 *
 * @return string
 */
function hamburg_admin_header_style() {

	/* Google fonts stylesheet.  */
	$protocol	= is_ssl() ? 'https' : 'http';
	$query_args = array( 'family' => 'Open+Sans:400,300,700|Roboto+Condensed:400,300,700' );

	wp_enqueue_style(
		'webfonts',
		add_query_arg( $query_args, "$protocol://fonts.googleapis.com/css" ),
		array(),
		NULL
	);

?>
	<style type="text/css">
	.appearance_page_custom-header .displaying-header-text {
		display: none !important;
	}
	.appearance_page_custom-header #headimg {
		border: none;
		background: #f6f6f6;
		line-height: .5;
	}
	#headimg .branding {
		background: #2cc2e1;
		margin-bottom: 48px;
		overflow: hidden;
		padding: 4px;
	}
	#headimg h1,
	#headimg #desc {
		color: #fff;
		float: left;
		font-family: "Roboto Condensed", "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
		font-weight: 300;
		line-height: 1;
		margin: 0;
	}
	#headimg h1 {
		font-size: 32px;
		font-size: 2rem;
		line-height: 0.8125;
		text-transform: uppercase;
		padding: 0 8px 0 0;
	}
	#headimg h1 a,
	#headimg h1 a:hover {
		color: #fff;
		text-decoration: none;
	}
	#headimg #desc {
		font-size: 14px;
		font-size: 0.875rem;
		font-weight: 300;
		line-height: 1.9;
		padding: 0 8px;
	}
	<?php if ( ! display_header_text() ) : ?>
	#headimg .branding {
		display: none;
	}
	<?php endif; ?>
	#headimg img {
		height: auto;
		max-width: 100%;
	}
	#theme-message {
		background-color: #fcfcfc;
		border-color: #dfdfdf;
	}
	#theme-message h3 {
		padding-left: 20px;
		position: relative;
	}
	#theme-message h3 i {
		background: url('images/menu.png') no-repeat -275px -40px;
		display: block;
		height: 16px;
		left: 0;
		position: absolute;
		text-indent: -100%;
		width: 20px;
	}
	</style>
<?php
}

/**
 * Outputs markup to be displayed on the Appearance > Header admin panel.
 * This callback overrides the default markup displayed there.
 *
 * @return string
 */
function hamburg_admin_header_image() {
	?>
	<div id="headimg">
	<?php $header_image = get_header_image();
		if ( ! display_header_text() )
			$style = ' style="display:none';
		else
			$style = '';
		?>
		<div class="branding"<?php echo $style; ?>>
			<h1 id="title">
				<a id="theme-name" onclick="return false;" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php bloginfo( 'name' ); ?>
				</a>
			</h1>
			<p id="desc"><?php bloginfo( 'description' ); ?></p>
		</div>
	<?php
		if ( ! empty( $header_image ) ) : ?>
		<img src="<?php
			echo esc_url( $header_image );
			?>" class="header-image" width="<?php
			echo get_custom_header()->width;
			?>" height="<?php echo
			get_custom_header()->height;
			?>" alt="" />
	<?php
	endif;
	?>
	</div>
	<div id="theme-message" class="updated">
	<h3><i>!</i> <?php _e( 'Achtung!', 'theme_hamburg_textdomain' ); ?></h3>
	<p>
	<?php
		printf(
			_x(
				'Theme %s got brains! Custom Header options will be processed in the following order:',
				'%s = theme name', 'theme_hamburg_textdomain'
			),
			wp_get_theme() );
	?>
	</p>
	<ol>
		<li>
			<p><strong>
			<?php
				_e(
					'Header Text below is checked.',
					'theme_hamburg_textdomain'
				);
			?>
			</strong><br />
			<?php
				_e(
					'If Header Text below is checked, blogname and description appear in the upper left corner of the menu bar fixed at the top.',
					'theme_hamburg_textdomain'
				);
			?>
			</p>
		</li>
		<li>
			<p><strong>
			<?php
				_e(
					'Header Text is not checked.',
					'theme_hamburg_textdomain'
				);
			?>
			</strong><br />
			<?php
				printf(
					_x(
						'If Header Text is not checked, that location is available as a custom menu location in %s; Primary Meta Menu, to be precise.',
						's% = link to Menus',
						'theme_hamburg_textdomain'
					),
					'<a href="/wp-admin/nav-menus.php">'
					. __(
						'Menus',
						'theme_hamburg_textdomain'
						)
					. '</a>'
				);
			?>
			</p>
		</li>
		<li>
			<p><strong>
			<?php
				_e(
					'A Header Image is selected.',
					'theme_hamburg_textdomain'
				);
			?>
			</strong><br />
			<?php
				_e(
					'If you select a Header Image below, it does appear in your theme header, no matter what.',
					'theme_hamburg_textdomain'
				);
			?>
			</p>
		</li>
		<li>
			<p><strong>
			<?php
				_e(
					'A Header Image is not selected.',
					'theme_hamburg_textdomain'
				);
			?>
			</strong><br />
			<?php
				printf(
					_x(
						'If you don’t select (or de-select) a header image, the theme’s default header appears and the logo option becomes available %s.',
						'%s = link to Customizer',
						'theme_hamburg_textdomain'
						),
					'<a href="/wp-admin/customize.php">'
					. _x(
						'within the Customizer',
						'before: "logo option becomes available"',
						'theme_hamburg_textdomain'
						)
					. '</a>'
				);
			?>
			</p>
			<p><strong>
			<?php

			printf(
				_x(
					'Please visit the <a href="%s">Hamburg theme documentation</a> for further details on all things header.',
					'%s = docs URL',
					'theme_hamburg_textdomain'
				),
				'http://marketpress.com/documentation/theme-hamburg/'
			);
			?>
			</strong></p>
		</li>
	</ol>
	</div>
<?php
}
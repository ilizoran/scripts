<?php
/**
 * Callback for text comments.
 *
 * @param mixed $comment
 * @param mixed $args
 * @param mixed $depth
 * @return string
 */
function hamburg_comment( $comment, $args, $depth ) {
?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
		<section id="comment-<?php comment_ID(); ?>" class="comment">
			<header class="comment-meta comment-author vcard">
				<?php

				/**
				 * Default Gravatar size in WordPress is 96px. That's just fine.
				 *
				 * @link http://codex.wordpress.org/Using_Gravatars#Theme_Support_for_WordPress_2.5.2B
				 */
				echo get_avatar( $comment );

				printf( '<cite class="fn">%s</cite>', get_comment_author_link() );
				printf( '<a href="%1$s"><time pubdate datetime="%2$s">%3$s</time></a>',
					esc_url( get_comment_link( $comment->comment_ID ) ),
					get_comment_time( 'c' ),
					sprintf(
						_x(
							'%1$s @ %2$s',
							'1: date, 2: time for comment meta',
							'theme_hamburg_textdomain'
						),
						get_comment_date(),
						get_comment_time() )
				);
				edit_comment_link(
					__( 'Edit', 'theme_hamburg_textdomain' ),
					'<span class="edit-link">',
					'</span>'
				);
				?>
			</header>

			<?php if ( '0' == $comment->comment_approved ) : ?>
				<p class="comment-awaiting-moderation alert-info"><?php
					_e( 'Your comment is awaiting moderation.', 'theme_hamburg_textdomain' );
				?></p>
			<?php endif; ?>

			<section class="comment post-content">
				<?php comment_text(); ?>
				<p>
				<?php
				/**
				 * Omnipresent reply link.
				 *
				 * Adjust to a defined maximal depth by setting
				 * 'max_depth' => $args['max_depth'].
				 */
				comment_reply_link(
					array_merge(
						$args,
						array(
						'reply_text'=> __( 'Reply', 'theme_hamburg_textdomain' ),
						'depth' 	=> $depth,
						'max_depth'	=> 999
						)
					)
				);
				?>
				</p>
			</section>
		</section>
	<?php
}


/**
 * Count amount of pingbacks + trackbacks for a post.
 *
 * @link http://wordpress.stackexchange.com/a/96596/23011
 * @param mixed $post_id (default: NULL)
 * @return string
 */
function hamburg_count_pings( $post_id = NULL ) {
	$pings	  = 0;
	$comments = FALSE;

	if ( NULL !== $post_id ) :
		$comments = get_comments(
			array (
				'post_id' => $post_id, # Note: post_ID will not work!
				'status'  => 'approve'
			)
		);
	elseif ( ! empty ( $GLOBALS['wp_query']->comments ) ) :
		$comments = $GLOBALS['wp_query']->comments;
	endif;

	if ( ! $comments )
		return 0;

	foreach ( $comments as $c )
		if ( in_array ( $c->comment_type, array ( 'pingback', 'trackback' ) ) )
			$pings += 1;

	return $pings;
}

/**
 * Callback for wp_list_comments( array ( 'type' => 'pings' ) )
 *
 * @link http://wordpress.stackexchange.com/a/96596/23011
 * @param  object $comment
 * @return string
 */
function hamburg_list_pings_callback( $comment ) {
	$url	 = esc_url( $comment->comment_author_url );
	$icon	 = hamburg_external_favicon( $url );
	$name	 = esc_html( $comment->comment_author );

	print "<li><a href='$url'>$icon $name</a>";
}

/**
 * Get an img element for a favicon from Google.
 *
 * @link http://wordpress.stackexchange.com/a/96596/23011
 * @param  string $url
 * @param  string $class class attribute
 * @param  int	  $size
 * @param  string $alt
 * @return string
 */
function hamburg_external_favicon( $url, $class = 'icon', $size = 16, $alt = '' ) {
	$host	  = parse_url( $url,  PHP_URL_HOST );
	$icon_url = "https://plus.google.com/_/favicon?domain=$host";

	return "<img class='$class' width='$size' height='$size' alt='$alt' src='$icon_url' />";
}

/**
 * Move comment textarea and notes above other form fields.
 *
 * @link https://gist.github.com/toscho/2553604
 *
 */
add_filter( 'comment_form_defaults', 'hamburg_move_comment_textarea', 100 );
add_action( 'comment_form_top', 'hamburg_move_comment_textarea' );

/**
 * Move the textarea field.
 *
 * @param  array $input
 * @return array
 */
function hamburg_move_comment_textarea( $input = array() ) {

	/**
	 * Make sure this does not display on ANY
	 * of the WooCommerce shop pages.
	 */
	if ( hamburg_is_woo() )
		return $input;

	static $textarea = '';

	if ( 'comment_form_defaults' === current_filter() ) :
		$textarea = $input['comment_field'];
		$input['comment_field'] = '';
		return $input;
	endif;

	print apply_filters( 'comment_form_field_comment', $textarea );
}

add_filter( 'comment_form_defaults', 'hamburg_move_comment_allowed_tags', 100 );
add_action( 'comment_form_top', 'hamburg_move_comment_allowed_tags' );

/**
 * Move the list of allowed tags.
 *
 * @param  array $input
 * @return array
 */
function hamburg_move_comment_allowed_tags( $input = array() ) {
	static $text = '';

	if ( 'comment_form_defaults' === current_filter() ) :
		$text = $input['comment_notes_after'];
		$input['comment_notes_after'] = '';
		return $input;
	endif;

	print $text;
}
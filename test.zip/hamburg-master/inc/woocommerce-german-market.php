<?php
/**
 * Plugin support: WooCommerce German Market.
 *
 * @link http://marketpress.com/product/woocommerce-german-market/
 */
if ( ! hamburg_is_wgm() )
	return;

/* Unset WGM default CSS option. @todo Add settings message. */
add_action( 'after_setup_theme', 'hamburg_wgm_unset_default_css' );
add_filter( 'pre_update_option_load_woocommerce-de_standard_css', 'hamburg_wgm_block_option_default_css', 11, 2 );

/* Revert WC-only price template. */
remove_filter( 'woocommerce_get_price_html',         'hamburg_wc_get_price_html', 10 );

/* Single product: price template wrapper. */
remove_filter( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 	10 );
   add_filter( 'woocommerce_single_product_summary', 'hamburg_wc_open_price', 10 );
   add_filter( 'woocommerce_single_product_summary', 'hamburg_wc_close_price', 21 );

/* Single product: price template. */
remove_filter( 'woocommerce_single_product_summary', array( 'WGM_Template', 'woocommerce_de_price_with_tax_hint_single' ), 7 );
   add_filter( 'woocommerce_single_product_summary', array( 'WGM_Template', 'woocommerce_de_price_with_tax_hint_single' ), 20 );

/* Single product: shipping time and shipping fees. */
remove_filter( 'woocommerce_single_product_summary', array( 'WGM_Template', 'add_template_loop_shop' ), 11 );
   add_filter( 'woocommerce_single_product_summary', array( 'WGM_Template', 'add_template_loop_shop' ), 30 );

/* Single product: extra fees notice for non-EU countries. */
remove_filter( 'woocommerce_single_product_summary', array( 'WGM_Template', 'show_extra_costs_eu' ), 11 );
   add_filter( 'woocommerce_single_product_summary', array( 'WGM_Template', 'show_extra_costs_eu' ), 30 );

/* Product loop shipping time. */
remove_filter( 'woocommerce_after_shop_loop_item',    array( 'WGM_Template', 'woocommerce_de_after_shop_loop_item' ) );
   add_filter( 'woocommerce_after_shop_loop_item',    array( 'WGM_Template', 'woocommerce_de_after_shop_loop_item' ), 5 );

/* Product loop price tag wrapper. */
add_action( 'wgm_before_loop_price', 'hamburg_wgm_loop_price_before' );
add_action( 'wgm_after_loop_price',  'hamburg_wgm_loop_price_after' );


/**
 * Wrapper for tax hint.
 *
 * @return string
 */
function hamburg_wc_open_price() {
	echo '<div class="price-de-tax-extra-costs">';
}

/**
 * Wrapper for tax hint.
 *
 * @return string
 */
function hamburg_wc_close_price() {
	echo "</div>";
}

/**
 * Disable WGM default CSS.
 *
 * @return string
 */
function hamburg_wgm_block_option_default_css( $value, $old_value ) {

	if( 'off' !== $value )
		$value = 'off';

	return $value;
}

/**
 * Unset WGM CSS option.
 *
 * @access public
 * @return bool
 */
function hamburg_wgm_unset_default_css() {

	$css = get_option( 'load_woocommerce-de_standard_css' );

	if ( ! $css || $css !== 'on' )
		return FALSE;

	update_option( 'load_woocommerce-de_standard_css', 'off' );

	return TRUE;
}

/**
 * Reformat tax output.
 *
 * @param mixed $text
 * @param mixed $percentage
 * @param mixed $amount
 * @return string
 */
function hamburg_wgm_tax_line( $text, $percentage, $amount ) {

	return sprintf(
				'<span class="product-tax-rate-text">%1$s</span>
				<span class="product-tax-rate-percentage">(%2$s):</span>
				<span class="product-tax-rate-amount">%3$s</span>',
				esc_attr( $text ),	// incl/plus + label, i.e. "incl. VAT"
				$percentage . '%',	// percentage, i.e. "7%"
				$amount				// amount, i.e. "€15,90"
			);
}

/**
 * Add price wrapper inside the Loop.
 *
 * @wp-hook hamburg_wgm_loop_price_before
 * @param mixed $html
 * @param mixed $args
 * @return string
 */
function hamburg_wgm_loop_price_before( ) {
	echo '<span class="price-tag">';
}

/**
 * Close price wrapper inside the Loop.
 *
 * @wp-hook hamburg_wgm_loop_price_after
 * @return string
 */
function hamburg_wgm_loop_price_after() {
	echo '</span>';
}
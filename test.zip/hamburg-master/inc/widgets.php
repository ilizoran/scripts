<?php
/**
 * Widget configuration
 */
add_action( 'widgets_init', 'hamburg_widgets_init' );
function hamburg_widgets_init() {

	// Define widget areas
	$sidebars = array(
		'sidebar-1' => array(
			'name' => _x(
						'Blog Sidebar',
						'Widget area name in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						),
			'desc' => _x(
						'The main sidebar',
						'Widget area description in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						)
			),
		'banner' 		=> array(
			'name' => _x(
						'Front Page Banner',
						'Widget area name in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						),
			'desc' => _x(
						'Widget area at the top of the front page',
						'Widget area description in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						)
			),
		'footer-1' => array(
			'name' => _x(
						'Footer 1',
						'Widget area name in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						),
			'desc' => _x(
						'Footer widgets',
						'Widget area description in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						)
			),
		'footer-2' => array(
			'name' => _x(
						'Footer 2',
						'Widget area name in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						),
			'desc' => _x(
						'More footer widgets',
						'Widget area description in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						)
			),
		'footer-3' => array(
			'name' => _x(
						'Footer 3',
						'Widget area name in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						),
			'desc' => _x(
						'Even more footer widgets',
						'Widget area description in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						)
			),
		'no-results' => array(
			'name' => _x(
						'No Results Page',
						'Widget area name in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						),
			'desc' => _x(
						'Widgets on no result pages (404, searches)',
						'Widget area description in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						)
			),
	);

	$shop_sidebars = array(
		'shop'		=> array(
			'name'	=> _x(
		  				'Shop Sidebar',
		  				'Widget area name in wp-admin/widgets.php',
		  				'theme_hamburg_textdomain'
		  				),
			'desc'	=> _x(
						'Widgets on WooCommerce shop pages',
						'Widget area description in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						),
			),
		'teasers'	=> array(
			'name'	=> _x(
						'Shop Front Page Teasers',
						'Widget area name in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
							),
			'desc'	=> _x(
						'Widget area in the middle of the shop front page',
						'Widget area description in wp-admin/widgets.php',
						'theme_hamburg_textdomain'
						),
			),
	);

	if ( hamburg_is_wc() )
		$sidebars = array_merge( $sidebars, $shop_sidebars );

	// Create widget areas
	foreach ( $sidebars as $id => $args ) {
		register_sidebar( array(
				'name'			=> $args['name'],
				'id'			=> $id,
				'description'	=> $args['desc'],
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
	}

	if ( ! class_exists( 'Inpsyde_Recent_Comments' ) )
		require_once 'inpsyde-theme-base/class-Inpsyde_Recent_Comments.php';

	Inpsyde_Recent_Comments::register();

	// Return a value for unit tests
	return $GLOBALS['wp_registered_sidebars'];
}

is_admin() || add_filter( 'dynamic_sidebar_params', 'hamburg_widget_classes' );

/**
 * Add classes for widgets with counters or dropdowns.
 *
 * @param  array $params
 * @return array
 */
function hamburg_widget_classes( $params ) {

	global $wp_registered_widgets;

	$classes     = array();
	$instance_id = $params[ 1 ][ 'number' ];
	$widget_id   = $params[ 0 ][ 'widget_id' ];
	// The class handling the widget.
	$settings    = hamburg_widget_settings(
		$wp_registered_widgets[ $widget_id ]
	);

	if ( empty ( $settings[ $instance_id ] ) )
		return $params;

	if ( ! empty ( $settings[ $instance_id ][ 'dropdown' ] ) )
		$classes[] = 'widget-with-dropdown';

	if ( ! empty ( $settings[ $instance_id ][ 'count' ] ) )
		$classes[] = 'widget-with-counters';

	if ( empty ( $classes ) )
		return $params;

	$params[0]['before_widget'] = str_replace(
		'class="',
		'class="' . join( ' ', $classes ) . ' ',
		$params[0]['before_widget']
	);

	return $params;
}

/**
 * Check a widget for correct properties.
 *
 * @see    hamburg_widget_classes()
 * @param  array $widget
 * @return array
 */
function hamburg_widget_settings( Array $widget ) {

	if ( empty ( $widget[ 'callback' ] ) )
		return array();

	if ( empty ( $widget[ 'callback' ][ 0 ] ) )
		return array();

	/** @var WP_Widget $class */
	$class = $widget[ 'callback' ][ 0 ];

	if ( ! is_object( $class ) )
		return array();

	if ( ! is_callable( array ( $class, 'get_settings' ) ) )
		return array();

	return $class->get_settings();
}
<?php
/**
 * Second Checkout Form
 * Merged from form-checkout.php review-order.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version		2.1
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

define( 'WGM_CHECKOUT', TRUE );

// Get checkout object
$checkout = WC()->checkout();

// define as checkout process, to ensure correct price calculation
if ( ! defined( 'WOOCOMMERCE_CHECKOUT' ) ) define( 'WOOCOMMERCE_CHECKOUT', TRUE );

if ( ! isset( $_SESSION[ 'first_checkout_post_array' ] ) || ! $_SESSION[ 'first_checkout_post_array' ] ) {

	$message = __( 'Es wurden keine Daten übergeben. Prüfen Sie den Warenkorb.', Woocommerce_German_Market::get_textdomain() );
	echo '<p class="error">'. $message .'</a></p>';
	return;

} else {

	$message = __( 'Bitte prüfen Sie alle Daten. Schließen Sie den Vorgang dann ab.', Woocommerce_German_Market::get_textdomain() );
}

wc_add_notice( $message );

wc_print_notices();

// If checkout registration is disabled and not logged in, the user cannot checkout
if ( ! $checkout->enable_signup && ! $checkout->enable_guest_checkout && ! is_user_logged_in() ) {
	echo apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) );
	return;
}

// filter hook for include new pages inside the payment method
$get_checkout_url = apply_filters( 'woocommerce_get_checkout_url', WC()->cart->get_checkout_url() ); ?>

<form name="checkout" method="post" class="checkout wgm-second-checkout" action="<?php echo esc_url( $get_checkout_url ); ?>">

	<?php if ( sizeof( $checkout->checkout_fields ) > 0 ) : ?>

		<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

		<div class="col2-set" id="customer_details">

			<div class="col-1">

				<?php WGM_Template::second_checkout_form_billing(); ?>

			</div>

			<?php if( WGM_Template::should_be_shipping_to_shippingadress() ): ?>
				<div class="col-2">
					<?php WGM_Template::second_checkout_form_shipping(); ?>
				</div>
			<?php endif; ?>

		</div>

		<?php do_action( 'woocommerce_checkout_after_customer_details' );

		$out = WGM_Template::checkout_readonly_field(
			'order_comments',
			array(
				'type'		  => 'textarea',
				'class'		  => array( 'notes' ),
				'name'		  => 'order_comments',
				'label'		  => __( 'Order Notes', 'woocommerce' ),
				'placeholder' => __( 'Notes about your order.', 'woocommerce' )
			)
		);

		if( $out ) {
			echo '<div class="wgm-second-checkout-user-note checkout_hints">';

			echo '<h3>' . __( 'Notizen/Kommentare', Woocommerce_German_Market::get_textdomain() ) . '</h3>';

			if ( is_array( $out ) ) {
				echo '<p><kbd>' . $out[0] . '</kbd></p>';
				$hidden_fields[] = $out[1];
			}

			echo '</div>';

			if ( is_array( $out ) ) {
				// print the hidden fields
				echo implode( '', $hidden_fields );
			}
		}

		if ( isset( $_SESSION[ 'first_checkout_post_array' ][ 'payment_method' ] )  ) :
		?>
			<h3><?php _e( 'Zahlungsmethode', Woocommerce_German_Market::get_textdomain() ) ?></h3>
			<?php
			$available_gateways = WC()->payment_gateways->get_available_payment_gateways();
			$gateway = $available_gateways[ $_SESSION[ 'first_checkout_post_array' ][ 'payment_method' ] ];
			?>
			<p id="payment_method"><?php echo apply_filters( 'woocommerce_gateway_icon', $gateway->get_icon(), $gateway->id ); ?>&#160;&#160;&#160;<strong><?php echo $gateway->title; ?></strong></p>
		<?php
		endif;


		$last_hint = get_option( 'woocommerce_de_last_checkout_hints' );
		if( $last_hint && trim( $last_hint ) != '' ) :

		?>

		<div class="checkout_hints">
			<h3><?php _e( 'Hinweis', Woocommerce_German_Market::get_textdomain() ); ?></h3>
			<?php echo $last_hint; ?>
		</div>
		<span class="wgm-break"></span>
		<?php

		endif;
	endif;
	?>
		<h3 id="order_review_heading"><?php _e( 'Your order', 'woocommerce' ); ?></h3>

	<?php

	do_action( 'woocommerce_after_checkout_form', $checkout );

	// copied from woocommerce core ( woocommerce-ajax.php ), important to update values
	if ( isset( $_SESSION[ 'first_checkout_post_array' ]['shipping_method']) ) $_SESSION['_chosen_shipping_method'] = $_SESSION[ 'first_checkout_post_array' ][ 'shipping_method' ];
	if ( isset( $_SESSION[ 'first_checkout_post_array' ]['country'] ) ) WC()->customer->set_country( $_SESSION[ 'first_checkout_post_array' ]['country'] );
	if ( isset( $_SESSION[ 'first_checkout_post_array' ]['state']) ) WC()->customer->set_state( $_SESSION[ 'first_checkout_post_array' ]['state'] );
	if ( isset( $_SESSION[ 'first_checkout_post_array' ]['postcode'] ) ) WC()->customer->set_postcode( $_SESSION[ 'first_checkout_post_array' ]['postcode'] );

	if ( isset( $_SESSION[ 'first_checkout_post_array' ]['s_country'] ) ) WC()->customer->set_shipping_country( $_SESSION[ 'first_checkout_post_array' ]['s_country'] );
	if ( isset( $_SESSION[ 'first_checkout_post_array' ]['s_state']) ) WC()->customer->set_shipping_state( $_SESSION[ 'first_checkout_post_array' ]['s_state'] );
	if ( isset( $_SESSION[ 'first_checkout_post_array' ]['s_postcode'] ) ) WC()->customer->set_shipping_postcode( $_SESSION[ 'first_checkout_post_array' ]['s_postcode'] );

	WC()->cart->calculate_totals();

	/**
	 * Copied Review order form
	 *
	 * @author 		WooThemes
	 * @package 	WooCommerce/Templates
	 */
	$available_methods = WC()->shipping->get_shipping_methods();
	?>
	<!-- Begin Order Review Template -->
	<div id="order_review">

		<table class="shop_table">
			<thead>
				<tr>
					<th class="product-name"><?php _e( 'Product', 'woocommerce' ); ?></th>
					<th class="product-total"><?php _e( 'Total', 'woocommerce' ); ?></th>
				</tr>
			</thead>
			<tfoot>
				<tr class="cart-subtotal">
					<th class="td"><?php _e( 'Cart Subtotal', 'woocommerce' ); ?></th>
					<td><?php echo WC()->cart->get_cart_subtotal(); ?></td>
				</tr>

				<?php

				if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) :

					do_action('woocommerce_review_order_before_shipping');
				?>
				<tr>
					<th><?php _e( 'Shipping', 'woocommerce' ); ?> </th>
					<td>
					<?php

					$packages = WC()->shipping->get_packages();

					foreach ( $packages as $i => $package ) :
						foreach( $package[ 'rates' ] as $key => $method ) :
							if( WC()->session->chosen_shipping_methods[ $i ] == $key ) :

							$metod_label_id = sprintf( 'shipping_method_%s_%s', $i, sanitize_title( $method->id ) );
							$metod_label_text = wc_cart_totals_shipping_method_label( $method );
					?>
					<span id="<?php echo $metod_label_id; ?>" class="shipping-method-label-text"><?php echo wp_kses_post( $metod_label_text ); ?></span>
					<?php
							endif;
						endforeach;
					endforeach;
					?>
					</td>
				</tr>
				<?php

					do_action('woocommerce_review_order_after_shipping');

				endif;

				foreach ( WC()->cart->get_fees() as $fee ) : ?>

					<tr class="fee fee-<?php echo $fee->id ?>">
						<th class="td"><?php echo $fee->name ?></th>
						<td><?php wc_cart_totals_fee_html( $fee ); ?></td>
					</tr>

				<?php endforeach; ?>

				<?php
					// Show the tax row if showing prices exlcusive of tax only
					if ( WC()->cart->tax_display_cart == 'excl' ) {

						$taxes = WC()->cart->get_taxes();

						if ( sizeof( $taxes ) > 0 ) {

							$has_compound_tax = FALSE;

							foreach ( $taxes as $key => $tax ) {
								if ( WC_Tax::is_compound( $key ) ) {
									$has_compound_tax = TRUE;
									continue;
								}
								?>
								<tr class="tax-rate tax-rate-<?php echo $key; ?>">
									<th class="td"><?php echo WC_Tax::get_rate_label( $key ); ?></th>
									<td><?php echo wc_price( $tax ); ?></td>
								</tr>
								<?php
							}

							if ( $has_compound_tax ) {
								?>
								<tr class="order-subtotal">
									<th class="td"><?php _e( 'Subtotal', 'woocommerce' ); ?></th>
									<td><?php echo WC()->cart->get_cart_subtotal( TRUE ); ?></td>
								</tr>
								<?php
							}

							foreach ( $taxes as $key => $tax ) {
								if ( ! WC_Tax::is_compound( $key ) )
									continue;
								?>
								<tr class="tax-rate tax-rate-<?php echo $key; ?>">
									<th class="td"><?php echo WC_Tax::get_rate_label( $key ); ?></th>
									<td><?php echo wc_price( $tax ); ?></td>
								</tr>
								<?php
							}

						} elseif ( WC()->cart->get_cart_tax() ) {
							?>
							<tr class="tax">
								<th class="td"><?php _e( 'Tax', 'woocommerce' ); ?></th>
								<td><?php echo WC()->cart->get_cart_tax(); ?></td>
							</tr>
							<?php
						}
					}
				?>

				<?php do_action( 'woocommerce_review_order_before_order_total' ); ?>

				<tr class="total">
					<th class="td"><?php _e( 'Order Total', 'woocommerce' ); ?></th>
					<td>
						<strong><?php echo WC()->cart->get_total(); ?></strong>
						<?php

							// If prices are tax inclusive, show taxes here
							if ( WC()->cart->tax_display_cart == 'incl' ) :

								$tax_string_array = array();
								$taxes = WC()->cart->get_taxes();

								if ( sizeof( $taxes ) > 0 ) {

									foreach ( $taxes as $key => $tax ) {

										$tax_string_array[] = sprintf( '%s %s', wc_price( $tax ), WC_Tax::get_rate_label( $key ) );

									}

								} elseif ( WC()->cart->get_cart_tax() ) {

									$tax_string_array[] = sprintf( '%s tax', wc_price( $tax ) );

								}

								if ( ! empty( $tax_string_array ) ) :
									?><small class="includes_tax"><?php printf( __( '(Enthält %s)', Woocommerce_German_Market::get_textdomain() ), implode( ', ', $tax_string_array ) ); ?></small><?php
								endif;

							endif; // WC()->cart->tax_display_cart == 'incl' )
						?>
					</td>
				</tr>

				<?php do_action( 'woocommerce_review_order_after_order_total' ); ?>

			</tfoot>
			<tbody>
				<?php
				do_action( 'woocommerce_review_order_before_cart_contents' );

				if ( sizeof( WC()->cart->get_cart() ) > 0 ) :
					foreach ( WC()->cart->get_cart() as $item_id => $values ) :
						$_product = $values['data'];
						if ( $_product->exists() && $values['quantity'] > 0 ) :
							echo '
								<tr class="' . esc_attr( apply_filters('woocommerce_cart_table_item_class', 'checkout_table_item', $values, $item_id ) ) . '">
									<td class="product-name">' . $_product->get_title() . ' <strong class="product-quantity">&times; ' . $values['quantity'] . '</strong>' . WC()->cart->get_item_data( $values );
									if ( get_option( 'woocommerce_de_show_show_short_desc' ) == 'on' ) {
										echo '<span class="wgm-break"></span> <span class="product-desc">'  . strip_tags( apply_filters( 'woocommerce_short_description', $_product->post->post_excerpt ) ) . '</span>';
									}

									$prerequisites = get_post_meta( $_product->id, 'product_function_desc_textarea', TRUE );

									if( ( $_product->is_virtual() || $_product->is_downloadable() ) && $prerequisites != FALSE ){
										echo '<span class="wgm-break"></span><span class="wgm-product-prerequisites">' . $prerequisites . '</span>';
									}

									echo '</td>
									<td class="product-total">' . apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $values['quantity'] ), $values, $item_id ) . '</td>
								</tr>';
						endif;
					endforeach;
				endif;

				do_action( 'woocommerce_review_order_after_cart_contents' );
				?>
			</tbody>
		</table>

		<div class="form-row place-order wgm-place-order">

			<!-- End Order Review Template -->

			<input type="submit" class="button wgm-go-back-button" name="woocommerce_checkout_update_totals" id="place_order" value="<?php _e( 'Zurück', Woocommerce_German_Market::get_textdomain() ) ?>" />
			<input type="submit" class="button alt checkout-button wgm-place-order" name="woocommerce_checkout_place_order" id="place_order" value="<?php echo apply_filters( 'woocommerce_de_buy_button_text', __( 'Kaufen', Woocommerce_German_Market::get_textdomain() ) ); ?>" />
			<?php
				// correct the referer
				$_SESSION[ 'first_checkout_post_array' ][ '_wp_http_referer' ] = $_SERVER['REQUEST_URI'];
				$_SESSION[ 'first_checkout_post_array' ][ 'widerruf' ] = '1';
				WGM_Template::print_hidden_fields( $_SESSION[ 'first_checkout_post_array' ], array_keys($_SESSION[ 'first_checkout_post_array' ] ) );
			?>

		</div>

		<div class="clear"></div>

	</div>
	</form>
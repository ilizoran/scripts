<?php
/**
 * Fallback file for missing specialized template files.
 *
 * @package    Hamburg
 * @subpackage Templates
 */

get_header();
$full_width = ! is_active_sidebar( 'sidebar-1' ) ? ' full-width' : '';
?>
	<div class="site-main">
		<div class="row">
			<div id="primary" class="content-area<?php echo $full_width; ?>">
				<main id="content" class="site-content" role="main">
				<?php

				/* Loop starts here. */
				while ( have_posts() ) :
					the_post();

					/* Include a template part specific to the Post Format. */
					get_template_part( 'parts/content', get_post_format() );

				/* Loop ends here. */
				endwhile;

				/* Include query pagination. */
				get_template_part( 'parts/pagination', 'site' );
				?>
				</main>
			</div>
			<?php

			/* We skip sidebar.php and load our sidebar templates directly. */
			get_template_part( 'parts/widgets', 'secondary' );

			/* Upwards link. */
			get_template_part( 'parts/navigation', 'up' );
			?>
		</div>
	</div>

<?php

/*
 * Check footer.php for the custom theme hook to edit theme info and
 * parts/widgets-footer.php to modify widget output in the footer.
 */
get_footer();
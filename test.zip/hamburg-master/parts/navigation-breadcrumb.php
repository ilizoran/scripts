<?php
/**
 * Show the breadcrumb navigation.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>
	<div class="site-breadcrumb navbar">
		<nav id="breadcrumb">
			<ul class="breadcrumb">
				<li class="breadcrumb-title">
					<span><?php
					_ex(
						'You are here:',
						'Breadcrumb title',
						'theme_hamburg_textdomain'
					);
					?></span>
				</li>
				<?php hamburg_breadcrumb(); ?>
			</ul>
		</nav>
	</div>
<?php
/**
 * Render post content
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>
	<div class="entry-content">
		<?php

		 /**
		  * The beef.
		  *
		  * This is where post content is happening, surprisingly.
		  */
		 the_content(
		 	_x(
		 		'Continue&#160;reading&#160;&#8230;',
		 		'More link text',
		 		'theme_hamburg_textdomain'
		 	)
		 );

		/**
		 * The knife.
		 *
		 * This is where post content can optionally be sliced
		 * into pages with the <!--nextpage--> tag.
		 */
		wp_link_pages(
			array(
				'before' => '<nav class="page-link">'
					. _x(
						'<span>Pages:</span>',
						'Prefix for content pagination',
						'theme_hamburg_textdomain'
					),
				'after'  => '</nav>'
			)
		);
		?>
	</div>
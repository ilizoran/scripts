<?php
/**
 * Default content renderer.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>

	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="entry">
			<?php

			// Include featured image.
			get_template_part( 'parts/entry', 'image' );

			// Include entry header.
			get_template_part( 'parts/entry', 'header' );

			// Post meta data.
			get_template_part( 'parts/entry', 'header-meta' );

			// Main post content.
			get_template_part( 'parts/entry', 'content' );
			?>
		</div>
	</article>
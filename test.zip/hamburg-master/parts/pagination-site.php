<?php
/**
 * Pagination for archive pages.
 *
 * Wrapping this into a template tag might seem rediculous
 * until you need to add markup around it for whatever reason.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>
	<nav class="pagination" role="navigation">
		<?php echo hamburg_posts_pagination(); ?>
	</nav>
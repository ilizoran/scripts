<?php
/**
 * Post meta data
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

/* Social sharing links. */
echo apply_filters(
	'hamburg_entry_social_sharing',
	hamburg_social_sharing(
		array(
			'before' => '<div class="social-sharing row"><aside class="social-sharing-links">',
			'after'	 => '</aside></div>',
		)
	)
);

if ( 'post' !== get_post_type() )
	return;

/*
 * Post tags.
 *
 * The wrapping footer element resides in function parameters
 * to avoid emtpy HTML if no tags are set for a post.
 */
the_tags(
	_x(
		'<footer class="entry-meta"><span class="tag-links"><span class="entry-utility-prep">Tagged </span>',
		'Prefix tag links',
		'theme_hamburg_textdomain'
	),
	' ',
	'</span></footer>'
);
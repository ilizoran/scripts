<?php
/**
 * Navigation between post attachments.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

global $attachments;

if ( ! count( $attachments ) > 1 )
	return;
?>
			<nav class="image-navigation posts-navigation" role="navigation">
				<span class="next-image">
				<?php
				next_image_link(
					FALSE,
					_x(
						'Next image <span>&#8250;</span>',
						 'Image attachment navigation',
						 'theme_hamburg_textdomain'
					)
				);
				?>
				</span>
				<span class="previous-image">
				<?php
				previous_image_link(
					FALSE,
					_x(
						'<span>&#8249;</span> Previous image',
						'Image attachment navigation',
						'theme_hamburg_textdomain'
					)
				);
				?>
				</span>
				<span class="back-to-post">
					<a href="<?php echo get_permalink( $post->post_parent ); ?>">
					<?php
					_ex(
							'Go back to post',
							'Image attachment navigation',
							'theme_hamburg_textdomain'
						);
					?>
					</a>
				</span>
			</nav>

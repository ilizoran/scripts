<?php
/**
 * Top banner aka The Slider.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

if ( ! is_active_sidebar( 'banner' ) )
	return;
?>
	<div id="banner" class="site-main">
		<div class="row">
		<?php

		/*
		 * If you’re looking for the slider from our theme demo,
		 * put this in a text widget into the Banner widget area in
		 * /wp-admin/widgets.php and fill in your own images and URLs.
		 *
		 * <div id="banner-slider" class="flexslider flex-slider">
		 * <ul class="slides">
		 * <li><a href="#"><img src="http://placehold.it/1024x300/db4b39/ffffff&text=Banner+1" title="Title" alt="Alt"></a></li>
		 * <li><a href="#"><img src="http://placehold.it/1024x300/2cc2e1/ffffff&text=Banner+2" title="Title" alt="Alt"></a></li>
		 * <li><a href="#"><img src="http://placehold.it/1024x300/db4b39/ffffff&text=Banner+3" title="Title" alt="Alt"></a></li>
		 * <li><a href="#"><img src="http://placehold.it/1024x300/2cc2e1/ffffff&text=Banner+4" title="Title" alt="Alt"></a></li>
		 * </ul>
		 * </div>
		 */
		dynamic_sidebar( 'banner' );
		?>
		</div>
	</div>
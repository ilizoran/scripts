<?php
/**
 * Back-to-top navigation.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

/* This has been animated with jQuery, check assets/js/hamburg.js. */
?>
	<nav class="backtotop">
		<a href="#hh" tabindex="-1">
			<span class="icon-double-angle-up fa-angle-double-up">
				<?php
				_ex(
					'Take me higher',
					'Back to top link at the bottom',
					'theme_hamburg_textdomain'
				);
				?>
			</span>
		</a>
	</nav>
<?php
/**
 * Render 404 page.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>
	<article class="post no-results not-found">
		<header class="entry-header">
			<h1 class="entry-title">
			<?php
			echo _x(
					'Apologies, nothing found here.',
					'No-results template heading',
					'theme_hamburg_textdomain'
					);
			?>
			</h1>
		</header>

		<div class="entry-content">
			<?php

			/* Default widgets. */
			if ( ! dynamic_sidebar( 'no-results' ) ) :

				echo "<p>";
				echo _x(
						'No posts or pages found which match your selection.',
						'No-results template text (not only 404, but also searches!)',
						'theme_hamburg_textdomain'
						);

				echo "</p>\n" ;

				if ( header_image() )
					the_widget( 'WP_Widget_Search' );

				the_widget( 'WP_Widget_Tag_Cloud' );

				the_widget(
					'WP_Widget_Archives',
					array(
						'title' => _x(
							'Monthly Archives',
							'Archives widget title',
							'theme_hamburg_textdomain'
							),
						'count' => 1
					)
				);

				the_widget(
					'WP_Widget_Recent_Posts',
					array(
						'title' => sprintf(
							_x(
								'%s Recent Posts',
								'%s = number of posts shown',
								'theme_hamburg_textdomain'
							),
							20
						),
						'number' => 20
					)
				);
			endif;
			?>
		</div>
	</article>
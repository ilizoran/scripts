<?php
/**
 * Global header.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
$header_image = get_header_image();
$logo         = hamburg_get_logo_url();

/* Bail early if there is nothing to do. */
if ( FALSE == $header_image && '' == $logo && FALSE == display_header_text() )
	return;

$esc_blogname = esc_attr( get_bloginfo( 'name' ) );

?>
	<div class="site-header <?php print $header_image ? 'has' : 'no'; ?>-header-image">
		<div class="row">
		<?php

		/* Show header image OR logo. */
		if ( $header_image ) :
		?>
			<header class="branding" role="banner">
				<h1 class="site-title">
					<a href="<?php
						echo esc_url( home_url( '/' ) )
						?>" title="<?php
						echo $esc_blogname;
					?>">
						<img src="<?php
							echo esc_url( $header_image );
							?>" alt="<?php
							echo $esc_blogname;
							?>">
					</a>
				</h1>
				<?php
				if ( ! display_header_text() ) :
				?>
				<p class="site-description"><?php
					bloginfo( 'description' );
				?></p>
				<?php
				endif;
				?>
			</header>
		<?php
		elseif ( '' !== $logo ) :
		?>
			<header class="branding" role="banner">
				<h1 class="site-title">
					<a href="<?php
						echo esc_url( home_url( '/' ) )
						?>" title="<?php
						echo $esc_blogname;
					?>">
						<img src="<?php
						echo esc_url( $logo );
						?>" alt="<?php
						echo $esc_blogname;
						?>">
					</a>
				</h1>
				<p class="site-description"><?php bloginfo( 'description' ); ?></p>
			</header>
		<?php

			print hamburg_get_contact_data();

			if ( hamburg_is_wc() && function_exists( 'get_product_search_form' ) ) :
				get_product_search_form();
			else:
				get_search_form();
			endif;

		endif; // ( ! empty( $header_image ) )


	/*
	 * WooCommerce side-wide store notice (i.e. for demo shop).
	 * Only active if WooCommerce is installed and store notice option is set.
	 */
	if( hamburg_is_wc() )
		echo woocommerce_demo_store();
		?>
		</div>
	</div>

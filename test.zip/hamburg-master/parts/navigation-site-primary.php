<?php
/**
 * The primary site navigation template.
 *
 * This is where all kinds of pages go.
 * The primary navigation collapses on smaller screens
 * and can be toggled into visibility via a button.
 *
 * There also is an optional secondary navigation ("Category Menu").
 * Use it for fun and profit!
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

/*
 * Return early if no content is defined.
 *
 * We've altered body_class() in functions.php with hamburg_body_classes()
 * to include class names for custom menus that have been assigned to any
 * predefined menu location. So we just need to check if those class names
 * are present in the body_class() array.
 */
if( ! in_array( 'menu-primary-active', get_body_class() ) &&
	( in_array( 'menu-meta-primary-active', get_body_class() ) ||
	  in_array( 'menu-meta-secondary-active', get_body_class() ) ) )
	return;
?>

	<div class="site-navigation navbar">
		<a href="#content" class="visually-hidden skip-link" title="<?php
			esc_attr_e( 'Skip to content', 'theme_hamburg_textdomain' );
			?>"><?php
			_e( 'Skip to content', 'theme_hamburg_textdomain' );
		?></a>
		<?php
		$mini_cart = '';
		if ( hamburg_is_wc() && function_exists( 'hamburg_wc_mini_cart' ) ) :

			$mini_cart = hamburg_wc_mini_cart(
				array(
					'before'    => '<div class="mini-cart">
									<a href="' . WC()->cart->get_cart_url() . '">',
					'after'     => '</a></div>',
					'separator' => '<i class="icon-shopping-cart fa-shopping-cart"></i>'
				)
			);
		endif;

		/*
		 * The primary site navigation.
		 *
		 * If no custom menu is assigned, logged in admins see an alert message suggesting to create a menu.
		 */
		wp_nav_menu(
			array(
				'theme_location'=> 'primary',
				'container'     => FALSE,
				'fallback_cb'   => 'hamburg_nav_menu_fallback',
				'items_wrap'    => '
				<nav class="row site-nav-primary toggle-nav" role="navigation">
				<button class="menu-toggle" title="' .
				_x( 'Toggle Menu', 'Main menu toggle button title attribute', 'theme_hamburg_textdomain' ) .
				'"><span>' .
				_x( 'Menu', 'Main menu toggle button', 'theme_hamburg_textdomain' ) .
				'</span></button>' .
				'<div id="mini-cart-wrapper">' . $mini_cart . '</div>' .
				'<ul id="%1$s" class="%2$s">
				%3$s
				</ul>
				</nav>'
			)
		);
		?>
	</div>
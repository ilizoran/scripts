<?php
/**
 * Pagination for comments.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>
	<nav class="pagination" role="navigation">
		<?php
 		paginate_comments_links(
 			array(
				'mid_size' 	=> 2,
				'type' 		=> 'list',
				'prev_text'	=> sprintf(
					'<span class="icon-angle-left fa-angle-left"><span class="visually-hidden">%s</span></span>',
					__( 'Previous', 'theme_hamburg_textdomain' )
					),
				'next_text'	=> sprintf(
					'<span class="icon-angle-right fa-angle-right"><span class="visually-hidden">%s</span></span>',
					__( 'Next', 'theme_hamburg_textdomain' )
					),
 			)
 		);
		?>
	</nav>
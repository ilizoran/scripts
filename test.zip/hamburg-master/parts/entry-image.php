<?php
/**
 * Post thumbnail for a post
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

/* Bail early if no featured image is available. */
if ( ! has_post_thumbnail() )
	return;
?>
	<figure class="entry-image">
		<?php if( ! is_singular() ) : ?>
		<a href="<?php the_permalink() ?>" title="<?php echo esc_attr( the_title() ) ?>" rel="bookmark">
		<?php
		endif;

		the_post_thumbnail(
			hamburg_featured_image_size(
				(int) get_post_thumbnail_id()
			)
		);

		if( ! is_singular() ) :
		?>
		</a>
		<?php endif; ?>
	</figure>
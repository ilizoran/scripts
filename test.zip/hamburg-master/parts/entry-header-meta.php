<?php
/**
 * Post meta data
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

if ( is_page() )
	return;
?>
<section class="entry-meta">
	<?php

	/* Hide category and tag text for pages on search. */
	if ( 'post' == get_post_type() ) :
	?>
	<span class="cat-links">
		<?php

		/* Post categories. */
		printf(
			_x(
				'<span class="entry-utility-prep">Posted in: </span> %s',
				'Prefix category links, %s = categroy list',
				'theme_hamburg_textdomain'
			),
			hamburg_get_the_category( get_the_ID() )
		);
		?>
	</span>
	<?php

	endif;

	/* Post time */
	printf( '<span class="date"><time class="entry-date updated" datetime="%1$s"><a href="%2$s">%3$s</a></time></span>',
		esc_attr( get_the_date( 'c' ) ),
		get_permalink(),
		get_the_date()
	);

	/* Post type 'post' only */
	if ( 'post' == get_post_type() ) :
		printf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>',
			esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
			esc_attr( sprintf( __( 'View all posts by %s', 'theme_hamburg_textdomain' ), get_the_author() ) ),
			esc_html( get_the_author() )
		);
	endif;

	if ( comments_open() ) : ?>
		<span class="comments-link">
		<?php
		comments_popup_link(
			__( '<span class="leave-reply">Leave a reply</span>', 'theme_hamburg_textdomain' ),
			__( '1 Reply', 'theme_hamburg_textdomain' ),
			__( '% Replies', 'theme_hamburg_textdomain' )
		);
		?>
		</span>
	<?php

	endif;

	edit_post_link(
		_x( 'Edit', 'Edit link', 'theme_hamburg_textdomain' ),
		'<span class="edit-link">',
		'</span>'
	);
	?>
</section>
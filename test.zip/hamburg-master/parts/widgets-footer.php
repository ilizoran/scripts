<?php
/**
 * Footer widgets.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

if ( ! is_active_sidebar( 'footer-1' ) &&
	! is_active_sidebar( 'footer-2' ) &&
	! is_active_sidebar( 'footer-3' ) )
	return;
?>
	<section id="widgets-footer" class="row" role="complementary">
		<?php

		foreach ( array ( 1, 2, 3 ) as $num ) :

			if ( is_active_sidebar( "footer-$num" ) ) :
			?>
				<div class="widget-area widgets-footer-<?php echo $num; ?>">
					<?php dynamic_sidebar( "footer-$num" ); ?>
				</div>
				<?php
			endif;

		endforeach;
		?>
	</section>

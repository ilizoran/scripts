<?php
/**
 * The default sidebar.
 *
 * This is where all the widgets dwell.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

if ( ! is_active_sidebar( 'sidebar-1' ) )
	return;

/*
 * Make sure this does not display on ANY of the WooCommerce shop pages,
 * nor on WooCommerce German Market’s second checkout page.
 */
if ( hamburg_is_woo() )
	return;
?>
	<section id="secondary" class="widget-area sidebar" role="complementary">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</section>
<?php
/**
 * The secondary site navigation ("Category Menu").
 *
 * This is optional, but only for blog pages.
 * It is hidden on WooCommerce shop pages!
 * It only displays first-level menu items
 * and does not feature a toggle button on smaller screens, so
 * it stays expanded all the time. You might want place your site's
 * main categories here. Whatever you do, treat this with some thought.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
$body_classes = get_body_class();
if (
	in_array( 'woocommerce', $body_classes ) ||
	in_array( 'woocommerce-page', $body_classes ) ||
	is_page()
	) :
	return;
endif;
?>
	<div class="site-navigation navbar">
		<?php
		wp_nav_menu(
			array(
				'theme_location'=> 'secondary',
				'container'     => FALSE,
				'depth'         => 1,
				'fallback_cb'   => 'hamburg_nav_menu_fallback',
				'items_wrap'    => '<nav class="row site-nav-secondary" role="navigation">
				<ul id="%1$s" class="%2$s">
				%3$s
				<li class="menu-item-rss">
				<a href="' . get_bloginfo( 'rss2_url' ) . '">
				<i class="icon-rss fa-rss"></i>
				<span class="visually-hidden">RSS</span>
				</a>
				</li>
				</ul>
				</nav>
				'
			)
		);
		?>
	</div>
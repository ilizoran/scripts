<?php
/**
 * Site meta menus.
 *
 * This is for meta items such as language selection,
 * Contact, Terms, FAQ and About pages and access to
 * user profiles.
 *
 * The meta navbar is fixed to the top of the page
 * and does not collapse on smaller screens.
 * It is up to admins to use its space wisely.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

/*
 * Return early if no content is defined.
 *
 * We've altered body_class() in functions.php with hamburg_body_classes()
 * to include class names for custom menus that have been assigned to any
 * predefined menu location. So we just need to check if those class names
 * are present in the body_class() array.
 * Also checking if custom header text has been activated.
 *
 */
if( ! in_array( 'menu-meta-primary-active', get_body_class() ) &&
	! in_array( 'menu-meta-secondary-active', get_body_class() ) &&
	! display_header_text() )
	return;

?>
	<div class="navbar fixed-top">
		<div class="row">
		<?php

		/* Custom header text will orveride menu! */
		if ( display_header_text() ) :
		?>
			<div class="branding">
				<h1 class="site-title">
					<a href="<?php echo
						esc_url( home_url( '/' ) );
						?>" title="<?php
						echo esc_attr( get_bloginfo( 'name' ) );
						?>">
						<?php bloginfo( 'name' ) ?>
					</a>
				</h1>
				<p class="site-description"><?php bloginfo( 'description' ); ?></p>
			</div>
		<?php

		/* Multilingual Press language selection will also orveride menu! */
		elseif ( function_exists( 'mlp_show_linked_elements' ) ) :
			mlp_show_linked_elements(
				array(
					'link_text' => 'text',
					'show_current_blog' => TRUE
					) );

		/* Primary Meta Menu. */
		else :
			wp_nav_menu(
				array(
					'theme_location'=> 'meta-primary',
					'container' 	=> false,
					'fallback_cb'	=> 'hamburg_nav_menu_fallback',
					'items_wrap' 	=> '
					<nav class="site-meta-nav site-meta-nav-primary" role="navigation">
					<ul id="%1$s" class="%2$s">
					%3$s
					</ul>
					</nav>
					'
				)
			);

		endif;

		/* Secondary Meta Menu. */
		wp_nav_menu(
			array(
				'theme_location'=> 'meta-secondary',
				'container' 	=> false,
				'fallback_cb'	=> 'hamburg_nav_menu_fallback',
				'items_wrap' 	=> '
				<button class="menu-toggle" title="' .
				_x( 'Toggle Menu', 'Main menu toggle button title attribute', 'theme_hamburg_textdomain' ) .
				'"><span>' .
				_x( 'Menu', 'Main menu toggle button', 'theme_hamburg_textdomain' ) .
				'</span></button>
				<nav class="site-meta-nav site-meta-nav-secondary toggle-nav" role="navigation">
				<ul id="%1$s" class="%2$s">
				%3$s
				</ul>
				</nav>
				'
			)
		);
		?>
		</div>
	</div>
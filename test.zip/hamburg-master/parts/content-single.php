<?php
/**
 * Post content on single posts.
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="entry"> <?php // = wrapper ?>
			<?php

			// Include featured image.
			get_template_part( 'parts/entry', 'image' );

			// Include entry header.
			get_template_part( 'parts/entry', 'header' );

			// Site meta menus.
			get_template_part( 'parts/entry', 'header-meta' );

			// The real content.
			get_template_part( 'parts/entry', 'content' );

			// post meta data.
			get_template_part( 'parts/entry', 'footer-meta' );

			// post author meta data.
			get_template_part( 'parts/entry', 'author-meta' );
			?>
		</div>
	</article>
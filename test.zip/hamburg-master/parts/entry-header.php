<?php
/**
 * Entry header.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>
	<header class="entry-header">
		<h1 class="entry-title">
			<?php

			if ( ! is_singular() ) : // archives
			?>
			<a href="<?php the_permalink() ?>" title="<?php echo esc_attr( the_title() ) ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
			<?php

			else :
				the_title(); // no links to the currently seen page
			endif;
			?>
		</h1>
	</header>
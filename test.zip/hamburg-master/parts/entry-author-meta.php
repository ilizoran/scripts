<?php
/**
 * Post author meta data
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

/* Requires autor biography. */
if ( 'post' !== get_post_type() || '' == get_the_author_meta( 'description' ) )
	return;

?>
	<section class="entry-author">
		<?php echo get_avatar( get_the_author_meta( 'user_email' ) ); ?>
		<div class="author-description">
			<h4 class="posted-by">
			<?php
			printf(
				'<span class="author-by entry-utility-prep">%1$s </span><cite class="fn"><a href="%2$s" title="%3$s" rel="author">%4$s</a></cite>',
				_x( 'Posted by', 'Author info box heading prefix', 'theme_hamburg_textdomain' ),
				esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
				esc_attr( get_the_author_meta( 'display_name' ) ),
				get_the_author_meta( 'display_name' )
			);
			?>
			</h4>
			<?php echo wpautop( get_the_author_meta( 'description' ) ); ?>
		</div>
	</section>
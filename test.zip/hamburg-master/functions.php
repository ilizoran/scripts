<?php
/**
 * Hamburg theme functions.
 */

if ( is_admin() )
	add_action( 'wp_loaded', 'hamburg_auto_updater' );

/**
 * Theme setup function.
 */
add_action( 'after_setup_theme', 'hamburg_setup', 0 );

function hamburg_setup() {

	if ( ! interface_exists( 'Inpsyde_Property_List_Interface' ) )
		require_once 'inc/inpsyde-theme-base/interface-Inpsyde_Property_List_Interface.php';

	if ( ! class_exists( 'Inpsyde_Property_List' ) )
		require_once 'inc/inpsyde-theme-base/class-Inpsyde_Property_List.php';

	require_once 'inc/inpsyde-theme-base/class-Inpsyde_Theme_Base.php';
	require_once 'inc/class-Hamburg_Theme_Config.php';
	require_once 'inc/inpsyde-theme-base/class-Inpsyde_Enqueues.php';

	$config = new Hamburg_Theme_Config;

	// to stop all further setup, add a filter like this:
	// add_filter( 'hamburg_config', '__return_null' );
	$config = apply_filters( 'hamburg_config', $config );

	if ( is_null( $config ) )
		return;

	// No further changes on the main configuration.
	$config->freeze();

	hamburg( new Inpsyde_Theme_Base( $config ) );
	hamburg( new Inpsyde_Enqueues( $config ) );
}


/**
 * Access Theme Base instance.
 *
 * @param  Inpsyde_Theme_Base $theme_base Fill static internal cache with an instance.
 * @return Inpsyde_Theme_Base
 */
function hamburg( $theme_base = NULL ) {

	static $instance;

	if ( is_a( $theme_base, 'Inpsyde_Theme_Base' ) )
		$instance = $theme_base;

	return $instance;
}

add_action( 'init', 'hamburg_customize_register' );

/**
 * Call customizer class.
 *
 * @wp-hook init
 * @return  void
 */
function hamburg_customize_register() {

	hamburg_load_textdomain();

	require_once get_template_directory() . '/inc/class-Hamburg_Customize.php';
	new Hamburg_Customize;
}

/**
 * Return the logo URL if there is one and we are not in the customizer.
 *
 * @return string
 */
function hamburg_get_logo_url() {

	return get_theme_mod( 'logo_url', '' );
}

/**
 * Get contact data set in customizer.
 *
 * @return string
 */
function hamburg_get_contact_data() {

	$text = trim( get_theme_mod( 'contact_text' ) );

	if ( '' === $text )
		return '';

	$parts = explode( "\n", $text, 2 );
	$parts = array_map( 'esc_html', $parts );

	if ( 1 === count( $parts ) )
		return '<address class="contact">
			   <span class="label">'
			. __( 'Phone', 'theme_hamburg_textdomain' )
			. '<span class="phone">'
			. $parts[ 0 ]
			. '</span></span></address>';

	return '<address class="contact">
		   <span class="label">'
		. __( 'Phone', 'theme_hamburg_textdomain' )
		. '<span class="phone">'
		. $parts[ 0 ]
		. '</span></span>
		   <span class="label">'
		. __( 'E-Mail', 'theme_hamburg_textdomain' )
		. '<span class="email">'
		. $parts[ 1 ]
		. '</span></span></address>';
}

/**
 * Theme setup.
 *
 * Functions in inc/setup.php register theme support for
 * translation, feed links, post images, custom menus etc.
 *
 */
require_once( 'inc/setup.php' );

/**
 * Add theme widget areas.
 *
 * The function in inc/widgets.php is pretty long.
 * It just seemed more convenient to the eye to put it
 * into a seperate file and include it from there.
 *
 */
require_once( 'inc/widgets.php' );

/**
 * Add custom header.
 *
 */
require_once( 'inc/custom-header.php' );

/**
 * @WooCommerce
 *
 */
if ( file_exists( get_template_directory() . '/inc/woocommerce.php' ) )
	require_once( 'inc/woocommerce.php' );

/**
 * @WooCommerce_German_Market
 *
 */
if ( file_exists( get_template_directory() . '/inc/woocommerce-german-market.php' ) )
	require_once( 'inc/woocommerce-german-market.php' );

add_filter( 'body_class', 'hamburg_body_classes' );
/**
 * Add extra class names to element 'body'.
 *
 * @wp-hook body_class
 * @global  $wp_registered_sidebars
 * @param   array $classes
 * @return  array
 */
function hamburg_body_classes( $classes ) {

	global $wp_registered_sidebars;
	// Layout classes
	if ( is_singular() )
		$classes[] = 'sidebar-content-sidebar';
	else
		$classes[] = 'content-sidebar-sidebar';

	// Sidebar classes
	foreach ( $wp_registered_sidebars as $id => $args ) {
		if ( is_active_sidebar( $id ) )
			$classes[] = "widget-area-" . esc_attr( $id ) . "-active";
	}

	// Menu classes
	$menu_locations = get_nav_menu_locations();

	if ( ! empty ( $menu_locations ) ) {
		foreach ( $menu_locations as $location => $has_items ) {
			if ( 0 !== $menu_locations[ $location ] )
				$classes[] = "menu-" . esc_attr( $location ) . "-active";
		}
	}

	// Class for blogs with more than 1 published author
	if ( is_multi_author() )
		$classes[] = 'group-blog';

	return $classes;
}

/**
 * Get extra class for content area.
 *
 * @return string
 */
function hamburg_content_area_class() {

	// Return empty string by default
	return esc_attr( apply_filters( 'hamburg_content_area_class', '' ) );
}

/**
 * Nav menu fallback.
 *
 * If no custom menu has been set, this displays a warning for
 * users with appropriate permissions prompting them to create
 * a custom menu via wp-admin/nav-menus.php.
 *
 * @param  array $args
 * @return void
 */
function hamburg_nav_menu_fallback( $args ) {
	global $current_user;

	// Return early if user cannot edit widgets and menus.
	if ( 'primary' !== $args['theme_location']
		|| ! is_user_logged_in()
		|| ! current_user_can( 'edit_theme_options' )
	) {
		return;
	}

	$h4 = _x(
		'Ahoy, %s!',
		'%s = current user display name',
		'theme_hamburg_textdomain'
	);
	$p = _x(
		'Please <a href="%s">create a custom menu</a> and assign it to one of the available menu locations.',
		'%s = wp-admin/nav-menus.php',
		'theme_hamburg_textdomain'
	);
?>
	<aside class="alert-success">
		<div class="row">
			<h4><?php printf( $h4, $current_user->display_name ); ?></h4>
			<p><?php  printf( $p, esc_url( admin_url( 'nav-menus.php' ) ) ); ?></p>
		</div>
	</aside>
<?php
}

/**
 * hamburg_posts_pagination function.
 *
 * Paginated posts navigation.
 * Used instead of next_posts()/previous_posts().
 * Displays an unordered list.
 *
 * $args   array
 * $query  object
 * @global $wp_query
 * @return string
 */
function hamburg_posts_pagination( $args = array(), $query = NULL ) {

	global $wp_query;

	$query = NULL !== $query ? $query : $wp_query;
	$paginated = $query->max_num_pages;

	if ( $paginated < 2 )
		return;

	// @todo Sanitize incoming args

	$default_args = array(
		'base' 		=> str_replace( 999999999, '%#%', get_pagenum_link( 999999999 ) ),
		'current' 	=> max( 1, get_query_var( 'paged' ) ),
		'format' 	=> '',
		'mid_size' 	=> 2,
		'end_size'  => 2,
		'total' 	=> absint( $query->max_num_pages ),
		'type' 		=> 'list',
		'prev_text'	=> sprintf(
						'<span class="icon-angle-left fa-angle-left"><span class="visually-hidden">%s</span></span>',
						__( 'Previous', 'theme_hamburg_textdomain' )
						),
		'next_text'	=> sprintf(
						'<span class="icon-angle-right fa-angle-right"><span class="visually-hidden">%s</span></span>',
						__( 'Next', 'theme_hamburg_textdomain' )
						),
	);

	$rtn = apply_filters( 'pre_hamburg_get_posts_pagination', FALSE, $args, $default_args );
	if ( $rtn !== FALSE )
		return $rtn;

	$args = wp_parse_args( $args, $default_args );
	$args = apply_filters( 'hamburg_get_posts_pagination_args', $args );

	$output = sprintf(
		_x(
			'<span class="label">Pages:</span> %s',
			'%s = paginate_links()',
			'theme_hamburg_textdomain'
		),
		paginate_links( $args )
	);

	return apply_filters( 'hamburg_get_posts_pagination', $output, $args );
}

/* Not used when a localized WordPress installation has set a filter in
 * their language file, like de_DE.php
 */
if ( ! has_filter( 'excerpt_more' ) )
	add_filter( 'excerpt_more', 'hamburg_excerpt_more' );

function hamburg_excerpt_more( $length ) {

	global $post;

	// hard space + […]
	$output  = '&#160;[&#8230;] ';
	$output .= '<p><a href="' . get_permalink() . '"';
	$output .= ' title="' . esc_attr( $post->title ) . '"';
	$output .= ' class="more-link">';
	$output .= _x( 'Continue&#160;reading&#160;&#8230;', 'More link text', 'theme_hamburg_textdomain' );
	$output .= '</a></p>';

	return $output;
}


/**
 * hamburg_category_breadcrumbs function.
 *
 * @param string $seperator (default: '&#187;')
 * @return void
 */
function hamburg_category_breadcrumbs( $seperator = '&#187;' ) {
	$queried   = get_queried_object()->term_id;
	$ancestors = get_ancestors($queried, 'category' );

	$ancestor_link = '';

	if ( $ancestors ) :
		sort( $ancestors );
		foreach ( $ancestors as $ancestor ) :
			$ancestor_link .= '<a class="category-ancestor" href="';
			$ancestor_link .= get_category_link( $ancestor );
			$ancestor_link .= '">';
			$ancestor_link .= get_category( $ancestor )->name;
			$ancestor_link .= '</a>';
			$ancestor_link .= $seperator;
		endforeach;
	endif;

	return $ancestor_link . '<span class="current-category">' . get_category( $queried )->name . '</span>';
}

/**
 * Featured image size.
 *
 * Calculates which of all available image sizes
 * should be used to display a featured image.
 *
 * @global $content_width
 * @param  integer $featured_image_id
 * @param  string $fallback_size (default: 'full')
 * @return string
 */
function hamburg_featured_image_size( $image_id, $fallback_size = 'full' ) {

	global $content_width;

	$intermediate_image_sizes = get_intermediate_image_sizes();
	$images_sizes             = array();

	$featured_image           = wp_get_attachment_image_src( $image_id, 'post-thumbnail' );

	foreach ( $intermediate_image_sizes as $size ) :
		if (
			get_option( "{$size}_size_w" ) >= $content_width
			&& get_option( "{$size}_size_w" ) >= (int) $featured_image[1]
			) :
			$images_sizes[ $size ] = get_option( "{$size}_size_w" );
		endif;
	endforeach;

	if ( ! $images_sizes )
		return $fallback_size;

	$images_sizes = array_keys( $images_sizes, min( $images_sizes ) );

	return (string) $images_sizes[0];
}

/**
 * hamburg_get_the_category function.
 *
 * @param mixed $post_id
 * @return void
 */
function hamburg_get_the_category( $post_id ) {

	$categories = get_the_category( $post_id );

	// Bail early.
	if ( ! $categories )
		return;

	// Single category.
	$category = $categories[0];
	$cat_link = hamburg_category_link( $category );

	// Single category link.
	if ( count( $categories ) == 1 )
		return $cat_link;

	// Multiple categories
	$output = '<ul>';
	$i      = 0;

	foreach ( $categories as $category ) :

		$cat_link = hamburg_category_link( $category );

		if ( 0 === $i )
			$output .= "<li>$cat_link<ul>";
		else
			$output .= "<li>$cat_link</li>";

		$i += 1;

	endforeach;

	$output .= '</ul></li></ul>';

	return $output;
}

/**
 * hamburg_category_link function.
 *
 * @param mixed $category_object
 * @return void
 */
function hamburg_category_link( $category_object ) {
	return '<a href="'
		. get_category_link( $category_object->term_id )
		. '" title="'
		. esc_attr(
			sprintf(
				_x(
					"View all posts in %s",
					'%s = category name',
					'theme_hamburg_textdomain'
					),
				$category_object->name
			)
		)
		. '">'
		. $category_object->cat_name
		. '</a>';
}

/**
 * Simple counter for repeating elements.
 *
 * @param  string $name
 * @return int
 */
function hamburg_counter( $name ) {

	static $counters = array ();

	if ( ! isset ( $counters[ $name ] ) )
		$counters[ $name ] = 0;

	$counters[ $name ] += 1;

	return $counters[ $name ];
}

/**
 * Featured image post classes.
 *
 * @global $post
 * @param  array $classes
 * @return array
 */
add_filter( 'post_class', 'hamburg_image_post_classes', 20 );

function hamburg_image_post_classes( $classes ) {

	global $post;

	$featured_image = get_post_thumbnail_id();

	// No featured image
	if ( ! $featured_image ) {
		$classes[] = 'no-featured-image';
		return $classes;
	}

	// Post has featured image
	$classes[] = 'has-featured-image';

	// Featured image dimensions
	$classes[] = hamburg_image_orientation( $featured_image );

	return $classes;
}

/**
 * Orientation classes for images.
 *
 * @global $post
 * @param  mixed  $id
 * @param  string $size (default: 'post_thumbnail')
 * @return string
 */
function hamburg_image_orientation( $id = 0, $size = 'post_thumbnail' ) {

	global $post;

	// Image ID
	$id = $id ? $id : get_post_thumbnail_id( $post->ID, $size );

	if( ! $id )
		return;

	// Featured image sizes
	$image = wp_get_attachment_image_src( $id, $size );

	/*
	Featured image dimensions.
	$image[1] = width
	$image[2] = height
	*/
	if ( $image[1] > $image[2] )
		return "landscape";
	elseif ( $image[1] < $image[2] )
		return "portrait";

	return "square";
}


/**
 * Breadcrumb helper function.
 *
 * @return void
 */
function hamburg_breadcrumb( $templates = '', $options = '' ) {

	$templates = wp_parse_args(
		$templates,
		array(
			'before'	=> '',
			'after'		=> '',
			'standard'	=> '<li itemscope itemtype="http://data-vocabulary.org/Breadcrumb">%s</li>',
			'current'	=> '<li class="current-breadcrumb"><span>%s</span></li>',
			'link'		=> '<a href="%s" itemprop="url"><span itemprop="title">%s</span></a>'
			)
		);

	$options = wp_parse_args(
		$options,
		array(
			'show_htfpt'	=> TRUE,
			'separator'		=> ''
		)
	);

	require_once( 'inc/class-DS_WP_Breadcrumb.php' );

	$breadcrumb = new DS_WP_Breadcrumb( $templates, $options );
}


// @link http://wordpress.stackexchange.com/a/88546/23011
add_filter('wp_list_categories','hamburg_widgets_postcount_filter');
add_filter('get_archives_link', 'hamburg_widgets_postcount_filter');

function hamburg_widgets_postcount_filter ( $variable ) {

	$variable = str_replace( '(', '<span class="post-count"> ', $variable );
	$variable = str_replace( ')', ' </span>', $variable );

	return $variable;
}

function hamburg_wc_is_woocommerce_page() {

	return in_array( 'woocommerce-page', get_body_class() );
}

/**
 * Conditional helper for WGM's 2nd checkout page.
 * Must be called within or after the_content().
 */
function hamburg_is_wgm_second_checkout() {

	if ( ! class_exists( 'Woocommerce_German_Market' ) )
		return FALSE;

	return Woocommerce_German_Market::is_wgm_checkout();
}

/**
 * WGM second checkout class.
 * Must be called within or after the_content().
 *
 */
function hamburg_wgm_wgm_second_checkout_class() {

	if ( hamburg_is_wgm_second_checkout() )
		$class = ' wgm-second-checkout';

	return $class;
}

/**
 * Social sharing links.
 *
 * @param  mixed $atts
 * @return string
 */
function hamburg_social_sharing( $atts = array() ) {

	$default_args = array(
			'before'		=> '<aside class="social-sharing-links">',
			'after'			=> '</aside>',
			'separator'		=> '',
			'icon_fb'		=> '<i class="icon-facebook fa-facebook"></i>',
			'icon_gplus'	=> '<i class="icon-google-plus fa-google-plus"></i>',
			'icon_twitter'	=> '<i class="icon-twitter fa-twitter"></i>',
			'post_id'		=> 0,
			'post_url'		=> get_permalink(),
			'post_title'	=> get_the_title()
		);

	$args = wp_parse_args( $atts, $default_args );

	$post_url	= 0 !== absint( $args['post_id'] ) ? get_permalink( $args['post_id'] ) : esc_url( $args['post_url'] );
	$user_lang	= strtok( get_locale(), '_' );
	$fb_url		= esc_url( "//www.facebook.com/sharer.php?u=$post_url&t=" . rawurlencode( $args['post_title'] ) );
	$gplus_url	= esc_url( "//plusone.google.com/_/+1/confirm?hl=$user_lang&url=$post_url" );
	$tw_url		= esc_url( "//twitter.com/share?url=$post_url" );
	$title		= _x( 'Share on %s', '%s = social network name', 'theme_hamburg_textdomain' );

	$output  = $args['before'];
	$output .= "<a class='facebook' href='$fb_url' title='"
		. sprintf( $title, 'Facebook' )
		. "' target='_blank'>" . $args['icon_fb'] . "</a>";
	$output .= $args['separator'];
	$output .= "<a class='googleplus' href='$gplus_url' title='"
		. sprintf( $title, 'Google+' )
		. "' target='_blank'>" . $args['icon_gplus'] . "</a>";
	$output .= $args['separator'];
	$output .= "<a class='twitter' href='$tw_url' title='"
		. sprintf( $title, 'Twitter' )
		. "' target='_blank'>" . $args['icon_twitter'] . "</a>";
	$output .= apply_filters(
		'hamburg_social_sharing_add_items',
		'',
		array(
			'separator'		=> $args['separator'],
			'post_id'		=> $args['post_id'],
			'post_url'		=> $post_url,
			'post_title'	=> $args['post_title']
		)
	);
	$output .= $args['after'];

	return apply_filters( 'hamburg_social_sharing', $output, $args );
}

function hamburg_social_sharing_bar( $atts = array() ) {

	echo hamburg_social_sharing( $atts );
}

/**
 * Test if we are on a WooCommerce page.
 *
 * @return bool
 */
function hamburg_is_woo() {

	return class_exists( 'WooCommerce' )
		&& (
			is_woocommerce()	  ||
			is_shop()			  ||
			is_product()		  ||
			is_product_category() ||
			is_product_tag()	  ||
			is_cart()			  ||
			is_checkout()		  ||
			is_account_page()	  ||
			hamburg_is_wgm_second_checkout() ||
			hamburg_wc_is_woocommerce_page()
		);
}

/**
 * Define global arguments for inline pagination.
 * (That <!--nextpage--> thing.)
 *
 */
add_filter( 'wp_link_pages_args', 'hamburg_link_pages_args' );
function hamburg_link_pages_args() {
	$args = array(
			'before' 			=> "<nav class='page-link'>\n" .
								   "<span class='label'>" .
								   __( 'Pages', 'default' ) .
								   ": </span>\n",
			'after' 			=> "\n</nav>\n",
			'link_before'		=> '',
			'link_after'		=> '',
			'next_or_number'	=> 'number',
			'nextpagelink'		=> '',
			'previouspagelink'	=> '',
			'pagelink'			=> '<span class="page-link-item">%</span>',
			'separator'			=> '',
			'echo' => 1
			);

	return $args;
}

/**
 * Creates a nicely formatted and more specific title element text for output
 * in head of document, based on current view.
 *
 * @param string $title Default title text for current view.
 * @param string $sep Optional separator.
 * @return string The filtered title.
 */
add_filter( 'wp_title', 'hamburg_wp_title', 10, 2 );
function hamburg_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() )
		return $title;

	// Add the site name.
	$title .= get_bloginfo( 'name' );

	// Front page title
	if( is_front_page() )
		$title = get_bloginfo( 'name' );

	// Add the site description for the post archive page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && is_home() )
		$title = "$title $sep $site_description";

	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 )
		$title = "$title $sep " . sprintf( __( 'Page %s', 'theme_hamburg_textdomain' ), max( $paged, $page ) );

	return $title;
}

/**
 * Template tag to include the banner widget area on the front page.
 *
 * @uses hamburg_slider_init()
 */
function hamburg_get_front_page_banner() {

	/**
	 * The main shop front page has its own call for
	 * the front page banner widget area, so we need
	 * to bail here if:
	 * a. this is the main shop page, or
	 * b. this is any front page AND front-page.php exists.
	 *
	 */
	if( function_exists( 'is_shop' ) )
		$is_shop_or_legacy_front_page = is_shop() || ( locate_template( 'front-page.php' ) && is_front_page() );
	else
		$is_shop_or_legacy_front_page = locate_template( 'front-page.php' ) && is_front_page();

	/*
	 * Bail conditionally.
	 */
	if( ! is_front_page()
		|| is_paged()
		|| $is_shop_or_legacy_front_page
		) {
		return;
	}

	//Envoke slider.
	hamburg_slider_init();

	// Get the template part.
	get_template_part( 'parts/widgets', 'banner' );
}
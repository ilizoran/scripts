<?php
/**
 * Render search results.
 *
 * @package    Hamburg
 * @subpackage Templates
 */

get_header();

?>
	<div class="term-description">
		<header class="row">
			<div class="page-description">
				<p>
				<?php

				printf(
					_x( 'Search results for: %s',
						'Section heading search results',
						'theme_hamburg_textdomain'
					),
					'<span class="search-query">' . get_search_query() . '</span>'
				);
				?>
				</p>
			</div>
		</header>
	</div>

	<div class="site-main">
		<div class="row">
			<div id="primary" class="content-area full-width">
				<main id="content" class="site-content" role="main">
				<?php

				if ( ! have_posts() || get_post_type() == 'product' ) :

					get_template_part( 'parts/content', 'no-results' );

				else:

					/* Loop starts here. */
					while ( have_posts() ) :
						the_post();
					?>

					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<div class="entry">
							<header class="entry-header">
								<h1 class="entry-title">
									<a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a>
								</h1>
							</header>
							<div class="entry-content">
								<?php

								/* Excerpt only for search results. */
								the_excerpt();
								?>
							</div>
						</div>
					</article>

					<?php

					/* Loop ends here. */
					endwhile;

					/* Include query pagination. */
					get_template_part( 'parts/pagination', 'site' );

				endif;
				?>
				</main>

			</div>
		</div>
	</div>

<?php

get_footer();
<?php
/**
 * Sidebar template for shop pages.
 *
 * This will only display if the shop sidebar
 * has widgets and we're on a product category
 * or product tag archive page.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

if( ! is_active_sidebar( 'shop' ) || ( ! is_product_category() && ! is_product_tag() ) )
	return;
?>
	<section id="secondary" class="widget-area sidebar sidebar-shop" role="complementary">
		<?php dynamic_sidebar( 'shop' ); ?>
	</section>
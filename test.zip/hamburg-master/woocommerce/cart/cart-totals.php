<?php
/**
 * Cart totals
 *
 * @package	   Hamburg
 * @subpackage Templateparts
 * @version		2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<div class="cart_totals <?php if ( WC()->customer->has_calculated_shipping() ) echo 'calculated_shipping'; ?>">

	<?php do_action( 'woocommerce_before_cart_totals' ); ?>

	<h2><?php _e( 'Cart Totals', 'woocommerce' ); ?></h2>

	<table cellspacing="0">

		<tr class="cart-subtotal">
			<th class="td"><?php _e( 'Cart Subtotal', 'woocommerce' ); ?></th>
			<td><?php wc_cart_totals_subtotal_html(); ?></td>
		</tr><?php

		foreach ( WC()->cart->get_coupons() as $code => $coupon ) : ?>

			<tr class="cart-discount coupon-<?php echo esc_attr( $code ); ?>">
				<th class="td"><?php wc_cart_totals_coupon_label( $coupon ); ?></th>
				<td><?php wc_cart_totals_coupon_html( $coupon ); ?></td>
			</tr><?php

		endforeach;

		if ( WC()->cart->needs_shipping() && WC()->cart->show_shipping() ) :

			do_action( 'woocommerce_cart_totals_before_shipping' );

			wc_cart_totals_shipping_html();

			do_action( 'woocommerce_cart_totals_after_shipping' );

		endif;

		foreach ( WC()->cart->get_fees() as $fee ) : ?>

			<tr class="fee">
				<th class="td"><?php echo esc_html( $fee->name ); ?></th>
				<td><?php wc_cart_totals_fee_html( $fee ); ?></td>
			</tr><?php

		endforeach;

		// @WooCommerce_German_Market:
		if( ! hamburg_is_wgm() || ( hamburg_is_wgm() && ! WGM_Tax::is_kur() ) ) :

			// WooCommerce tax display
			if ( WC()->cart->tax_display_cart == 'excl' ) :

				if ( get_option( 'woocommerce_tax_total_display' ) == 'itemized' ) :

					foreach ( WC()->cart->get_tax_totals() as $code => $tax ) : ?>

						<tr class="tax-rate tax-rate-<?php echo sanitize_title( $code ); ?>">
							<th class="td"><?php echo esc_html( $tax->label ); ?></th>
							<td><?php echo wp_kses_post( $tax->formatted_amount ); ?></td>
						</tr><?php

					endforeach;

				else : ?>

					<tr class="tax-total">
						<th class="td"><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></th>
						<td><?php echo wc_price( WC()->cart->get_taxes_total() ); ?></td>
					</tr><?php

				endif;
			endif;

		endif; // end WGM

		do_action( 'woocommerce_cart_totals_before_order_total' );
		?>

		<tr class="order-total">
			<th><?php _e( 'Order Total', 'woocommerce' ); ?></th>
			<td class="th"><?php wc_cart_totals_order_total_html(); ?></td>
		</tr>

		<?php do_action( 'woocommerce_cart_totals_after_order_total' ); ?>

	</table>

	<?php

	if( WC()->cart->get_cart_tax() ) :

		/* @WooCommerce_German_Market: */
		if( ! hamburg_is_wgm() || ( hamburg_is_wgm() && get_option( 'woocommerce_de_estimate_cart', 'on' ) === 'on' ) ) :

		$estimated_text = WC()->customer->is_customer_outside_base() && ! WC()->customer->has_calculated_shipping()
							? sprintf( ' ' . __( ' (taxes estimated for %s)', 'woocommerce' ), WC()->countries->estimated_for_prefix() . __( WC()->countries->countries[ WC()->countries->get_base_country() ], 'woocommerce' ) )
							: '';

			printf(
				'<p><small>%s</small></p>',
				sprintf(
					__( 'Note: Shipping and taxes are estimated%s and will be updated during checkout based on your billing and shipping information.', 'woocommerce' ),
					$estimated_text
					)
				);

		endif;

	endif;

	if( ! hamburg_is_wgm() ) :
	?>

	<div class="wc-proceed-to-checkout">

		<?php do_action( 'woocommerce_proceed_to_checkout' ); ?>

	</div>

	<?php

	endif;

	do_action( 'woocommerce_after_cart_totals' );
	?>

</div>
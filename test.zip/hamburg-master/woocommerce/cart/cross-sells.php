<?php
/**
 * Template for cross-sells.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

	global $product, $woocommerce_loop;

	$crosssells = WC()->cart->get_cross_sells();

	/* Bail early if no cross-sells are set. */
	if ( sizeof( $crosssells ) == 0 )
		return;

	/* Envoke carousel doo-wop. */
	hamburg_slider_init();

	/* Prepare a new product query. */
	$meta_query = WC()->query->get_meta_query();
	$args = array(
		'post_type'           => 'product',
		'ignore_sticky_posts' => 1,
		'posts_per_page'      => apply_filters( 'woocommerce_cross_sells_total', 8 ),
		'no_found_rows'       => 1,
		'orderby'             => apply_filters( 'hamburg_wc_cart_crosssells_orderby', 'rand' ),
		'post__in'            => $crosssells,
		'meta_query'          => $meta_query
	);

	$products = new WP_Query( $args );

	$woocommerce_loop['columns'] = apply_filters( 'woocommerce_cross_sells_columns', 2 );

	if ( $products->have_posts() ) :
	?>
	<div class="cross-sells">

		<h2><?php _e( 'You may be interested in&hellip;', 'woocommerce' ) ?></h2>

		<?php woocommerce_product_loop_start(); ?>

		<div class="flexslider flex-carousel">
			<ul class="slides">
			<?php

			while ( $products->have_posts() ) :

				$products->the_post();

				/**
				 * Fetch template for related product content,
				 * no extra template for cross-sells.
				 */
				wc_get_template_part( 'content', 'product-related' );

			endwhile;
			?>
			</ul>
		</div>

		<?php woocommerce_product_loop_end(); ?>

	</div>
	<?php
	endif;

	/* Called the_post(), need to reset. */
	wp_reset_query();
<?php
/**
 * Content wrappers.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    1.6.4
 */
?>
	<div class="site-main">
		<div class="row">
			<div id="primary" class="content-area">
				<main id="content" class="site-content shop-content" role="main">

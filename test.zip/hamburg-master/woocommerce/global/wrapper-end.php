<?php
/**
 * Content wrappers.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    1.6.4
 */
?>
				</main>
			</div>
			<?php

			/**
			 * Include sidebars.
			 *
			 * We skip sidebar.php and load our sidebar templates directly.
			 * If you need to edit this, go straight to woocommerce/hamburg-widgets-shop.php.
			 *
			 */
			 wc_get_template_part( 'hamburg', 'widgets-shop' );

			/**
			 * Include an upwards link for user convenience.
			 *
			 * Edit parts/navigation-up.php as you see fit,
			 * or better yet: create a Child Theme!
			 *
			 */
			 get_template_part( 'parts/navigation', 'up' );
			?>
		</div>
	</div>
<?php
/**
 * The template for displaying related product content.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

	global $product, $woocommerce_loop;

	// Store loop count we're currently on
	if ( empty( $woocommerce_loop['loop'] ) )
		$woocommerce_loop['loop'] = 0;

	// Ensure visibility
	if ( ! $product->is_visible() )
		return;

	// Increase loop count
	$woocommerce_loop['loop']++;

?>
<li id="post-<?php the_ID(); ?>" <?php post_class( 'flex-item' ); ?>>

	<a class="flex-entry" href="<?php the_permalink(); ?>" title="<?php echo esc_attr( get_the_title() );  ?>">
		<h3 class="flex-title">
			<span><?php the_title(); ?></span>
		</h3>
		<?php
		woocommerce_show_product_loop_sale_flash();
		woocommerce_template_loop_product_thumbnail();
		?>
	</a>

</li>
<?php global $product; ?>
<li>
	<a href="<?php echo esc_url( get_permalink( $product->id ) ); ?>">
		<div class="product-widget-product-image">
			<?php echo $product->get_image(); ?>
		</div>
		<div class="product-widget-product-content">
			<?php echo $product->get_title(); ?>
			<?php if ( ! empty( $show_rating ) ) : ?>
			<div class="widget-rating"><?php echo $product->get_rating_html(); ?></div>
			<?php endif; ?>
			<div class="widget-price"><?php echo $product->get_price_html(); ?></div>
		</div>
	</a>
</li>
<?php
/**
 * Search form template for product search.
 *
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */

/**
 * We're counting search forms in order to
 * pass them unique ID values.
 *
 */
$search_count = hamburg_counter( 'search_form' );
?>
<div class="site-search">
	<div class="search-form">
		<form class="inline-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
			<label for="s_<?php echo $search_count; ?>"<?php
				/**
				 * Look for search term.
				 *
				 * If the search field has a value, we pass an additional class
				 * to its label which we positioned *behind* the transparent field.
				 * Once the field gains focus or has a value we hide the label via CSS.
				 * Why? Well, try styling a placeholder attribute, dude.
				 *
				 */
				if( '' !== get_search_query() )
					echo ' class="has-value"';

				?>>
				<span><?php echo _x( 'Find products&#8230;', 'Search field label (ellipsis)', 'theme_hamburg_textdomain' ); ?></span>
				<input id="s_<?php echo $search_count; ?>" name="s" type="text" class="search-input" value="<?php echo esc_attr( get_search_query() ); ?>" />
			</label>
			<div class="search-submit">
				<input type="submit" value="<?php echo _x( 'Submit', 'Search form submit button', 'theme_hamburg_textdomain' ); ?>" />
				<input type="hidden" name="post_type" value="product" />
			</div>
		</form>
	</div>
</div>
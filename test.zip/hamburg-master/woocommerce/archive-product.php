<?php
/**
 * The Template for displaying product archives,
 * including the main shop page which is a post type archive.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header('shop');

	/**
	 * Extra front page goodies.
	 *
	 * If this is the front page of your site, we're loading
	 * two additional template parts:
	 * 1. widget area "Front Page Banner"
	 * 2. widget area "Shop Front Page Teaser"
	 * Visit those template files for further insight.
	 *
	 */
	if( is_front_page() && ! is_paged() ) :

		/* Envoke slider. */
		hamburg_slider_init();

		/* Fetch template part for widget area "Front Page Banner" */
		get_template_part( 'parts/widgets', 'banner' );

		/* Fetch template part for widget area "Shop Front Page Teasers" */
		wc_get_template_part( 'hamburg', 'widgets-teasers' );

	endif;

	/* Fetch the page header template */
	if ( have_posts() )
		wc_get_template_part( 'hamburg', 'page-header' );

	/**
	 * woocommerce_before_main_content hook
	 *
	 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
	 * @hooked woocommerce_breadcrumb - 20
	 */
	do_action('woocommerce_before_main_content');

	if ( have_posts() ) :

		/**
		 * woocommerce_before_shop_loop hook
		 *
		 * @hooked woocommerce_result_count - 20
		 * @hooked woocommerce_catalog_ordering - 30
		 */
		do_action( 'woocommerce_before_shop_loop' );

		/* The Loop is on. */
		woocommerce_product_loop_start();

		woocommerce_product_subcategories();

		while ( have_posts() ) :
			the_post();

			/* Product content template part. */
			wc_get_template_part( 'content', 'product' );

		endwhile;

		woocommerce_product_loop_end();
		/* The Loop ends. */

		/**
		 * woocommerce_after_shop_loop hook
		 *
		 * @hooked woocommerce_pagination - 10
		 */
		do_action( 'woocommerce_after_shop_loop' );


	elseif ( ! woocommerce_product_subcategories(
				array(
					'before' => woocommerce_product_loop_start( false ),
					'after' => woocommerce_product_loop_end( false )
				))
			) :

		wc_get_template( 'loop/no-products-found.php' );

	endif;

	/**
	 * woocommerce_after_main_content hook
	 *
	 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
	 */
	do_action('woocommerce_after_main_content');


	/**
	 * woocommerce_sidebar hook
	 *
	 * @hooked woocommerce_get_sidebar - 10
	 */
	do_action('woocommerce_sidebar');


get_footer('shop');
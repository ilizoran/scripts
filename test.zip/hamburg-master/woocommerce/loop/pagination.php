<?php
/**
 * Pagination template for catalog pages.
 * Fancy icons for prev/next links.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version     2.2.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
	<nav class="pagination woocommerce-pagination">
		<?php echo hamburg_posts_pagination( array( 'mid_size' => '0', 'type' => 'list' ) ); ?>
	</nav>
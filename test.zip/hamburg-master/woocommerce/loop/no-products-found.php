<?php
/**
 * Template for no-result page.
 * Displayed when no products are found matching the current query.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
	<article class="post no-results not-found">

		<header class="entry-header">
			<h1 class="entry-title">
			<?php

			echo _x(
					'Apologies, nothing found here.',
					'No-results template heading',
					'theme_hamburg_textdomain'
					);
			?>
			</h1>
		</header>

		<div class="entry-content">
			<p><?php
				echo _x(
						'No products found which match your selection.',
						'No-results template for products (not only 404, but also searches!)',
						'theme_hamburg_textdomain'
						);
				?></p>
		</div>

	</article>
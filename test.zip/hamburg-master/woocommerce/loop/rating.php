<?php
/**
 * Loop Rating.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

if ( get_option( 'woocommerce_enable_review_rating' ) == 'no' )
	return;

/**
 * Built our own function here to get better markup.
 * Check inc/woocommerce.php for details.
 */
echo hamburg_wc_get_rating_html( $product );
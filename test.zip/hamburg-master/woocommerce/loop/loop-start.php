<?php
/**
 * Product Loop Start.
 * Theme Hamburg doesn't use this template,
 * but we have to keep it around to make sure
 * WooCommerce doesn't fall back to its own template.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    2.0.0
 */
?>
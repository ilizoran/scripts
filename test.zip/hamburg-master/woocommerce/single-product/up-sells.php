<?php
/**
 * Template for up-sells on single product pages.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

	global $product, $woocommerce_loop;

	$upsells = $product->get_upsells();

	if ( sizeof( $upsells ) == 0 )
		return;

	/* Upsells come in a carousel which we envoke here. */
	hamburg_slider_init();

	/* Prepare a new product query. */
	$meta_query = WC()->query->get_meta_query();
	$args = array(
		'post_type'           => 'product',
		'ignore_sticky_posts' => 1,
		'no_found_rows'       => 1,
		'posts_per_page'      => apply_filters( 'hamburg_wc_product_upsells_posts_per_page', 8 ),
		'orderby'             => $orderby,
		'post__in'            => $upsells,
		'post__not_in'        => array( $product->id ),
		'meta_query'          => $meta_query
	);

	$products = new WP_Query( $args );

	$woocommerce_loop['columns'] 	= $columns;

	if ( $products->have_posts() ) :
	?>
	<div class="upsells products">

		<h2><?php _e( 'You may also like&hellip;', 'woocommerce' ) ?></h2>

		<?php woocommerce_product_loop_start(); ?>

		<div class="flexslider flex-carousel">
			<ul class="slides">
		<?php

			while ( $products->have_posts() ) :
				$products->the_post();

				/* Fetch template for related product content. */
				wc_get_template_part( 'content', 'product-related' );

			endwhile;
		?>
			</ul>
		</div>

		<?php woocommerce_product_loop_end(); ?>

	</div>
	<?php
	endif;

	/* We called the_post() before, so we have to put things at ease again. */
	wp_reset_postdata();

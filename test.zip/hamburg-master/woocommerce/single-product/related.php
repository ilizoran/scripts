<?php
/**
 * Template for related products loop.
 * If there actually are enough items in that loop,
 * related products display as a responsive carousel.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 * @version    1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product, $woocommerce_loop;

$related = $product->get_related();

/* Bail early. */
if ( sizeof( $related ) == 0 )
	return;

/* Envoke carousel fancyness. */
hamburg_slider_init();

/* Prepare a new product query */
$args = apply_filters('woocommerce_related_products_args', array(
	'post_type'				=> 'product',
	'ignore_sticky_posts'	=> 1,
	'no_found_rows' 		=> 1,
	'posts_per_page' 		=> 8,
	'orderby' 				=> $orderby,
	'post__in' 				=> $related,
	'post__not_in'			=> array($product->id)
) );

$products = new WP_Query( $args );

$woocommerce_loop['columns'] = $columns;

if ( $products->have_posts() ) :
?>
	<div class="related products">
		<h2><?php _e( 'Related Products', 'woocommerce' ); ?></h2>

		<?php woocommerce_product_loop_start(); ?>

		<div class="flexslider flex-carousel">
			<ul class="slides">
		<?php
		while ( $products->have_posts() ) : $products->the_post();

			/* Fetch template for related product content. */
			wc_get_template_part( 'content', 'product-related' );

		endwhile;
		?>
			</ul>
		</div>

		<?php woocommerce_product_loop_end(); ?>

	</div>
<?php
endif;

/* Need to reset post data as we've called the_post() before. */
wp_reset_postdata();
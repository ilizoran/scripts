<?php
/**
 * Template for teasers section on shop front page.
 *
 * @package    Hamburg
 * @subpackage Templateparts
 */
?>

	<div id="teaser" class="site-main">
		<div class="row">
		<?php
		/**
		 * You can place your own choice of widgets
		 * in the widget area named "Shop Front Page Teasers".
		 * However, if you don't, a selection of your top 10
		 * best-selling products will be displayed in a
		 * responsive carousel. Neat, eh?
		 *
		 */
		if( ! dynamic_sidebar( 'teasers' ) ) :

		?>
			<h2 class="section-header">
				<?php echo _x( 'Our Top 10', 'Teaser heading on shop front page', 'theme_hamburg_textdomain' ); ?>
			</h2>
			<?php

			/**
			 * That carousel mentioned above.
			 *
			 */
			echo hamburg_best_selling_products( array(
					'before' => '<div id="teaser-slider" class="flexslider flex-carousel"><ul class="slides">',
					'after' => '</ul></div>'
					) );

		endif;
		?>
		</div>
	</div>
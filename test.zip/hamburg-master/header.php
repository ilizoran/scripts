<?php
/**
 * HTML header
 *
 * @package    Hamburg
 * @subpackage Templates
 */

/* Include Doctype and IE conditionals. */
hamburg()->htmlstart();
?>
<head profile="http://gmpg.org/xfn/11">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php

	/* Optional support for wpSEO plugin. */
	if( has_action( 'wpseo_the_meta' ) ) :
		do_action( 'wpseo_the_meta' );
	else :
	?>
	<title><?php
	wp_title( '|', TRUE, 'right' );
	?></title>
	<?php
	endif;

	/* Support Windwos 8 start screen. */
	?>
	<meta name="application-name" content="<?php bloginfo( 'blogname' ); ?>">
	<meta name="msapplication-TileColor" content="<?php
		// see inc/class-Hamburg_Customize.php
		echo apply_filters( 'hamburg_ms_tile_color', '#ffffff' );
	?>">
	<?php
	wp_head();
	?>
</head>
<body <?php body_class(); ?>>
	<?php

	/*
	 * Include meta navigation template.
	 *
	 * A meta navigation typically contains items like
	 * "About", "Contact", "FAQ" as well as language selections
	 * on multilangual sites.
	 */
	get_template_part( 'parts/navigation', 'meta' );

	/*
	 * Include the site header template.
	 *
	 * A site header typically contains the site's title,
	 * maybe in form of a a brand or logo or header image,
	 * as well as a site description.
	 */
	get_template_part( 'parts/header', 'site' );

	/*
	 * Include primary site navigation.
	 *
	 * The site navigation (main navigation, main menu)
	 * typically contains items displaying the first
	 * (optionally: 2nd, 3rd) level of the page tree.
	 *
	 */
	get_template_part( 'parts/navigation', 'site-primary' );

	/* Breadcrumb navigation. */
	get_template_part( 'parts/navigation', 'breadcrumb' );

	/* Secondary navigation. */
	get_template_part( 'parts/navigation', 'site-secondary' );

	/* Archive header. */
	get_template_part( 'parts/header', 'archives' );

	/*
	 * Front page banner widget area.
	 *
	 * This includes parts/widgets-banner.php on the front page,
	 * whether that would be a static page or the posts loop.
	 *
	 * hamburg_get_front_page_banner() is defined in functions.php
	 * and uses hamburg_slider_init() defned in inc/setup.php.
	 *
	 */
	hamburg_get_front_page_banner();
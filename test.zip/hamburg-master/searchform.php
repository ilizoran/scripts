<?php
/**
 * Render the search form.
 *
 * This file will also be used by the search widget.
 *
 * @package    Hamburg
 * @subpackage Templates
 */

/*
 * In case we use the search form multiple times, we have to avoid a
 * reused ID, because that would render our HTML invalid.
 * Here, we add a counter to the ID each time the file is called.
 * So we get "s_1", "s_2" and so on as ID attribute values.
 */
$search_count = hamburg_counter( 'search_form' );
?>
<div class="site-search">
	<div class="search-form">
		<form class="inline-form" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
			<label for="s_<?php echo $search_count; ?>"<?php

				/*
				 * Look for search term.
				 * If the search field has a value, this gets an additional class.
				 */
				if( '' !== get_search_query() )
					echo ' class="has-value"';

				?>>
				<span><?php
				echo _x(
					'Find&#8230;',
					'Search field label (ellipsis)',
					'theme_hamburg_textdomain'
				);
				?></span>
				<input id="s_<?php
					echo $search_count;
					?>" name="s" type="text" class="search-input" value="<?php
					the_search_query();
					?>" />
			</label>
			<div class="search-submit">
				<input type="submit" value="<?php
				echo _x(
					'Submit',
					'Search form submit button',
					'theme_hamburg_textdomain'
				);
				?>" />
			</div>
		</form>
	</div>
</div>
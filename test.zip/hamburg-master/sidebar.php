<?php
/**
 * Dummy file.
 *
 * Themes without sidebar.php are deprecated since WordPress 3.0,
 * so we need this in order to avoid a notice in DEBUG mode.
 *
 * You look good, by the way!
 */
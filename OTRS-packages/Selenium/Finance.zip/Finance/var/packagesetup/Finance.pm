# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package var::packagesetup::Finance;
## no critic(Perl::Critic::Policy::OTRS::RequireCamelCase)

use strict;
use warnings;

our @ObjectDependencies = (
    'Kernel::Config',
    'Kernel::System::DB',
    'Kernel::System::Cache',
    'Kernel::System::Group',
    'Kernel::System::SysConfig',
    'Kernel::System::Valid',
);

=head1 NAME

Finance.pm - code to execute during package installation

=head1 SYNOPSIS

All functions

=head1 PUBLIC INTERFACE

=over 4

=cut

=item new()

create an object

    use Kernel::System::ObjectManager;
    local $Kernel::OM = Kernel::System::ObjectManager->new();
    my $CodeObject = $Kernel::OM->Get('var::packagesetup::Finance');

=cut

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {};
    bless( $Self, $Type );

    # rebuild ZZZ* files
    $Kernel::OM->Get('Kernel::System::SysConfig')->WriteDefault();

    # define the ZZZ files
    my @ZZZFiles = (
        'ZZZAAuto.pm',
        'ZZZAuto.pm',
    );

    # reload the ZZZ files (mod_perl workaround)
    for my $ZZZFile (@ZZZFiles) {

        PREFIX:
        for my $Prefix (@INC) {
            my $File = $Prefix . '/Kernel/Config/Files/' . $ZZZFile;
            next PREFIX if !-f $File;

            do $File;
            last PREFIX;
        }
    }

    # always discard the config object before package code is executed,
    # to make sure that the config object will be created newly, so that it
    # will use the recently written new config from the package
    $Kernel::OM->ObjectsDiscard(
        Objects => ['Kernel::Config'],
    );

    # define file prefix
    $Self->{FilePrefix} = 'Finance';

    return $Self;
}

=item CodeInstall()

run the code install part

    my $Result = $CodeObject->CodeInstall();

=cut

sub CodeInstall {
    my ( $Self, %Param ) = @_;

    $Self->_InsertFinanceArticle();

    # add the group time_accounting
    $Self->_GroupAdd(
        Name        => 'DevelopmentFinance',
        Description => 'Group for all finance user.',
    );

    # delete the group cache to avoid permission problems
    $Kernel::OM->Get('Kernel::System::Cache')->CleanUp( Type => 'Group' );

    return 1;
}

=item CodeReinstall()

run the code reinstall part

    my $Result = $CodeObject->CodeReinstall();

=cut

sub CodeReinstall {
    my ( $Self, %Param ) = @_;

    $Self->_InsertFinanceArticle();

    # add the group time_accounting
    $Self->_GroupAdd(
        Name        => 'DevelopmentFinance',
        Description => 'Group for all finance user.',
    );

    # delete the group cache to avoid permission problems
    $Kernel::OM->Get('Kernel::System::Cache')->CleanUp( Type => 'Group' );

    return 1;
}

=item CodeUpgrade()

run the code upgrade part

    my $Result = $CodeObject->CodeUpgrade();

=cut

sub CodeUpgrade {
    my ( $Self, %Param ) = @_;

    return 1;
}

=item CodeUninstall()

run the code uninstall part

    my $Result = $CodeObject->CodeUninstall();

=cut

sub CodeUninstall {
    my ( $Self, %Param ) = @_;

    # deactivate the group time_accounting
    $Self->_GroupDeactivate(
        Name => 'DevelopmentFinance',
    );

    return 1;
}

=item CodeUpgradeFromLowerThan_5_0_1()

This function is only executed if the installed module version is smaller than 5.0.1.

my $Result = $CodeObject->CodeUpgradeFromLowerThan_5_0_1();

=cut

sub CodeUpgradeFromLowerThan_5_0_1 {    ## no critic
    my ( $Self, %Param ) = @_;

    # change configurations to match the new module location.
    $Self->_MigrateConfigs();

    return 1;
}

=item _InsertFinanceArticle()

creates all dynamic fields that are necessary for Finance

    my $Result = $CodeObject->_InsertFinanceArticle();

=cut

sub _InsertFinanceArticle {
    my ( $Self, %Param ) = @_;

    # ItemID ArticleID Title Description PiceReal PicePublic Tax Discount Price UserID
    # define finance articles
    my @FinanceArticle = (
        {
            Number      => '1001',
            Title       => 'OTRS Feature Development',
            Situation   => '',
            Description => 'Ausgangssituation/Problem:

Implementierungsvorschlag:

Platformen:',
            Comments => '',
            Discount => '20',
            Tax      => '19',
            Price    => '1250.00',
        },
        {
            Number      => '1002',
            Title       => 'OTRS Consulting',
            Situation   => '',
            Description => 'Installation, Konfiguration und Einführung.',
            Comments    => '',
            Discount    => '0',
            Tax         => '19',
            Price       => '1250.00',
        },
        {
            Number      => '1003',
            Title       => 'OTRS Senior Consulting',
            Situation   => '',
            Description => 'Installation, Konfiguration und Einführung.',
            Comments    => '',
            Discount    => '0',
            Tax         => '19',
            Price       => '1250.00',
        },
    );

    # get DB object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    for my $Article (@FinanceArticle) {

        # add the finance article
        return if !$DBObject->Do(
            SQL => '
                INSERT INTO finance_article (number, title, situation, description, comments,
                    discount, tax, price, valid_id, create_time, create_by, change_time, change_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, current_timestamp, 1, current_timestamp, 1)
            ',
            Bind => [
                \$Article->{Number}, \$Article->{Title}, \$Article->{Situation},
                \$Article->{Description},
                \$Article->{Comments}, \$Article->{Discount}, \$Article->{Tax}, \$Article->{Price},
            ],
        );
    }

    return 1;
}

=item _GroupAdd()

add a group

    my $Result = $CodeObject->_GroupAdd(
        Name        => 'the-group-name',
        Description => 'The group description.',
    );

=cut

sub _GroupAdd {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Argument (qw(Name Description)) {
        if ( !$Param{$Argument} ) {
            Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Argument!",
            );
            return;
        }
    }

    # get valid list
    my %ValidList = $Kernel::OM->Get('Kernel::System::Valid')->ValidList(
        UserID => 1,
    );
    my %ValidListReverse = reverse %ValidList;

    # get group object
    my $GroupObject = $Kernel::OM->Get('Kernel::System::Group');

    # get list of all groups
    my %GroupList = $GroupObject->GroupList();

    # reverse the group list for easier lookup
    my %GroupListReverse = reverse %GroupList;

    # check if group already exists
    my $GroupID = $GroupListReverse{ $Param{Name} };

    # reactivate the group
    if ($GroupID) {

        # get current group data
        my %GroupData = $GroupObject->GroupGet(
            ID     => $GroupID,
            UserID => 1,
        );

        # reactivate group
        $GroupObject->GroupUpdate(
            %GroupData,
            ValidID => $ValidListReverse{valid},
            UserID  => 1,
        );

        return 1;
    }

    # add the group
    else {
        return if !$GroupObject->GroupAdd(
            Name    => $Param{Name},
            Comment => $Param{Description},
            ValidID => $ValidListReverse{valid},
            UserID  => 1,
        );
    }

    # lookup the new group id
    my $NewGroupID = $GroupObject->GroupLookup(
        Group  => $Param{Name},
        UserID => 1,
    );

    # add user root to the group
    $GroupObject->GroupMemberAdd(
        GID        => $NewGroupID,
        UID        => 1,
        Permission => {
            ro        => 1,
            move_into => 1,
            create    => 1,
            owner     => 1,
            priority  => 1,
            rw        => 1,
        },
        UserID => 1,
    );

    return 1;
}

=item _GroupDeactivate()

deactivate a group

    my $Result = $CodeObject->_GroupDeactivate(
        Name => 'the-group-name',
    );

=cut

sub _GroupDeactivate {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    if ( !$Param{Name} ) {
        Kernel::OM->Get('Kernel::System::Log')->Log(
            Priority => 'error',
            Message  => 'Need Name!',
        );
        return;
    }

    # get group object
    my $GroupObject = $Kernel::OM->Get('Kernel::System::Group');

    # lookup group id
    my $GroupID = $GroupObject->GroupLookup(
        Group => $Param{Name},
    );

    return if !$GroupID;

    # get valid list
    my %ValidList = $Kernel::OM->Get('Kernel::System::Valid')->ValidList(
        UserID => 1,
    );
    my %ValidListReverse = reverse %ValidList;

    # get current group data
    my %GroupData = $GroupObject->GroupGet(
        ID     => $GroupID,
        UserID => 1,
    );

    # deactivate group
    $GroupObject->GroupUpdate(
        %GroupData,
        ValidID => $ValidListReverse{invalid},
        UserID  => 1,
    );

    return 1;
}

sub _MigrateConfigs {

    # create needed objects
    my $SysConfigObject = $Kernel::OM->Get('Kernel::System::SysConfig');
    my $ConfigObject    = $Kernel::OM->Get('Kernel::Config');

    # migrate Finance menu modules
    my $MenuModule = '460-Offer';

    # get setting content for Finance menu modules
    my $Setting = $ConfigObject->Get('Ticket::Frontend::MenuModule');

    # update module location
    my $Module = $Setting->{$MenuModule}->{'Module'};
    if ( $Module && $Module =~ m{Kernel::Output::HTML::TicketMenu(\w+)} ) {

        $Setting->{$MenuModule}->{Module} = "Kernel::Output::HTML::TicketMenu::Generic";

        # set new setting,
        my $Success = $SysConfigObject->ConfigItemUpdate(
            Valid => 1,
            Key   => 'Ticket::Frontend::MenuModule###' . $MenuModule,
            Value => $Setting->{$MenuModule},
        );
    }

    return 1;
}

1;

=back

=head1 TERMS AND CONDITIONS

This software is part of the OTRS project (L<http://otrs.org/>).

This software comes with ABSOLUTELY NO WARRANTY. For details, see
the enclosed file COPYING for license information (AGPL). If you
did not receive this file, see L<http://www.gnu.org/licenses/agpl.txt>.

=cut

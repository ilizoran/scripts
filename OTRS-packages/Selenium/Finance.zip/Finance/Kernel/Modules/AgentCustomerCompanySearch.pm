# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::Modules::AgentCustomerCompanySearch;

use strict;
use warnings;

our $ObjectManagerDisabled = 1;

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {%Param};
    bless( $Self, $Type );

    return $Self;
}

sub Run {
    my ( $Self, %Param ) = @_;

    # get param object
    my $ParamObject  = $Kernel::OM->Get('Kernel::System::Web::Request');
    my $LayoutObject = $Kernel::OM->Get('Kernel::Output::HTML::Layout');

    my $JSON = '';

    # search customers
    if ( !$Self->{Subaction} ) {

        # get needed params
        my $Search = $ParamObject->GetParam( Param => 'Term' ) || '';
        my $MaxResults = int( $ParamObject->GetParam( Param => 'MaxResults' ) || 20 );

        # get customer list
        my %CustomerCompanyList = $Kernel::OM->Get('Kernel::System::CustomerCompany')->CustomerCompanyList(
            Search => $Search,
            Valid  => 1,
        );

        # build data
        my @Data;
        my $MaxResultCount = $MaxResults;
        CUSTOMERCOMPANYID:
        for my $CustomerCompanyID (
            sort { $CustomerCompanyList{$a} cmp $CustomerCompanyList{$b} }
            keys %CustomerCompanyList
            )
        {
            my $CustomerValue = $CustomerCompanyList{$CustomerCompanyID};
            $CustomerValue =~ s/^\s+//;
            $CustomerValue =~ s/\s+$//;

            push @Data, {
                CustomerKey   => $CustomerCompanyID,
                CustomerValue => $CustomerValue,
            };

            $MaxResultCount--;
            last CUSTOMERCOMPANYID if $MaxResultCount <= 0;
        }

        # build JSON output
        $JSON = $LayoutObject->JSONEncode(
            Data => \@Data,
        );
    }

    # send JSON response
    return $LayoutObject->Attachment(
        ContentType => 'application/json; charset=' . $LayoutObject->{Charset},
        Content     => $JSON || '',
        Type        => 'inline',
        NoCache     => 1,
    );

}

1;

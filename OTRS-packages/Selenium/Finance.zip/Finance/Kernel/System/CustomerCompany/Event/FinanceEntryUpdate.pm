# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::System::CustomerCompany::Event::FinanceEntryUpdate;

use strict;
use warnings;

our @ObjectDependencies = (
    'Kernel::System::Finance',
    'Kernel::System::Log',
);

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {};
    bless( $Self, $Type );

    return $Self;
}

sub Run {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Needed (qw( Data Event Config UserID )) {
        if ( !$Param{$Needed} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Needed!",
            );

            return;
        }
    }
    for my $Needed (qw( CustomerID OldCustomerID )) {
        if ( !$Param{Data}->{$Needed} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Needed in Data!",
            );

            return;
        }
    }

    return 1 if $Param{Data}->{CustomerID} eq $Param{Data}->{OldCustomerID};

    # get finance object
    my $FinanceObject = $Kernel::OM->Get('Kernel::System::Finance');

    # search all Finance entries for CustomerID
    my @Items = $FinanceObject->ItemSearch(
        CustomerID => $Param{Data}->{OldCustomerID},
        UserID     => 1,
    );

    # update all Finance entries
    for my $Item (@Items) {

        my %Data = $FinanceObject->ItemGet(
            ItemID => $Item,
            UserID => 1,
        );

        $FinanceObject->ItemUpdate(
            %Data,
            CustomerID => $Param{Data}->{CustomerID},
            UserID     => 1,
        );

    }

    return 1;
}

1;

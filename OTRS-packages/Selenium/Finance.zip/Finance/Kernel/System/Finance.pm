# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::System::Finance;

use strict;
use warnings;

our @ObjectDependencies = (
    'Kernel::System::Cache',
    'Kernel::System::CustomerUser',
    'Kernel::System::DB',
    'Kernel::System::Log',
    'Kernel::System::Main',
    'Kernel::System::TimeAccounting',
);

=head1 NAME

Kernel::System::Valid - valid lib

=head1 SYNOPSIS

All valid functions.

=head1 PUBLIC INTERFACE

=over 4

=cut

=item new()

create an object. Do not use it directly, instead use:

    use Kernel::System::ObjectManager;
    local $Kernel::OM = Kernel::System::ObjectManager->new();
    my $FinanceObject = $Kernel::OM->Get('Kernel::System::Finance');

=cut

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {};
    bless( $Self, $Type );

    $Self->{CacheType} = 'Finance';
    $Self->{CacheTTL}  = 60 * 60 * 24 * 20;

    return $Self;
}

sub ItemAdd {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (
        qw(
        Title State Description InfoBilling CustomerUserID NextAction
        Delivery SWQADate Processed Probability UserID)
        )
    {
        if ( !defined $Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # set owner_id undef if not present
    $Param{OwnerID} = undef if !$Param{OwnerID};

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # add new item
    return if !$DBObject->Do(
        SQL => '
            INSERT INTO finance_item (title, state, situation, description, info_billing,
                customer_user_id, customer_id, action, delivery, swqa_date, ticket_sales,
                ticket_devel, ticket_billing, processed, probability, owner_id, create_time,
                create_by, change_time, change_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, current_timestamp, ?,
                current_timestamp, ?)
        ',
        Bind => [
            \$Param{Title}, \$Param{State}, \$Param{Situation}, \$Param{Description},
            \$Param{InfoBilling}, \$Param{CustomerUserID}, \$Param{CustomerID},
            \$Param{NextAction},  \$Param{Delivery},       \$Param{SWQADate}, \$Param{TicketSales},
            \$Param{TicketDevel}, \$Param{TicketBilling},  \$Param{Processed}, \$Param{Probability},
            \$Param{OwnerID},     \$Param{UserID},         \$Param{UserID},
        ],
    );

    # delete cache
    $Kernel::OM->Get('Kernel::System::Cache')->CleanUp(
        Type => $Self->{CacheType},
    );

    # get item id
    return if !$DBObject->Prepare(
        SQL => '
            SELECT id
            FROM finance_item
            WHERE title = ? AND state = ? AND description = ? AND change_by = ?
        ',
        Bind => [
            \$Param{Title}, \$Param{State}, \$Param{Description}, \$Param{UserID},
        ],
        Limit => 1,
    );

    # fetch the result
    my $ItemID;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        $ItemID = $Row[0];
    }

    return if !$ItemID;

    # sync with time accounting
    $Self->TimeAccountingSync(
        ItemID => $ItemID,
        UserID => $Param{UserID},
    );

    return $ItemID;
}

sub ItemUpdate {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (
        qw(
        ItemID Title State Description InfoBilling CustomerUserID
        NextAction Delivery SWQADate Processed Probability UserID
        )
        )
    {
        if ( !defined $Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # sync with time accounting
    if ( $Param{ItemID} ) {
        $Self->TimeAccountingSync(
            ItemID => $Param{ItemID},
            UserID => $Param{UserID},
        );
    }

    # set owner_id undef if not present
    $Param{OwnerID} = undef if !$Param{OwnerID};

    # update item
    return if !$Kernel::OM->Get('Kernel::System::DB')->Do(
        SQL => '
            UPDATE finance_item
            SET title = ?, state = ?, situation = ?, description = ?, info_billing = ?,
                customer_user_id = ?, customer_id = ?, action = ?, delivery = ?,
                swqa_date = ?, ticket_sales = ?, ticket_devel = ?, ticket_billing = ?,
                processed = ?, probability = ?, owner_id =?, change_time = current_timestamp,
                change_by = ?
            WHERE id = ?
        ',
        Bind => [
            \$Param{Title}, \$Param{State}, \$Param{Situation}, \$Param{Description},
            \$Param{InfoBilling}, \$Param{CustomerUserID}, \$Param{CustomerID},
            \$Param{NextAction},  \$Param{Delivery},       \$Param{SWQADate}, \$Param{TicketSales},
            \$Param{TicketDevel}, \$Param{TicketBilling},  \$Param{Processed},
            \$Param{Probability}, \$Param{OwnerID},        \$Param{UserID}, \$Param{ItemID},
        ],
    );

    # delete cache
    $Kernel::OM->Get('Kernel::System::Cache')->CleanUp(
        Type => $Self->{CacheType},
    );

    return 1;
}

sub ItemGet {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (qw(ItemID UserID)) {
        if ( !$Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    # check cache
    my $CacheKey = 'ItemGet-' . $Param{ItemID};
    my $Cache    = $CacheObject->Get(
        Key  => $CacheKey,
        Type => $Self->{CacheType},
    );

    return %{$Cache} if $Cache;

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # get item
    return if !$DBObject->Prepare(
        SQL => '
            SELECT id, title, state, situation, description, info_billing,
                customer_user_id, customer_id, action, delivery, swqa_date,
                ticket_sales, ticket_devel, ticket_billing, processed, probability,
                owner_id, create_time, create_by, change_time, change_by
            FROM finance_item
            WHERE id = ?
        ',
        Bind  => [ \$Param{ItemID} ],
        Limit => 1,
    );

    # fetch the result
    my %Data;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        $Data{ItemID}         = $Row[0];
        $Data{Number}         = $Row[0];
        $Data{Title}          = $Row[1];
        $Data{State}          = $Row[2];
        $Data{Situation}      = $Row[3];
        $Data{Description}    = $Row[4];
        $Data{InfoBilling}    = $Row[5];
        $Data{CustomerUserID} = $Row[6];
        $Data{CustomerID}     = $Row[7];
        $Data{NextAction}     = $Row[8];
        $Data{Delivery}       = $Row[9];
        $Data{SWQADate}       = $Row[10];
        $Data{TicketSales}    = $Row[11];
        $Data{TicketDevel}    = $Row[12];
        $Data{TicketBilling}  = $Row[13];
        $Data{Processed}      = $Row[14];
        $Data{Probability}    = $Row[15];
        $Data{OwnerID}        = $Row[16];
        $Data{Created}        = $Row[17];
        $Data{CreatedBy}      = $Row[18];
        $Data{Changed}        = $Row[19];
        $Data{ChangedBy}      = $Row[20];

        $Data{Volume} = 0;
    }

    # get prices
    return if !$DBObject->Prepare(
        SQL => '
            SELECT pice_public, price, discount
            FROM finance_item_article
            WHERE item_id = ?
        ',
        Bind => [ \$Param{ItemID} ],
    );

    # fetch the result
    while ( my @Row = $DBObject->FetchrowArray() ) {

        my $Total = $Row[0] * $Row[1];
        $Total = $Total / 100 * ( 100 - $Row[2] );
        $Total =~ s/^(.*\.\d\d).+?$/$1/;

        $Data{Volume} += $Total;
    }

    if ( $Data{Volume} && $Data{Volume} !~ /\./ ) {
        $Data{Volume} .= '.00';
    }

    # set cache
    $CacheObject->Set(
        Key   => $CacheKey,
        Value => \%Data,
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
    );

    return %Data;
}

sub ItemSearch {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (qw(UserID)) {
        if ( !$Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    my $SQL    = 'SELECT id FROM finance_item';
    my $SQLExt = '';
    my @Bind;
    my @CacheItems;

    if ( $Param{State} && @{ $Param{State} } ) {
        if ( !$SQLExt ) {
            $SQL .= ' WHERE '
        }
        $SQLExt .= "state IN ( '${\(join '\', \'', sort @{ $Param{State} } )}' )";
        push @CacheItems, 'State::' . join( '|', sort @{ $Param{State} } );
    }

    if ( $Param{NextAction} && @{ $Param{NextAction} } ) {
        if ( !$SQLExt ) {
            $SQL .= ' WHERE '
        }
        if ($SQLExt) {
            $SQLExt .= ' AND ';
        }
        $SQLExt .= "action IN ( '${\(join '\', \'', sort @{ $Param{NextAction} } )}' )";
        push @CacheItems, 'NextAction::' . join( '|', sort @{ $Param{NextAction} } );
    }

    if ( $Param{CustomerID} ) {
        if ( !$SQLExt ) {
            $SQL .= ' WHERE '
        }
        if ($SQLExt) {
            $SQLExt .= ' AND ';
        }
        $SQLExt .= "customer_id = ? ";
        push @Bind,       \$Param{CustomerID};
        push @CacheItems, "CustomerID::$Param{CustomerID}";
    }

    if ( $Param{CustomerUserLogin} ) {
        if ( !$SQLExt ) {
            $SQL .= ' WHERE '
        }
        if ($SQLExt) {
            $SQLExt .= ' AND ';
        }
        $SQLExt .= "customer_user_id = ? ";
        push @Bind,       \$Param{CustomerUserLogin};
        push @CacheItems, "CustomerUserLogin::$Param{CustomerUserLogin}";
    }

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    if ( $Param{CreateTimeNewerDate} ) {
        if ( !$SQLExt ) {
            $SQL .= ' WHERE '
        }
        if ($SQLExt) {
            $SQLExt .= ' AND ';
        }
        $SQLExt .= "create_time >= '" . $DBObject->Quote( $Param{CreateTimeNewerDate} ) . "' ";
        push @CacheItems, "CreateTimeNewerDate::$Param{CreateTimeNewerDate}";
    }

    if ( $Param{CreateTimeOlderDate} ) {
        if ( !$SQLExt ) {
            $SQL .= ' WHERE '
        }
        if ($SQLExt) {
            $SQLExt .= ' AND ';
        }
        $SQLExt .= "create_time <= '" . $DBObject->Quote( $Param{CreateTimeNewerDate} ) . "' ";
        push @CacheItems, "CreateTimeOlderDate::$Param{CreateTimeOlderDate}";
    }

    $SQL .= $SQLExt . ' ORDER BY create_time DESC';

    # check cache
    my $CacheKeyRaw = 'ItemSearch-' . join( '::', @CacheItems );
    my $CacheKey = $Kernel::OM->Get('Kernel::System::Main')->MD5sum(
        String => \$CacheKeyRaw,
    );

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    my $Cache = $CacheObject->Get(
        Key  => $CacheKey,
        Type => $Self->{CacheType},
    );

    return @{$Cache} if $Cache;

    # ask the database
    return if !$DBObject->Prepare(
        SQL   => $SQL,
        Limit => $Param{Limit},
        Bind  => \@Bind,
    );

    # fetch the result
    my @Data;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        push @Data, $Row[0];
    }

    # set cache
    $CacheObject->Set(
        Key   => $CacheKey,
        Value => \@Data,
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
    );

    return @Data;
}

=item ItemGetFirstLastCreationDates()

gets the oldest and latest years when an item was created

    my %ItemCreationDates = $FinanceObject->ItemGetFirstLastCreationDates();

returns

    %ItemCreationDates = (
        OldestYear => '2008',
        LatestYear => '2011',
    );

=cut

sub ItemGetFirstLastCreationDates {
    my ( $Self, %Param ) = @_;

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    # check cache
    my $CacheKey = 'ItemGetFirstLastCreationDates';
    my $Cache    = $CacheObject->Get(
        Key  => $CacheKey,
        Type => $Self->{CacheType},
    );
    return %{$Cache} if $Cache;

    # build query to get latest date
    my $SQL = '
        SELECT MAX(create_time)
        FROM finance_item
    ';

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # prepare query
    return if !$DBObject->Prepare(
        SQL   => $SQL,
        Limit => 1,
    );

    # fetch the result
    my $LatestYear;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        $LatestYear = $Row[0];
    }

    # build query to get oldest date
    $SQL = '
        SELECT MIN(create_time)
        FROM finance_item
    ';

    # prepare query
    return if !$DBObject->Prepare(
        SQL   => $SQL,
        Limit => 1,
    );

    # fetch the result
    my $OldestYear;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        $OldestYear = $Row[0];
    }

    # get only years from dates
    my %ItemCreationDates;
    if ( $LatestYear && $LatestYear =~ /^(\d{4})-\d{2}-\d{2}/ ) {
        $ItemCreationDates{LatestYear} = $1;
    }
    if ( $OldestYear && $OldestYear =~ /^(\d{4})-\d{2}-\d{2}/ ) {
        $ItemCreationDates{OldestYear} = $1;
    }

    # set cache
    $CacheObject->Set(
        Key   => $CacheKey,
        Value => \%ItemCreationDates,
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
    );

    return %ItemCreationDates;
}

=item ItemGetAllCreationDates()

get all years when an item was created

    my @ItemCreationDates = $FinanceObject->ItemGetAllCreationDates();

returns

    @ItemCreationDates = ('2008', '2009', '2010');

=cut

sub ItemGetAllCreationDates {
    my ( $Self, %Param ) = @_;

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    # check cache
    my $CacheKey = 'ItemGetAllCreationDates';
    my $Cache    = $CacheObject->Get(
        Key  => $CacheKey,
        Type => $Self->{CacheType},
    );

    return @{$Cache} if $Cache;

    # build query to get latest date
    my $SQL = '
        SELECT DISTINCT(create_time)
        FROM finance_item
        ORDER BY create_time ASC
    ';

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # prepare query
    return if !$DBObject->Prepare(
        SQL => $SQL,
    );

    # fetch the result
    my @CreateTimes;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        if ( $Row[0] =~ /^(\d{4})-\d{2}-\d{2}/ ) {

            # make sure that only different years are saved in the array
            if ( !grep { $_ eq $1 } @CreateTimes ) {
                push @CreateTimes, $1;
            }
        }
    }

    # set cache
    $CacheObject->Set(
        Key   => $CacheKey,
        Value => \@CreateTimes,
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
    );

    return @CreateTimes;
}

sub ItemArticleList {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (qw(ItemID UserID)) {
        if ( !$Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    # check cache
    my $CacheKey = 'ItemArticleList-' . $Param{ItemID};
    my $Cache    = $CacheObject->Get(
        Key  => $CacheKey,
        Type => $Self->{CacheType},
    );

    return @{$Cache} if $Cache;

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # ask the database
    return if !$DBObject->Prepare(
        SQL => '
            SELECT id
            FROM finance_item_article
            WHERE item_id = ?
        ',
        Bind => [ \$Param{ItemID} ],
    );

    # fetch the result
    my @Data;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        push @Data, $Row[0];
    }

    # set cache
    $CacheObject->Set(
        Key   => $CacheKey,
        Value => \@Data,
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
    );

    return @Data;
}

sub ItemArticleAdd {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (
        qw(ItemID ArticleID Title Description PiceReal PicePublic Tax Discount Price UserID)
        )
    {
        if ( !defined $Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # set owner_id undef if not present
    $Param{OwnerID} = undef if !$Param{OwnerID};

    # insert new item article
    return if !$Kernel::OM->Get('Kernel::System::DB')->Do(
        SQL => '
            INSERT INTO finance_item_article (item_id, article_id, title, situation,
                description, comments, pice_real, pice_public, tax, discount, price,
                owner_id, create_time, create_by, change_time, change_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, current_timestamp, ?,
                current_timestamp, ?)
        ',
        Bind => [
            \$Param{ItemID},    \$Param{ArticleID},   \$Param{Title},
            \$Param{Situation}, \$Param{Description}, \$Param{Comment},
            \$Param{PiceReal},  \$Param{PicePublic},  \$Param{Tax}, \$Param{Discount},
            \$Param{Price},     \$Param{OwnerID},     \$Param{UserID}, \$Param{UserID},
        ],
    );

    # delete cache
    $Kernel::OM->Get('Kernel::System::Cache')->CleanUp(
        Type => $Self->{CacheType},
    );

    return 1;
}

sub ItemArticleUpdate {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (
        qw(
        ItemArticleID ItemID ArticleID Title Description
        PiceReal PicePublic Tax Discount Price UserID
        )
        )
    {
        if ( !defined $Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!",
            );
            return;
        }
    }

    # set owner_id undef if not present
    $Param{OwnerID} = undef if !$Param{OwnerID};

    # update the item article
    return if !$Kernel::OM->Get('Kernel::System::DB')->Do(
        SQL => '
            UPDATE finance_item_article
            SET item_id = ?, article_id = ?, title = ?, situation = ?, description = ?,
                comments = ?, pice_real = ?, pice_public = ?, tax = ?, discount = ?,
                price = ?, owner_id = ?, change_time = current_timestamp, change_by = ?
            WHERE id = ?
        ',
        Bind => [
            \$Param{ItemID}, \$Param{ArticleID}, \$Param{Title}, \$Param{Situation},
            \$Param{Description}, \$Param{Comment}, \$Param{PiceReal},
            \$Param{PicePublic},  \$Param{Tax},     \$Param{Discount}, \$Param{Price},
            \$Param{OwnerID},     \$Param{UserID},  \$Param{ItemArticleID},
        ],
    );

    # delete cache
    $Kernel::OM->Get('Kernel::System::Cache')->CleanUp(
        Type => $Self->{CacheType},
    );

    return 1;
}

sub ItemArticleDelete {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (qw(ItemArticleID UserID)) {
        if ( !defined $Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # delete the item article
    return if !$Kernel::OM->Get('Kernel::System::DB')->Do(
        SQL => '
            DELETE FROM finance_item_article
            WHERE id = ?
        ',
        Bind => [ \$Param{ItemArticleID} ],
    );

    # delete cache
    $Kernel::OM->Get('Kernel::System::Cache')->CleanUp(
        Type => $Self->{CacheType},
    );

    return 1;
}

sub ItemArticleGet {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (qw(ItemArticleID UserID)) {
        if ( !$Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    # check cache
    my $CacheKey = 'ItemArticleGet-' . $Param{ItemArticleID};
    my $Cache    = $CacheObject->Get(
        Key  => $CacheKey,
        Type => $Self->{CacheType},
    );

    return %{$Cache} if $Cache;

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # ask the database
    return if !$DBObject->Prepare(
        SQL => '
            SELECT id, item_id, article_id, title, situation, description, comments, tax,
                discount, price, pice_real, pice_public, owner_id, create_time, create_by,
                change_time, change_by
            FROM finance_item_article
            WHERE id = ?
        ',
        Bind  => [ \$Param{ItemArticleID} ],
        Limit => 1,
    );

    # fetch the result
    my %Data;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        $Data{ItemArticleID} = $Row[0];
        $Data{ItemID}        = $Row[1];
        $Data{ArticleID}     = $Row[2];
        $Data{Title}         = $Row[3];
        $Data{Situation}     = $Row[4];
        $Data{Description}   = $Row[5];
        $Data{Comment}       = $Row[6];
        $Data{Tax}           = $Row[7];
        $Data{Discount}      = $Row[8];
        $Data{Price}         = $Row[9];
        $Data{PiceReal}      = $Row[10];
        $Data{PicePublic}    = $Row[11];
        $Data{OwnerID}       = $Row[12];
        $Data{Created}       = $Row[13];
        $Data{CreatedBy}     = $Row[14];
        $Data{Changed}       = $Row[15];
        $Data{ChangedBy}     = $Row[16];
    }

    return if !%Data;

    # set default real price
    $Data{PiceReal} ||= $Data{PicePublic};

    $Data{Total} = $Data{PicePublic} * $Data{Price};
    $Data{Total} = $Data{Total} / 100 * ( 100 - $Data{Discount} );
    $Data{Total} =~ s/^(.*\.\d\d).+?$/$1/;

    if ( $Data{Total} =~ /\.(\d\d|\d)$/ ) {
        my $Length = 1 - ( length($1) || 0 );
        while ( $Length == 0 ) {
            $Length = $Length - 1;
            $Data{Total} .= '0';
        }
    }
    else {
        $Data{Total} .= '.00';
    }

    $Data{TotalInclTax} = ( $Data{Total} / 100 * ( 100 + $Data{Tax} ) );
    $Data{TotalInclTax} =~ s/^(.*\.\d\d).+?$/$1/;

    my %Article = $Self->ArticleGet(
        ArticleID => $Data{ArticleID},
        UserID    => $Param{UserID},
    );

    $Data{ArticleTitle} = $Article{Title};

    # set cache
    $CacheObject->Set(
        Key   => $CacheKey,
        Value => \%Data,
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
    );

    return %Data;
}

sub ArticleList {
    my ( $Self, %Param ) = @_;

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    # check cache
    my $CacheKey = 'ArticleList';
    my $Cache    = $CacheObject->Get(
        Key  => $CacheKey,
        Type => $Self->{CacheType},
    );

    return %{$Cache} if $Cache;

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # ask database
    return if !$DBObject->Prepare(
        SQL => '
            SELECT id, number, title
            FROM finance_article
            WHERE valid_id = 1
        ',
    );

    # fetch the result
    my %Data;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        $Data{ $Row[0] } = "$Row[1] $Row[2]";
    }

    # set cache
    $CacheObject->Set(
        Key   => $CacheKey,
        Value => \%Data,
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
    );

    return %Data;
}

sub ArticleGet {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (qw(ArticleID UserID)) {
        if ( !$Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    # check cache
    my $CacheKey = 'ArticleGet-' . $Param{ArticleID};
    my $Cache    = $CacheObject->Get(
        Key  => $CacheKey,
        Type => $Self->{CacheType},
    );

    return %{$Cache} if $Cache;

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # ask database
    return if !$DBObject->Prepare(
        SQL => '
            SELECT id, number, title, situation, description, comments, discount,
                tax, price, valid_id, create_time, create_by, change_time, change_by
            FROM finance_article
            WHERE id = ?
        ',
        Bind => [ \$Param{ArticleID} ],
    );

    # fetch the result
    my %Data;
    while ( my @Row = $DBObject->FetchrowArray() ) {
        $Data{ArticleID}   = $Row[0];
        $Data{Number}      = $Row[1];
        $Data{Title}       = $Row[2];
        $Data{Situation}   = $Row[3];
        $Data{Description} = $Row[4];
        $Data{Comment}     = $Row[5];
        $Data{Discount}    = $Row[6];
        $Data{Tax}         = $Row[7];
        $Data{Price}       = $Row[8];
        $Data{ValidID}     = $Row[9];
        $Data{Created}     = $Row[10];
        $Data{CreatedBy}   = $Row[11];
        $Data{Changed}     = $Row[12];
        $Data{ChangedBy}   = $Row[12];
    }

    # set cache
    $CacheObject->Set(
        Key   => $CacheKey,
        Value => \%Data,
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
    );

    return %Data;
}

sub TimeAccountingSync {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Item (qw(ItemID UserID)) {
        if ( !$Param{$Item} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Item!"
            );

            return;
        }
    }

    # create needed objects
    my $TimeAccountingObject = $Kernel::OM->Get('Kernel::System::TimeAccounting');
    my $CustomerUserObject   = $Kernel::OM->Get('Kernel::System::CustomerUser');

    # get item
    my %Item = $Self->ItemGet(
        ItemID => $Param{ItemID},
        UserID => $Param{UserID},
    );

    # get customer user data
    my %Customer;
    if ( $Item{CustomerUserID} ) {
        %Customer = $CustomerUserObject->CustomerUserDataGet(
            User => $Item{CustomerUserID},
        );
    }
    $Customer{UserCustomerID} ||= '';

    $Item{Number} = sprintf( "%04d", $Item{Number} );
    my $StringMatch  = "PROJECT#$Item{Number} -";
    my $StringUpdate = "PROJECT#$Item{Number} - $Customer{UserCustomerID} - $Item{Title}";

    # get project settings
    my %Projects = $TimeAccountingObject->ProjectSettingsGet();

    my $AddNew = 1;
    if (%Projects) {

        PROJECTID:
        for my $ProjectID ( sort keys %{ $Projects{Project} } ) {

            if ( $Projects{Project}->{$ProjectID} =~ /^\Q$StringMatch\E/i ) {

                # update project setting
                $TimeAccountingObject->ProjectSettingsUpdate(
                    ID                 => $ProjectID,
                    Project            => $StringUpdate,
                    ProjectDescription => $Projects{ProjectDescription}->{$ProjectID}
                        || 'auto sync',
                    ProjectStatus => 1,
                );

                $AddNew = 0;

                last PROJECTID;
            }
        }
    }

    # add new project setting
    if ($AddNew) {
        $TimeAccountingObject->ProjectSettingsInsert(
            Project       => $StringUpdate,
            ProjectStatus => 1,
        );
    }

    return 1;
}

1;

=back

=head1 TERMS AND CONDITIONS

This software is part of the OTRS project (L<http://otrs.org/>).

This software comes with ABSOLUTELY NO WARRANTY. For details, see
the enclosed file COPYING for license information (AGPL). If you
did not receive this file, see L<http://www.gnu.org/licenses/agpl.txt>.

=cut

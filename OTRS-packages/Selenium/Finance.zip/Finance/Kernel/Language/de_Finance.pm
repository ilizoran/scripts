# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::Language::de_Finance;

use strict;
use warnings;
use utf8;

sub Data {
    my $Self = shift;

    # Template: AgentFinance
    $Self->{Translation}->{'Year Navigation'} = '';
    $Self->{Translation}->{'Current situation'} = '';
    $Self->{Translation}->{'Implementation'} = '';
    $Self->{Translation}->{'Internal'} = '';
    $Self->{Translation}->{'Job Owner'} = '';
    $Self->{Translation}->{'Total'} = '';
    $Self->{Translation}->{'Tax'} = '';
    $Self->{Translation}->{'Planned'} = '';
    $Self->{Translation}->{'Article #'} = '';
    $Self->{Translation}->{'Effort (Real)'} = '';
    $Self->{Translation}->{'Effort (Customer)'} = '';
    $Self->{Translation}->{'Price'} = '';
    $Self->{Translation}->{'Discount'} = '';
    $Self->{Translation}->{'%'} = '';
    $Self->{Translation}->{'Current Situation? Current Problem?'} = '';
    $Self->{Translation}->{'What need to be changed? What need to be done? Implementation'} = '';
    $Self->{Translation}->{'New Position'} = '';
    $Self->{Translation}->{'#'} = '';
    $Self->{Translation}->{'N. Action'} = '';
    $Self->{Translation}->{'Probab.'} = '';
    $Self->{Translation}->{'Proces.'} = '';
    $Self->{Translation}->{'Volume'} = '';
    $Self->{Translation}->{'Count Positions'} = '';
    $Self->{Translation}->{'Volume Positions'} = '';
    $Self->{Translation}->{'Total Net'} = 'Total Netto';
    $Self->{Translation}->{'Please enter a customer company to make the SupportDB link available.'}
        = 'Sie müssen eine Kunden-Firma angeben, um den SupportDB-Link verfügbar zu machen.';

    # SysConfig
    $Self->{Translation}->{'All parameters for the Finance object in the agent interface.'} = 'Alle Parameter des Finance-Objekts im Agent-Interface.';
    $Self->{Translation}->{'Module to show offer link in menu.'} = 'Über dieses Modul wird der Offer-Link in der Linkleiste der Ticketansicht angezeigt.';
    $Self->{Translation}->{''} = '';

    #
    # OBSOLETE ENTRIES FOR REFERENCE, DO NOT TRANSLATE!
    #

}

1;

# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::System::DynamicField::Driver::Attachment;

use strict;
use warnings;
use YAML;

our @ObjectDependencies = (
    'Kernel::Config',
    'Kernel::Output::HTML::Layout',
    'Kernel::System::DB',
    'Kernel::System::DynamicFieldValue',
    'Kernel::System::Log',
    'Kernel::System::Main',
    'Kernel::System::VirtualFS',
    'Kernel::System::Web::UploadCache',
    'Kernel::System::DynamicField::Backend',
    'Kernel::System::Ticket',
);

use Kernel::System::VariableCheck qw(:all);

use base qw(Kernel::System::DynamicField::Driver::BaseText);

=head1 NAME

Kernel::System::DynamicField::Driver::Attachment

=head1 SYNOPSIS

DynamicFields Attachment Driver delegate

=head1 PUBLIC INTERFACE

This module implements the public interface of L<Kernel::System::DynamicField::Backend>.
Please look there for a detailed reference of the functions.

=over 4

=item new()

usually, you want to create an instance of this
by using Kernel::System::DynamicField::Backend->new();

=cut

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {};
    bless( $Self, $Type );

    # set field behaviors
    $Self->{Behaviors} = {
        'IsACLReducible'               => 0,
        'IsNotificationEventCondition' => 1,
        'IsSortable'                   => 0,
        'IsFiltrable'                  => 0,
        'IsStatsCondition'             => 0,
        'IsCustomerInterfaceCapable'   => 1,
        'IsAttachement'                => 1,
    };

    # get the Dynamic Field Backend custmom extensions
    my $DynamicFieldDriverExtensions
        = $Kernel::OM->Get('Kernel::Config')->Get('DynamicFields::Extension::Driver::Text');

    EXTENSION:
    for my $ExtensionKey ( sort keys %{$DynamicFieldDriverExtensions} ) {

        # skip invalid extensions
        next EXTENSION if !IsHashRefWithData( $DynamicFieldDriverExtensions->{$ExtensionKey} );

        # create a extension config shortcut
        my $Extension = $DynamicFieldDriverExtensions->{$ExtensionKey};

        # check if extension has a new module
        if ( $Extension->{Module} ) {

            # check if module can be loaded
            if ( !$Kernel::OM->Get('Kernel::System::Main')->RequireBaseClass( $Extension->{Module} ) ) {
                die "Can't load dynamic fields backend module"
                    . " $Extension->{Module}! $@";
            }
        }

        # check if extension contains more behabiors
        if ( IsHashRefWithData( $Extension->{Behaviors} ) ) {

            %{ $Self->{Behaviors} } = (
                %{ $Self->{Behaviors} },
                %{ $Extension->{Behaviors} }
            );
        }
    }

    return $Self;
}

=item ValueGet()

returns a hash holding the file as well as it's info

    my $Attachment = $DynamicFieldDriver->ValueGet(
        DynamicFieldConfig     => \%DynamicFieldConfig,
        ObjectID               => $ObjectID,            # TicketID or ArticleID
        Download               => 0,                    # or 1, optional, returns file + info if 1
        Filename               => 'StarryNight.jpg',    # Required if Download == 1
    );

=cut

sub ValueGet {
    my ( $Self, %Param ) = @_;
    my $Download = $Param{Download} || 0;

    for my $Needed (qw(DynamicFieldConfig ObjectID)) {
        if ( !$Param{$Needed} ) {

            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Got no $Needed in DynamicField Driver Attachment ValueGet!",
            );

            return;
        }

    }

    my $DFValue = $Kernel::OM->Get('Kernel::System::DynamicFieldValue')->ValueGet(
        FieldID  => $Param{DynamicFieldConfig}->{ID},
        ObjectID => $Param{ObjectID},
    );

    return if !$DFValue;
    return if !IsArrayRefWithData($DFValue);
    return if !IsHashRefWithData( $DFValue->[0] );

    # extract real values
    my @ReturnData;
    for my $Item ( @{$DFValue} ) {
        push @ReturnData, YAML::Load( $Item->{ValueText} ) || {};
    }

    if ( !$Download ) {
        return \@ReturnData;
    }

    for my $Needed (qw(Filename)) {
        if ( !$Needed ) {

            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => 'Got no $Needed in DynamicField Driver Attachment ValueGet!',
            );
            return;
        }
    }
    my @FileFound = grep { $Param{Filename} eq $_->{Filename} } @ReturnData;

    my $StorageLocation = 'DynamicField/' . $Param{DynamicFieldConfig}->{ID} . '/'
        . $Param{DynamicFieldConfig}->{ObjectType} . '/'
        . $Param{ObjectID} . '/' . $Param{Filename};

    # Check if we found the file we have to download, and if that recors has a StorageLocation
    if (
        !@FileFound
        || !IsHashRefWithData( $FileFound[0] )
        || !length $FileFound[0]->{StorageLocation}
        || $StorageLocation ne $FileFound[0]->{StorageLocation}
        )
    {

        $Kernel::OM->Get('Kernel::System::Log')->Log(
            Priority => 'error',
            Message =>
                'Could not validate $Param{Filename} in DynamicFieldAttachment ValueGetDownload!',
        );

        return;
    }

    # get virtualfs object
    my $VirtualFSObject = $Kernel::OM->Get('Kernel::System::VirtualFS');

    # find all attachments of this change
    my @Attachments = $VirtualFSObject->Find(
        Filename    => $FileFound[0]->{StorageLocation},
        Preferences => {
            ObjectID => $Param{ObjectID},
        },
    );

    # return error if file does not exist
    if ( !@Attachments ) {
        $Kernel::OM->Get('Kernel::System::Log')->Log(
            Message  => "No such attachment ($FileFound[0]->{StorageLocation})!",
            Priority => 'error',
        );
        return;
    }

    # get data for attachment
    my %AttachmentData = $VirtualFSObject->Read(
        Filename => $FileFound[0]->{StorageLocation},
        Mode     => 'binary',
    );

    my $AttachmentInfo = {
        %AttachmentData,
        Filename    => $FileFound[0]->{Filename},
        Content     => ${ $AttachmentData{Content} },
        ContentType => $AttachmentData{Preferences}->{ContentType},
        Type        => 'attachment',
        Filesize    => $AttachmentData{Preferences}->{Filesize},
    };

    return $AttachmentInfo;
}

sub ValueSet {
    my ( $Self, %Param ) = @_;

    my $FieldName = 'DynamicField_' . $Param{DynamicFieldConfig}->{Name};

    # For storing our values we need a unique directory structure
    # so we're fetching the FieldID (unique)
    my $FieldID = $Param{DynamicFieldConfig}->{ID};

    # as well as the ObjectType (Article or Ticket)
    # which will be used in the directory path
    my $ObjectType = $Param{DynamicFieldConfig}->{ObjectType};

    # get virtualfs object
    my $VirtualFSObject = $Kernel::OM->Get('Kernel::System::VirtualFS');

    # At first let's see if we have already stored values in the Filesystem & Database
    my $ExistingValues = $Self->ValueGet(
        DynamicFieldConfig => $Param{DynamicFieldConfig},
        ObjectID           => $Param{ObjectID},
    );
    my @KeptFiles;
    if ( IsArrayRefWithData($ExistingValues) ) {

        # File deletion part:
        # check if which values we got that were already stored in the database
        # and delete all others
        my $StoredAttachments = $Self->{ 'UploadCacheFilesMeta' . $FieldName };

        # let's loop through the values classically because
        # FileID in StoredAttachments is the counter ID of the existing Files
        for ( my $i = 0, my $Limit = scalar @{$ExistingValues}; $i < $Limit; $i++ ) {

            # now find the StoredValues of our Attachments that's ID equals our Counter ID
            my @Temp = grep { $_->{StoredValue} && $_->{FileID} == $i } @{$StoredAttachments};

            # If we found our file inside StoredAttachments, we have to keep this file,
            # let's take the hash of old values we had stored in the dynamicField
            # for this file and push them into @KeptFiles
            if (@Temp) {

                # overtake the commited Disabled value
                $ExistingValues->[$i]->{Disabled} = $Param{Value}->[$i]->{Disabled};
                push @KeptFiles, $ExistingValues->[$i];
            }
            else {

                # We haven't found the stored file in our newly submitted @StoredAttachments
                # it's deleting time for this file
                # we don't have to care about the old information
                # stored in the dynamic_field_value table, because they get all deleted on
                # ValueSet so we just keep the ones that the user told us to keep

                my $Success = $VirtualFSObject->Delete(
                    Filename => $ExistingValues->[$i]{StorageLocation},
                );
                if ( !$Success ) {
                    $Kernel::OM->Get('Kernel::System::Log')->Log(
                        Priority => 'error',
                        Message  => 'Cannot delete attachment '
                            . $ExistingValues->[$i]{StorageLocation}
                            . ' from VirtualFS',
                    );

                    return;
                }
            }
        }
    }

    my @ValueText;

    # OK for now, if we have values inside @KeptFiles
    # this is the basis for our new Values, so we'll yaml the information
    # and put them into ValueText
    if (@KeptFiles) {
        for my $Item (@KeptFiles) {
            push @ValueText, {
                ValueText => YAML::Dump($Item),
            };
        }
    }

    # then we'll need the UploadFieldUID which was stored in $Self
    # by EditFieldValueGet or EditFieldValueValidate and under which, used as FormID
    # the files were stored via the UploadCacheObject

    # get uploadcache object
    my $UploadCacheObject = $Kernel::OM->Get('Kernel::System::Web::UploadCache');

    my $UploadFieldUID = $Self->{ 'UploadCacheFormID' . $FieldName };
    my @Attachments    = $UploadCacheObject->FormIDGetAllFilesData(
        FormID => $UploadFieldUID,
    );

    for my $Item (@Attachments) {

        # Now we'll try to store the cached object
        # ObjectID = TicketID or ArticleID
        # ObjectType = Ticket or Article
        my $Success = $VirtualFSObject->Write(
            Filename    => "DynamicField/$FieldID/$ObjectType/$Param{ObjectID}/$Item->{Filename}",
            Mode        => 'binary',
            Content     => \$Item->{Content},
            Preferences => {
                ContentID => $Item->{ContentID} || '',
                ContentType => $Item->{ContentType},
                ObjectID    => $Param{ObjectID},
                ObjectType  => $ObjectType,
                UserID      => $Param{UserID},
            },
        );
        if ( !$Success ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Cannot add attachment for $ObjectType $Param{ObjectID}",
            );

            return;
        }
        push @ValueText, {
            ValueText => YAML::Dump(
                {
                    Filename => $Item->{Filename},
                    StorageLocation =>
                        "DynamicField/$FieldID/$ObjectType/$Param{ObjectID}/$Item->{Filename}",
                    Filesize    => $Item->{Filesize},
                    ContentType => $Item->{ContentType},
                    Disabled    => $Item->{Disabled} || 0,
                }
            ),
        };
    }

    # ATTENTION: On AgentTicketProcess double store action could be trigger
    # try to re-enable next lines of code ones the mentioned screen has been reviewed

    # # if all files are stored correctly we'll remove the cached ones
    # $UploadCacheObject->FormIDRemove(
    #     FormID => $UploadFieldUID,
    # );

    my $Success;

    # get dynamicfieldvalue object
    my $DynamicFieldValueObject = $Kernel::OM->Get('Kernel::System::DynamicFieldValue');

    # if all values got deleted we have to call ValueDelete
    # because ValueSet is unable to work on no existing values
    if ( !@ValueText ) {
        $Success = $DynamicFieldValueObject->ValueDelete(
            FieldID  => $Param{DynamicFieldConfig}->{ID},
            ObjectID => $Param{ObjectID},
            UserID   => $Param{UserID},
        );

    }
    else {
        $Success = $DynamicFieldValueObject->ValueSet(
            FieldID  => $Param{DynamicFieldConfig}->{ID},
            ObjectID => $Param{ObjectID},
            Value    => \@ValueText,
            UserID   => $Param{UserID},
        );
    }

    return $Success;
}

sub ValueDelete {
    my ( $Self, %Param ) = @_;

    my $Values = $Self->ValueGet(
        DynamicFieldConfig => $Param{DynamicFieldConfig},
        ObjectID           => $Param{ObjectID},
        UserID             => $Param{UserID},
    );

    # get virtualfs object
    my $VirtualFSObject = $Kernel::OM->Get('Kernel::System::VirtualFS');

    if ( IsArrayRefWithData($Values) ) {
        for my $Item ( @{$Values} ) {
            my $Success = $VirtualFSObject->Delete(
                Filename => $Item->{StorageLocation},
            );
            if ( !$Success ) {
                $Kernel::OM->Get('Kernel::System::Log')->Log(
                    Priority => 'error',
                    Message =>
                        "Cannot delete attachments from $Param{DynamicFieldConfig}->{ObjectType} $Param{ObjectID}",
                );

                return;
            }
        }
    }

    my $Success = $Kernel::OM->Get('Kernel::System::DynamicFieldValue')->ValueDelete(
        FieldID  => $Param{DynamicFieldConfig}->{ID},
        ObjectID => $Param{ObjectID},
        UserID   => $Param{UserID},
    );

    return $Success;
}

sub AllValuesDelete {
    my ( $Self, %Param ) = @_;

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    return if !$DBObject->Prepare(
        SQL => '
            SELECT id, value_text, value_date, value_int
            FROM dynamic_field_value
            WHERE field_id = ?
            ORDER BY id
        ',
        Bind => [ \$Param{DynamicFieldConfig}->{ID} ],
    );
    my @Filenames;
    while ( my @Data = $DBObject->FetchrowArray() ) {
        if ( length $Data[1] ) {
            my $FileInfo = YAML::Load( $Data[1] );
            if ( IsHashRefWithData($FileInfo) && length $FileInfo->{StorageLocation} ) {
                push @Filenames, $FileInfo->{StorageLocation};
            }
        }
    }

    # get virtualfs object
    my $VirtualFSObject = $Kernel::OM->Get('Kernel::System::VirtualFS');

    for my $Filename (@Filenames) {
        my $Success = $VirtualFSObject->Delete(
            Filename => $Filename,
        );
        if ( !$Success ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                'Priority' => 'error',
                'Message'  => "Could not delete $Filename",
            );
            return $Success;
        }
    }

    my $Success = $Kernel::OM->Get('Kernel::System::DynamicFieldValue')->AllValuesDelete(
        FieldID => $Param{DynamicFieldConfig}->{ID},
        UserID  => $Param{UserID},
    );

    return $Success;
}

sub ValueValidate {
    my ( $Self, %Param ) = @_;

    # check value
    my @Values;
    if ( IsArrayRefWithData( $Param{Value} ) ) {
        @Values = @{ $Param{Value} };
    }
    else {
        @Values = ( $Param{Value} );
    }

    # get dynamicfieldvalue object
    my $DynamicFieldValueObject = $Kernel::OM->Get('Kernel::System::DynamicFieldValue');

    my $Success;
    for my $Item (@Values) {

        $Success = $DynamicFieldValueObject->ValueValidate(
            Value => {
                ValueText => $Item,
            },
            UserID => $Param{UserID}
        );
        return if !$Success
    }
    return $Success;
}

sub SearchSQLGet {
    my ( $Self, %Param ) = @_;

    my %Operators = (
        Equals            => '=',
        GreaterThan       => '>',
        GreaterThanEquals => '>=',
        SmallerThan       => '<',
        SmallerThanEquals => '<=',
    );

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    if ( $Operators{ $Param{Operator} } ) {
        my $SQL = " $Param{TableAlias}.value_text $Operators{$Param{Operator}} '";
        $SQL .= $DBObject->Quote( $Param{SearchTerm} ) . "' ";
        return $SQL;
    }

    if ( $Param{Operator} eq 'Like' ) {

        my $SQL = $DBObject->QueryCondition(
            Key   => "$Param{TableAlias}.value_text",
            Value => $Param{SearchTerm},
        );

        return $SQL;
    }

    $Kernel::OM->Get('Kernel::System::Log')->Log(
        'Priority' => 'error',
        'Message'  => "Unsupported Operator $Param{Operator}",
    );

    return;
}

sub SearchSQLOrderFieldGet {
    my ( $Self, %Param ) = @_;

    return "$Param{TableAlias}.value_text";
}

sub EditFieldRender {
    my ( $Self, %Param ) = @_;

    # get needed objects
    my $LayoutObject = $Kernel::OM->Get('Kernel::Output::HTML::Layout');

    # take config from field config
    my $FieldConfig = $Param{DynamicFieldConfig}->{Config};
    my $FieldName   = 'DynamicField_' . $Param{DynamicFieldConfig}->{Name};
    my $FieldLabel  = $Param{DynamicFieldConfig}->{Label};

    my $UploadFieldUID = $Param{ParamObject}->GetParam( Param => "${FieldName}UID" );

    # Flag if we are dealing with an erroneous submit or a new edit request
    my $NewForm = 0;

    # create form id
    if ( !$UploadFieldUID ) {
        $UploadFieldUID = $Kernel::OM->Get('Kernel::System::Web::UploadCache')->FormIDCreate();
        $NewForm        = 1;
    }

    # check value
    my @Values;
    if ( ref $Param{Value} eq 'ARRAY' ) {
        @Values = @{ $Param{Value} };
    }

    # check and set class if necessary
    my $FieldClass = 'DynamicFieldAttachment';
    if ( defined $Param{Class} && $Param{Class} ne '' ) {
        $FieldClass .= ' ' . $Param{Class};
    }

    # set PossibleValues
    my $SelectionData = $FieldConfig->{PossibleValues};

    # use PossibleValuesFilter if defined
    $SelectionData = $Param{PossibleValuesFilter}
        if defined $Param{PossibleValuesFilter};

    # set PossibleNone attribute
    my $FieldPossibleNone;
    if ( defined $Param{OverridePossibleNone} ) {
        $FieldPossibleNone = $Param{OverridePossibleNone};
    }
    else {
        $FieldPossibleNone = $FieldConfig->{PossibleNone} || 0;
    }

    my $NumberOfFiles   = $FieldConfig->{NumberOfFiles}   || 16;
    my $MaximumFileSize = $FieldConfig->{MaximumFileSize} || 20;
    my $Undeletable     = $FieldConfig->{Undeletable}     || 0;
    my $ServerErrorHTML = '';

    if ( $Param{ServerError} ) {
        my $ErrorMessage = '';
        if ( IsHashRefWithData( $Param{ErrorMessage} ) ) {

            for my $Key ( sort keys %{ $Param{ErrorMessage} } ) {
                if ( $Key eq 'Filesize' && IsArrayRefWithData( $Param{ErrorMessage}->{Filesize} ) )
                {
                    $ErrorMessage
                        .= $LayoutObject->{LanguageObject}->Get(
                        'The following attachments were removed because they were bigger than the allowed size of '
                        )
                        . $MaximumFileSize . ' '
                        . $LayoutObject->{LanguageObject}->Get('MB') . ': '
                        . join(
                        '',
                        map { '<p>' . $LayoutObject->{LanguageObject}->Get($_) . '</p>' }
                            @{ $Param{ErrorMessage}->{Filesize} }
                        );
                }
                if ( $Key eq 'Filename' && IsArrayRefWithData( $Param{ErrorMessage}->{Filename} ) )
                {
                    $ErrorMessage
                        .= $LayoutObject->{LanguageObject}->Get(
                        'Attachments with the same name as the following names were already present and got deleted.'
                        )
                        . join(
                        '',
                        map { '<p>' . $LayoutObject->{LanguageObject}->Get($_) . '</p>' }
                            @{ $Param{ErrorMessage}->{Filename} }
                        );
                }
            }

        }

        else {
            $ErrorMessage = $LayoutObject->{LanguageObject}->Get( $Param{ErrorMessage} )
                || 'This field is required.';
        }

        # for server side validation
        $ServerErrorHTML .= <<"EOF";
        <div class="Tooltip TongueLeft">
            <div class="Tongue" ></div>
            <div class="Content" role="tooltip" style="word-wrap: break-word;">
                <p>
                    $ErrorMessage
                </p>
            </div>
        </div>
EOF
    }

    my $HTMLString = <<"EOF";
    $ServerErrorHTML
    <div id="${FieldName}Div" style="padding: 0px; border: 0px;">
        <input type="hidden" id="${FieldName}NumberOfFiles" name="${FieldName}NumberOfFiles" value="$NumberOfFiles" />
        <input type="hidden" id="${FieldName}UID" name="${FieldName}UID" value="$UploadFieldUID" />
EOF
    my $Counter     = 0;
    my $DeleteText  = $LayoutObject->{LanguageObject}->Get('Delete');
    my $DisableText = $LayoutObject->{LanguageObject}->Get('Disable');

    # We put in Database Values just if we have a new form,
    # not a resubmitted one
    if ( @Values && $NewForm ) {
        for my $Item (@Values) {
            my $Filename = $Item->{Filename};
            my $FileID   = $Item->{FileID};
            my $Disabled = $Item->{Disabled};
            my $DivClass = '';
            if ($Disabled) {
                $DivClass .= ' class="Disabled" style="color: lightgray;"';
            }

            $HTMLString .= <<"EOF";
        <div id="${FieldName}_div${Counter}"$DivClass style="padding: 0px;">
            <input class="$FieldClass" id="${FieldName}${Counter}Disabled" type="hidden" name="${FieldName}${Counter}Disabled" value="${Disabled}">
            <input class="$FieldClass" id="${FieldName}${Counter}" type="hidden" size="40" name="${FieldName}${Counter}" value="${Counter}Stored${Filename}">${Filename}
EOF
            if ($Undeletable) {
                if ( !$Disabled ) {
                    $HTMLString .= <<"EOF";
            <input id="Disable${FieldName}${Counter}" class="DisableDynamicFieldAttachment" type="Button" value="$DisableText" />
EOF
                }
            }
            else {
                $HTMLString .= <<"EOF";
            <input id="Delete${FieldName}${Counter}" class="DeleteDynamicFieldAttachment" type="Button" value="$DeleteText" />
EOF
            }

            $HTMLString .= <<"EOF";
        </div>
EOF
            $Counter++;
        }
    }
    if ( IsArrayRefWithData( $Self->{ 'UploadCacheFilesMeta' . $FieldName } ) ) {
        for my $Item ( @{ $Self->{ 'UploadCacheFilesMeta' . $FieldName } } ) {

            # if we're dealing with a Value alread stored in the database
            if ( $Item->{StoredValue} ) {
                my $Filename = $Item->{Filename};
                my $FileID   = $Item->{FileID};
                my $Disabled = $Item->{Disabled};
                my $DivClass = '';
                if ($Disabled) {
                    $DivClass .= ' class="Disabled" style="color: lightgray;"';
                }

                $HTMLString .= <<"EOF";
        <div id="${FieldName}_div${Counter}"$DivClass style="padding:0px;">
            <input class="$FieldClass" id="${FieldName}${Counter}Disabled" type="hidden" name="${FieldName}${Counter}Disabled" value="${Disabled}">
            <input class="$FieldClass" id="${FieldName}${Counter}" type="hidden" size="40" name="${FieldName}${Counter}" value="${FileID}Stored${Filename}">${Filename}
EOF
                if ($Undeletable) {
                    if ( !$Disabled ) {
                        $HTMLString .= <<"EOF";
            <input id="Disable${FieldName}${Counter}" class="DisableDynamicFieldAttachment" type="Button" value="${DisableText}" />
EOF
                    }
                }
                else {
                    $HTMLString .= <<"EOF";
          <input id="Delete${FieldName}${Counter}" class="DeleteDynamicFieldAttachment" type="Button" value="${DeleteText}" />
EOF
                }

                $HTMLString .= <<"EOF";
        </div>
EOF
                $Counter++;
            }

            # else it was an uploaded value
            else {
                my $Filename = $Item->{Filename};
                my $FileID   = $Item->{FileID};
                $HTMLString .= <<"EOF";
        <div id="${FieldName}_div${Counter}" style="padding:0px;">
            <input class="$FieldClass" id="${FieldName}${Counter}" type="file" size="40" name="${FieldName}${Counter}">
            <input id="Delete${FieldName}${Counter}" class="DeleteDynamicFieldAttachment" type="Button" value="${DeleteText}" />
        </div>
EOF
                $Counter++;
            }
        }
    }
    if ( $Counter < $NumberOfFiles ) {
        $HTMLString .= <<"EOF";
        <div id="${FieldName}_div${Counter}" style="padding:0px;">
            <input class="$FieldClass" id="${FieldName}${Counter}" type="file" size="40" name="${FieldName}${Counter}">
            <input id="Delete${FieldName}${Counter}" class="DeleteDynamicFieldAttachment" type="Button" value="${DeleteText}" />
        </div>
EOF
    }

    my $TextWarning = $LayoutObject->{LanguageObject}->Get(
        'You are going to disable at least one attachment. This procedure is irreversible! Are you sure you want to disable the selected attachments?'
    );

    $HTMLString .= <<"EOF";
    </div>
    <div id="DynamicFieldAttachmentDisableConfirmDialog" class="Hidden">
        <div class="Center">
            <p class="Warning">
                $TextWarning
            </p>
        </div>
    </div>
EOF

    # add js to call FormUpdate()
    my $JSCode = '
    $(".Field, fieldset").on("change", ".DynamicFieldAttachment", Core.Agent.DynamicField.Attachment.AddField);
    $(".Field, fieldset").on("click", ".DeleteDynamicFieldAttachment", Core.Agent.DynamicField.Attachment.DeleteField);
    ';

    if ($Undeletable) {

        # add js to call FormUpdate()
        my $JSCode .= '
        $(".Field, fieldset").on("click", ".DisableDynamicFieldAttachment", Core.Agent.DynamicField.Attachment.DisableField);
        ';
    }

    if ( $Param{AJAXUpdate} ) {

        my $FieldSelector = '#' . $FieldName;

        my $FieldsToUpdate = '';
        if ( IsArrayRefWithData( $Param{UpdatableFields} ) ) {
            my $FirstItem = 1;
            FIELD:
            for my $Field ( @{ $Param{UpdatableFields} } ) {
                next FIELD if $Field eq $FieldName;
                if ($FirstItem) {
                    $FirstItem = 0;
                }
                else {
                    $FieldsToUpdate .= ', ';
                }
                $FieldsToUpdate .= "'" . $Field . "'";
            }
        }

        # add js to call FormUpdate()
        my $JSCode .= '
//    $("$FieldSelector").bind("change", function (Event) {
//        Core.AJAX.FormUpdate($(this).parents("form"), "AJAXUpdate", "$FieldName", [ $FieldsToUpdate ]);
//    });
        ';
    }

    $LayoutObject->AddJSOnDocumentComplete( Code => $JSCode );

    # call EditLabelRender on the base driver
    my $LabelString = $Self->EditLabelRender(
        %Param,
        DynamicFieldConfig => $Param{DynamicFieldConfig},
        Mandatory          => $Param{Mandatory} || '0',
        FieldName          => $FieldName,
    );

    my $Data = {
        Field => $HTMLString,
        Label => $LabelString,
    };

    return $Data;
}

sub EditFieldValueGet {
    my ( $Self, %Param ) = @_;

    # if we don't have a ParamObject
    # we were called not by a FormSubmit
    # so there are no Params to get and return
    #
    # this is the case for GenericAgent.pm
    # which can fill DynamicFields with template values
    #
    # As long as we can't provide files in Templates
    # that should get stored in here
    # we can return undef
    if ( !$Param{ParamObject} ) {
        return;
    }

    my $FieldName = 'DynamicField_' . $Param{DynamicFieldConfig}->{Name};

    # We store processed uploaded files meta data on the object
    # in order to reduce mysql requests
    if ( IsArrayRefWithData( $Self->{ 'UploadCacheFilesMeta' . $FieldName } ) ) {
        return $Self->{ 'UploadCacheFilesMeta' . $FieldName };
    }

    # just to make sure that we don't end in an infinite loop default it to 16
    my $NumberOfFiles = $Param{DynamicFieldConfig}->{NumberOfFiles} || 16;

    my $MaximumFileSize = $Param{DynamicFieldConfig}->{MaximumFileSize} || 20;

    my $UploadFieldUID = $Param{ParamObject}->GetParam( Param => "${FieldName}UID" );

    # if we didn't have a UID we haven't been called by a submit
    # this shouldn't happen
    my $ObjectID = $Param{ParamObject}->GetParam( Param => $Param{DynamicFieldConfig}->{ObjectType} . 'ID' );
    if ( !$UploadFieldUID ) {
        if ($ObjectID) {
            return $Self->ValueGet(
                FieldID  => $Param{DynamicFieldConfig}->{ID},
                ObjectID => $ObjectID,
                %Param,
            );
        }
        else {
            return [];
        }
    }

    my $Value;
    my @StoredAttachments;
    my $OldStoredAttachments;
    if ($ObjectID) {
        $OldStoredAttachments = $Self->ValueGet(
            FieldID  => $Param{DynamicFieldConfig}->{ID},
            ObjectID => $ObjectID,
            %Param,
        );
    }

    # if we are dealing with a value we had in the database from an earlier submit/change
    for ( my $i = 0; $i < $NumberOfFiles; $i++ ) {

        # the submitted value looks like 0StoredMyFile.pdf
        # where 0 is the inded of the stored values and all after "Stored" is the Filename
        # we need this to delete gui-deleted files from storage
        # filename necessary to have enough info for displaying the entry on an erroneous submit
        # and ServerError Displaying
        my $FileID = $Param{ParamObject}->GetParam( Param => $FieldName . $i );
        my $Disabled = $Param{ParamObject}->GetParam( Param => $FieldName . $i . 'Disabled' ) || 0;

        if (
            $FileID
            && $FileID =~ /^(\d+)Stored(.*)/
            && IsArrayRefWithData($OldStoredAttachments)
            && IsHashRefWithData( $OldStoredAttachments->[$1] )
            )
        {
            push @StoredAttachments, {
                FileID      => $1,
                Filename    => $2,
                Filesize    => $OldStoredAttachments->[$1]{Filesize},
                ContentType => $OldStoredAttachments->[$1]{ContentType},
                StoredValue => 1,
                Disabled    => $Disabled,
            };
        }
    }

    # get uploadcache object
    my $UploadCacheObject = $Kernel::OM->Get('Kernel::System::Web::UploadCache');

    # Get old stored UploadCache files Metainfo
    my @Attachments = $UploadCacheObject->FormIDGetAllFilesMeta(
        FormID => $UploadFieldUID,
    );

    # If there were old stored filed, we have to check
    # which of the UploadCache files are still here after an erroneous submit
    # and possible reduction of cached values
    if (@Attachments) {
        my %RemainingAttachments;
        for ( my $i = 0; $i < $NumberOfFiles; $i++ ) {
            my $FileID = $Param{ParamObject}->GetParam( Param => $FieldName . $i );
            if ( $FileID && $FileID =~ /^\d+$/ ) {
                $RemainingAttachments{$FileID} = 1;
            }
        }

        # Loop through the old Attachments and delete those
        # that haven't been submitted any more
        for my $Item (@Attachments) {
            if ( !$RemainingAttachments{ $Item->{FileID} } ) {
                $UploadCacheObject->FormIDRemoveFile(
                    FormID => $UploadFieldUID,
                    FileID => $Item->{FileID},
                );
            }
        }
    }

    # Classic for loop with counter because:
    # fields start at id 0
    # $MaximumFiles whereas is the total number of files
    # Additionally we need the nuber for UploadFieldName generation
    NUMBERFILE:
    for ( my $i = 0; $i < $NumberOfFiles; $i++ ) {

        my %UploadFile = $Param{ParamObject}->GetUploadAll(
            Param  => $FieldName . $i,
            Source => 'string',
        );

        # If we had no content in the upload field
        # let's try the next one (not all inputs have fields
        # dealing with an existing cached file for example)
        if ( !IsHashRefWithData( \%UploadFile ) ) {
            next NUMBERFILE;
        }
        push @{$Value}, {%UploadFile};
        $UploadCacheObject->FormIDAddFile(
            %UploadFile,
            FormID => $UploadFieldUID,
        );
    }

    @Attachments = $UploadCacheObject->FormIDGetAllFilesMeta(
        FormID => $UploadFieldUID,
    );

    # now let's bring together the info about the old stored attachments as well as the uploaded ones
    @Attachments = ( @StoredAttachments, @Attachments );
    $Self->{ 'UploadCacheFilesMeta' . $FieldName } = \@Attachments;
    $Self->{ 'UploadCacheFormID' . $FieldName }    = $UploadFieldUID;
    return \@Attachments;
}

sub EditFieldValueValidate {
    my ( $Self, %Param ) = @_;

    # get the field value from the http request
    my $Values = $Self->EditFieldValueGet(
        DynamicFieldConfig => $Param{DynamicFieldConfig},
        ParamObject        => $Param{ParamObject},

        # not necessary for this backend but place it for consistency reasons
        ReturnValueStructure => 1,
    );
    my $FieldName = 'DynamicField_' . $Param{DynamicFieldConfig}->{Name};
    my $ServerError;
    my %ErrorMessage;
    my %CheckFilenames;

    # perform necessary validations
    if ( $Param{Mandatory} && !IsArrayRefWithData($Values) && !IsHashRefWithData( $Values->[0] ) ) {
        my $Result = {
            ServerError  => 1,
            ErrorMessage => 'This field is required.',
        };
        return $Result;
    }
    else {

        # get maximum filesize values list
        my $MaximumFileSize  = $Param{DynamicFieldConfig}->{Config}->{MaximumFileSize} || 20;
        my $MaxFileSizeBytes = $MaximumFileSize * 1024 * 1024;
        my $UploadFieldUID   = $Self->{ 'UploadCacheFormID' . $FieldName };
        if ( !$UploadFieldUID ) {
            $UploadFieldUID = $Param{ParamObject}->GetParam( Param => "${FieldName}UID" );
            if ($UploadFieldUID) {
                $Self->{ 'UploadCacheFormID' . $FieldName } = $UploadFieldUID;
            }
            else {
                $Kernel::OM->Get('Kernel::System::Log')->Log(
                    Priority => 'error',
                    Message  => "Couldn't get DynamicFieldUID!",
                );
                return {
                    ServerError => 1,
                };
            }
        }

        # Hash holding all deleted item's FileID's
        # needed to clenaup $Self->{ 'UploadCacheFilesMeta' . $FieldName } after file deletion
        # withouth doing an additional sql query, because UploadCacheObject doesn't cache it's meta contents
        my %Deleted;

        # get uploadcache object
        my $UploadCacheObject = $Kernel::OM->Get('Kernel::System::Web::UploadCache');

        # validate if value is in possible values list (but let pass empty values)
        VALUESLOOP:
        for my $Item ( @{$Values} ) {

            # Check if a file with the same name already exists and delete it from the upload cache + error out
            if ( $CheckFilenames{ $Item->{Filename} } ) {
                $Deleted{ $Item->{FileID} } = 1;
                $UploadCacheObject->FormIDRemoveFile(
                    FormID => $UploadFieldUID,
                    FileID => $Item->{FileID},
                );
                $ServerError = 1;
                push @{ $ErrorMessage{Filename} }, $Item->{Filename};
            }

            # If we are dealing with a value we already had in the Database
            # no validation
            my $Filesize      = $Item->{Filesize};
            my $FilesizeBytes = 0;
            if ( $Filesize =~ s{([0-9,.]+) \s+ MBytes}{$1}xms ) {
                $FilesizeBytes = $1 * 1024 * 1024;
            }
            elsif ( $Filesize =~ s{([0-9,.]+)\s+KBytes}{$1}xms ) {
                $FilesizeBytes = $1 * 1024;
            }
            elsif ( $Filesize =~ s{([0-9,.]+)\s+Bytes}{$1}xms ) {
                $FilesizeBytes = $Filesize;
            }
            else {
                $Kernel::OM->Get('Kernel::System::Log')->Log(
                    Priority => 'error',
                    Message  => "DynamicField Backend File could not detect file size!",
                );
                return {
                    ServerError => 1,
                };
            }

            if ( $FilesizeBytes > $MaxFileSizeBytes ) {
                $Deleted{ $Item->{FileID} } = 1;
                $UploadCacheObject->FormIDRemoveFile(
                    FormID => $UploadFieldUID,
                    FileID => $Item->{FileID},
                );
                $ServerError = 1;
                push @{ $ErrorMessage{Filesize} }, $Item->{Filename};
            }
            $CheckFilenames{ $Item->{Filename} } = 1;
        }

        # Now let's see if we had deleted items and remove them from the $Self->{ 'UploadCacheFilesMeta' . $FieldName }
        # StoredValues are not beeing deleted here, deletion will be done on save
        if (%Deleted) {
            @{ $Self->{ 'UploadCacheFilesMeta' . $FieldName } }
                = grep { $_->{StoredValue} || !$Deleted{ $_->{FileID} } } @{$Values};
        }
    }

    # create resulting structure
    my $Result = {
        ServerError  => $ServerError,
        ErrorMessage => \%ErrorMessage,
    };

    return $Result;
}

sub DisplayValueRender {
    my ( $Self, %Param ) = @_;

    # set HTMLOuput as default if not specified
    if ( !defined $Param{HTMLOutput} ) {
        $Param{HTMLOutput} = 1;
    }

    # set Value and Title variables
    my $Value         = '';
    my $Title         = '';
    my $ValueMaxChars = $Param{ValueMaxChars} || '';
    my $TitleMaxChars = $Param{TitleMaxChars} || '';

    # check value
    my @Values;
    if ( ref $Param{Value} eq 'ARRAY' ) {
        @Values = @{ $Param{Value} };
    }

    # return simple string if not HTMLOutput
    if ( !$Param{HTMLOutput} ) {

        # get specific field settings
        my $FieldConfig = $Kernel::OM->Get('Kernel::Config')->Get('DynamicFields::Driver')->{Attachment} || {};

        # set new line separator
        my $ItemSeparator = $FieldConfig->{ItemSeparator} || ', ';

        my @FileNames = map { $_->{Filename} } @Values;

        my $Value = join( $ItemSeparator, @FileNames );

        my $Data = {
            Value => $Value,
            Title => undef,
            Link  => undef,
        };

        return $Data;
    }

    # get layout object
    my $LayoutObject = $Kernel::OM->Get('Kernel::Output::HTML::Layout');

    # get real values
    my $PossibleValues     = $Param{DynamicFieldConfig}->{Config}->{PossibleValues};
    my $TranslatableValues = $Param{DynamicFieldConfig}->{Config}->{TranslatableValues};

    my $FieldName = 'DynamicField_' . $Param{DynamicFieldConfig}->{Name};
    my $Template  = <<'EOF';
[% RenderBlockStart("AttachmentHTML") %]
[% RenderBlockStart("AttachmentHTMLCSSAgent") %]
    <style type="text/css">
        #AttachmentLink[% Data.FieldName | html %] {
            cursor: pointer;
            display: block;
            height: 16px;
            width: 100px;
            padding-left: 5px !important;
        }
    </style>
[% RenderBlockEnd("AttachmentHTMLCSSAgent") %]
[% RenderBlockStart("AttachmentHTMLCSSCustomer") %]
    <style type="text/css">
        #AttachmentLink[% Data.FieldName | html %] {
            cursor: pointer;
            display: inline-block;
            height: 16px;
            width: 100px;
            padding-left: 5px !important;
        }
    </style>
[% RenderBlockEnd("AttachmentHTMLCSSCustomer") %]
[% RenderBlockStart("AttachmentIconSingle") %]
    <a id="AttachmentLink[% Data.FieldName | html %]" class="Attachment" title="[% Translate("Attachment") | html %] [% Data.Filename | html %] ([% Data.Filesize | html %])" rel="Attachment[% Data.FieldName | html %]">
        <i class="fa fa-paperclip"></i> [% Translate("Attachment") | html %]
    </a>
[% RenderBlockEnd("AttachmentIconSingle") %]
[% RenderBlockStart("AttachmentIconMultiple") %]
    <a id="AttachmentLink[% Data.FieldName | html %]" class="Attachment" title="[% Translate("Attachments") | html %]" rel="Attachment[% Data.FieldName | html %]">
        <i class="fa fa-paperclip"></i> [% Translate("Attachments") | html %]
    </a>
[% RenderBlockEnd("AttachmentIconMultiple") %]
    <div id="Attachment[% Data.FieldName | html %]" class="AttachmentData Hidden">
        <div style="height: 100%; width: 100%;" class="Attachment InnerContent">
[% RenderBlockStart("AttachmentRowLink") %]
            <div class="AttachmentElement">
                <h3>
EOF
    $Template .= '
                    <a href="[% Env("CGIHandle") %]?Action='
        . (
        $LayoutObject->{UserType} eq 'Customer'
        ? 'CustomerDynamicFieldAttachment'
        : 'AgentDynamicFieldAttachment'
        )
        . ';Filename=[% Data.Filename | uri %];DynamicFieldID=[% Data.DynamicFieldID | uri %];Object=[% Data.Object | uri %];ObjectID=[% Data.ObjectID | uri %]" target="attachment"[% Data.FieldClass | html %]>[% Data.Filename | html %]</a>';

    $Template .= <<'EOF';
                </h3>
                <p>[% Data.Filesize | html %]</p>
            </div>
[% RenderBlockEnd("AttachmentRowLink") %]
        </div>
    </div>
[% RenderBlockEnd("AttachmentHTML") %]
EOF

    $LayoutObject->Block(
        Name => 'AttachmentHTML',
        Data => {
            FieldName => $FieldName,
        },
    );

    if ( $LayoutObject->{UserType} eq 'Customer' ) {
        $LayoutObject->Block(
            Name => 'AttachmentHTMLCSSCustomer',
            Data => {
                FieldName => $FieldName,
            },
        );
    }
    else {
        $LayoutObject->Block(
            Name => 'AttachmentHTMLCSSAgent',
            Data => {
                FieldName => $FieldName,
            },
        );
    }

    if (@Values) {
        if ( scalar @Values == 1 ) {
            $LayoutObject->Block(
                Name => 'AttachmentIconSingle',
                Data => {
                    Filename  => $Values[0]->{Filename},
                    Filesize  => $Values[0]->{Filesize},
                    FieldName => $FieldName,
                },
            );
        }
        else {
            $LayoutObject->Block(
                Name => 'AttachmentIconMultiple',
                Data => {
                    FieldName => $FieldName,
                },
            );
        }

        for my $Item (@Values) {

            my $Object;
            my $ObjectID;
            my $FieldID    = $Param{DynamicFieldConfig}->{ID};
            my $ObjectType = $Param{DynamicFieldConfig}->{ObjectType};
            my $FieldClass = $Item->{Disabled} ? " style='color: lightgrey;'" : '';
            if ( $Item->{StorageLocation} =~ /^DynamicField\/$FieldID\/$ObjectType\/(\d+)\// ) {
                $ObjectID = $1;
            }

            $LayoutObject->Block(
                Name => 'AttachmentRowLink',
                Data => {
                    Filename       => $Item->{Filename},
                    Filesize       => $Item->{Filesize},
                    FieldName      => $FieldName,
                    DynamicFieldID => $FieldID,
                    Object         => $ObjectType,
                    ObjectID       => $ObjectID,
                    FieldClass     => $FieldClass,
                },
            );
        }

        # article and ticket type are shown on differen places over the screen
        if (
            $Param{DynamicFieldConfig}->{ObjectType} eq 'Article'
            )
        {
            my $JSCode = '
    $(document).on("click", "#AttachmentLink' . $FieldName . '", function (Event) {
        var Position, HTML;
        if ($(this).attr("rel") && $("#" + $(this).attr("rel")).length) {
            Position = $(this).offset();
            Core.UI.Dialog.ShowContentDialog($("#" + $(this).attr("rel"))[0].innerHTML, "Attachments", Position.top + 25, parseInt(Position.left, 10) + 25);
        }
        Event.preventDefault();
        Event.stopPropagation();
        return false;
    });
            ';

            # add js to call FormUpdate()
            $LayoutObject->AddJSOnDocumentComplete( Code => $JSCode );

        }

        # else use the on_document_complete version
        else {

            my $JSCode = '

    $(document).on("click", "#AttachmentLink' . $FieldName . '", function (Event) {
        var Position, HTML, $HTMLObject, WindowWidth, ReduceToLeft;
        if ($(this).attr("rel") && $("#" + $(this).attr("rel")).length) {
            Position = $(this).offset();
            WindowWidth = $(window).width();
            ReduceToLeft = ( WindowWidth /100 ) * 20;
            Core.UI.Dialog.ShowContentDialog($("#" + $(this).attr("rel"))[0].innerHTML, "Attachments", Position.top + 20, $(window).width() - parseInt(ReduceToLeft) );
        }
        Event.preventDefault();
        Event.stopPropagation();
        return false;
    });
            ';

            # add js to call FormUpdate()
            $LayoutObject->AddJSOnDocumentComplete( Code => $JSCode );

        }

    }
    my $Rendered = $LayoutObject->Output(
        Template => $Template,
    );

    my $Data = {
        Value => $Rendered,
        Title => undef,
        Link  => undef,
    };

    return $Data;
}

sub SearchFieldRender {
    my ( $Self, %Param ) = @_;

    # take config from field config
    my $FieldConfig = $Param{DynamicFieldConfig}->{Config};
    my $FieldName   = 'Search_DynamicField_' . $Param{DynamicFieldConfig}->{Name};
    my $FieldLabel  = $Param{DynamicFieldConfig}->{Label};

    # set the field value
    my $Value = ( defined $Param{DefaultValue} ? $Param{DefaultValue} : '' );

    # get the field value, this fuction is always called after the profile is loaded
    my $FieldValue = $Self->SearchFieldValueGet(%Param);

    # set values from profile if present
    if ( defined $FieldValue ) {
        $Value = $FieldValue;
    }

    # check if value is an arrayref (GenericAgent Jobs and NotificationEvents)
    if ( IsArrayRefWithData($Value) ) {
        $Value = @{$Value}[0];
    }

    # check and set class if necessary
    my $FieldClass = 'DynamicFieldFile';

    my $HTMLString = <<"EOF";
<input type="text" class="$FieldClass" id="$FieldName" name="$FieldName" title="$FieldLabel" value="$Value" />
EOF

    my $AdditionalText;
    if ( $Param{UseLabelHints} ) {
        $AdditionalText = 'e.g. Text or Te*t';
    }

    # call EditLabelRender on the base driver
    my $LabelString = $Self->EditLabelRender(
        %Param,
        DynamicFieldConfig => $Param{DynamicFieldConfig},
        FieldName          => $FieldName,
        AdditionalText     => $AdditionalText,
    );

    my $Data = {
        Field => $HTMLString,
        Label => $LabelString,
    };

    return $Data;
}

sub SearchFieldValueGet {
    my ( $Self, %Param ) = @_;

    my $Value;

    # get dynamic field value form param object
    if ( defined $Param{ParamObject} ) {
        $Value = $Param{ParamObject}->GetParam(
            Param => 'Search_DynamicField_' . $Param{DynamicFieldConfig}->{Name}
        );
    }

    # otherwise get the value from the profile
    elsif ( defined $Param{Profile} ) {
        $Value = $Param{Profile}->{ 'Search_DynamicField_' . $Param{DynamicFieldConfig}->{Name} };
    }
    else {
        return;
    }

    if ( defined $Param{ReturnProfileStructure} && $Param{ReturnProfileStructure} eq 1 ) {
        return {
            'Search_DynamicField_' . $Param{DynamicFieldConfig}->{Name} => $Value,
        };
    }

    return $Value;

}

sub SearchFieldParameterBuild {
    my ( $Self, %Param ) = @_;

    # get field value
    my $Value = $Self->SearchFieldValueGet(%Param);

    # $Value holds an array ref with an empty string if we have to search for nothing
    # or the value we have to search for as string on the first position of the array
    if ( ref $Value eq 'ARRAY' && defined $Value->[0] ) {
        $Value = $Value->[0];
    }

    # If we didn't have a clean value to search for,
    # make sure we deal at least with an empty string
    elsif ( !defined $Value ) {
        $Value = '';
    }

    # set operator
    my $Operator = 'Like';

    # search for a wild card in the value
    if ( length $Value ) {
        $Value = '%Filename: ' . $Value . '%';
    }

    # return search parameter structure
    return {
        Parameter => {
            $Operator => $Value,
        },
        Display => $Value,
    };
}

sub StatsFieldParameterBuild {
    my ( $Self, %Param ) = @_;

    return {
        Name    => $Param{DynamicFieldConfig}->{Label},
        Element => 'DynamicField_' . $Param{DynamicFieldConfig}->{Name},
    };
}

sub CommonSearchFieldParameterBuild {
    my ( $Self, %Param ) = @_;

    my $Value = $Param{Value};

    # set operator
    my $Operator = 'Like';

    # search for a wild card in the value
    if ( length $Value ) {
        $Value = '%Filename: ' . $Value . '%';
    }

    return {
        $Operator => $Value,
    };
}

sub ReadableValueRender {
    my ( $Self, %Param ) = @_;

    # set Value and Title variables
    my $Value = '';
    my $Title = '';

    # check value
    my @Values;
    if ( ref $Param{Value} eq 'ARRAY' ) {
        @Values = @{ $Param{Value} };
    }

    my @ReadableValues;

    VALUEITEM:
    for my $Item (@Values) {
        next VALUEITEM if !$Item;

        push @ReadableValues, (
            $Item->{Filename} . ', '
                . $Item->{Filesize}
        );
    }

    # set new line separator
    my $ItemSeparator = '; ';

    # Ouput transformations
    $Value = join( $ItemSeparator, @ReadableValues );
    $Title = $Value;

    # cut strings if needed
    if ( $Param{ValueMaxChars} && length($Value) > $Param{ValueMaxChars} ) {
        $Value = substr( $Value, 0, $Param{ValueMaxChars} ) . '...';
    }
    if ( $Param{TitleMaxChars} && length($Title) > $Param{TitleMaxChars} ) {
        $Title = substr( $Title, 0, $Param{TitleMaxChars} ) . '...';
    }

    # create return structure
    my $Data = {
        Value => $Value,
        Title => $Title,
    };

    return $Data;
}

sub TemplateValueTypeGet {
    my ( $Self, %Param ) = @_;

    my $FieldName = 'DynamicField_' . $Param{DynamicFieldConfig}->{Name};

    # set the field types
    my $EditValueType   = 'ARRAY';
    my $SearchValueType = 'ARRAY';

    # return the correct structure
    if ( $Param{FieldType} eq 'Edit' ) {
        return {
            $FieldName => $EditValueType,
            }
    }
    elsif ( $Param{FieldType} eq 'Search' ) {
        return {
            'Search_' . $FieldName => $SearchValueType,
            }
    }
    else {
        return {
            $FieldName             => $EditValueType,
            'Search_' . $FieldName => $SearchValueType,
            }
    }
}

sub RandomValueSet {
    my ( $Self, %Param ) = @_;

    my $Value = int( rand(500) );

    # get a new upload cache object
    my $UploadCacheObject = $Kernel::OM->Get('Kernel::System::Web::UploadCache');

    # get a new form id
    my $FormID     = $UploadCacheObject->FormIDCreate();
    my $FormIDName = 'UploadCacheFormIDDynamicField_' . $Param{DynamicFieldConfig}->{Name};

    # set new form id
    $Self->{$FormIDName} = $FormID;

    my $Success = $Self->ValueSet(
        %Param,
        Value => $Value,
    );

    if ( !$Success ) {
        return {
            Success => 0,
        };
    }
    return {
        Success => 1,
        Value   => $Value,
    };
}

sub ObjectMatch {
    my ( $Self, %Param ) = @_;

    my $FieldName = $Param{DynamicFieldConfig}->{Name};

    # not supported
    return 0;
}

sub ValueLookup {
    my ( $Self, %Param ) = @_;

    my $Value = defined $Param{Key} ? $Param{Key} : '';

    return $Value;
}

=item AttachmentDownload()

This function is used to get the output headers for the download

    my $Value = $BackendObject->AttachmentDownload(
        ObjectID           => $DynamicFieldObjectID,
        Object             => $DynamicFieldObject,  # Ticket or Article
        DynamicFieldID     => $DynamicFieldID,
        Filename           => $AttachmentFileName,
        DynamicFieldConfig => $DynamicFieldConfig,  # complete config of the DynamicField
        TicketObject       => $TicketObject,
        LayoutObject       => $LayoutObject,
    );

    Returns $Attachment;

=cut

sub AttachmentDownload {
    my ( $Self, %Param ) = @_;

    # get layout object
    my $LayoutObject = $Kernel::OM->Get('Kernel::Output::HTML::Layout');

    # check needed stuff
    for my $Needed (qw(ObjectID Object DynamicFieldID Filename DynamicFieldConfig)) {
        if ( !$Param{$Needed} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Needed!"
            );
            return $LayoutObject->ErrorScreen();
        }
    }

    # get ticket object
    my $TicketObject = $Kernel::OM->Get('Kernel::System::Ticket');

    my $TicketID;
    my %Object;
    if ( $Param{Object} eq 'Article' ) {
        %Object = $TicketObject->ArticleGet(
            ArticleID     => $Param{ObjectID},
            DynamicFields => 1,
            UserID        => 1,
        );
        if ( !$Object{TicketID} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Message  => "No TicketID for ArticleID ($Param{ObjectID})!",
                Priority => 'error',
            );
            return $LayoutObject->ErrorScreen();
        }
        $TicketID = $Object{TicketID};

    }
    elsif ( $Param{Object} eq 'Ticket' ) {
        %Object = $TicketObject->TicketGet(
            TicketID      => $Param{ObjectID},
            DynamicFields => 1,
            UserID        => 1,
        );
        if ( !$Object{TicketID} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Message  => "No Ticket found for ID ($Param{ObjectID})!",
                Priority => 'error',
            );
            return $LayoutObject->ErrorScreen();
        }
        $TicketID = $Object{TicketID};
    }
    else {
        $Kernel::OM->Get('Kernel::System::Log')->Log(
            Message  => "Could not determine Objet for $Param{Object}!",
            Priority => 'error',
        );
        return $LayoutObject->ErrorScreen();
    }

    # check permissions
    my $Access;
    if ( $LayoutObject->{UserType} eq 'Customer' ) {
        $Access = $TicketObject->TicketCustomerPermission(
            Type     => 'ro',
            TicketID => $TicketID,
            UserID   => $Param{UserID}
        );
    }
    else {
        $Access = $TicketObject->TicketPermission(
            Type     => 'ro',
            TicketID => $TicketID,
            UserID   => $Param{UserID}
        );
    }

    if ( !$Access ) {
        return $LayoutObject->NoPermission( WithHeader => 'yes' );
    }

    if ( !IsHashRefWithData( $Param{DynamicFieldConfig} ) ) {
        $Kernel::OM->Get('Kernel::System::Log')->Log(
            Message =>
                "No DynamicField config found for DynamicFieldID $Param{DynamicFieldID} and Object $Param{Object}!",
            Priority => 'error',
        );
        return $LayoutObject->ErrorScreen();
    }

    my $Attachment = $Kernel::OM->Get('Kernel::System::DynamicField::Backend')->ValueGet(
        DynamicFieldConfig => $Param{DynamicFieldConfig},
        ObjectID           => $Param{ObjectID},
        Download           => 1,
        Filename           => $Param{Filename},
    );

    if ( !IsHashRefWithData($Attachment) ) {
        $Kernel::OM->Get('Kernel::System::Log')->Log(
            Message  => "Could not get file named $Param{Filename}!",
            Priority => 'error',
        );
        return $LayoutObject->ErrorScreen();
    }

    return $LayoutObject->Attachment(
        %{$Attachment},
        Type => 'attachment',
    );
}

1;

=back

=head1 TERMS AND CONDITIONS

This software is part of the OTRS project (L<http://otrs.org/>).

This software comes with ABSOLUTELY NO WARRANTY. For details, see
the enclosed file COPYING for license information (AGPL). If you
did not receive this file, see L<http://www.gnu.org/licenses/agpl.txt>.

=cut

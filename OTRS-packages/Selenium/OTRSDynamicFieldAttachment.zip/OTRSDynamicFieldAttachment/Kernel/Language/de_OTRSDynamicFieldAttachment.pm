# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::Language::de_OTRSDynamicFieldAttachment;

use strict;
use warnings;

use utf8;

sub Data {
    my $Self = shift;

    $Self->{Translation}->{'Change this, if you need more or less attachments to be stored in this DynamicField.'} =
        'Ändern Sie diese Einstellung wenn sie mehr oder weniger Dokumente in dieses DynamicField speichern wollen.';
    $Self->{Translation}->{'Maximum amount of attachments'} = 'Maximale Anzahl an Dokumenten';
    $Self->{Translation}->{'Maximum attachment size'} = 'Maximale Dateigröße';
    $Self->{Translation}->{'Maximum size per attachment in MB for this DynamicField. 0 for no limit.'} = 'Maximale Größe jedes Dokuments in MB für dieses DynamicField. 0 für keine Beschränkung.';
    $Self->{Translation}->{'The maximum of attachments for this DynamicFieldAttachment must be a positive number.'} = 'Die maximale Anzahl an Dokumenten muss eine positive Ganzzahl sein.';
    $Self->{Translation}->{'The maximum attachment size for this DynamicFieldAttachment must be a positive number.'} = 'Die maximale Größe jedes Dokuments muss eine positive Ganzzahl sein.';
    $Self->{Translation}->{'The following attachments were removed because they were bigger than the allowed size of '} = 'Folgende Dateien wurden entfernt da sie größer waren als die erlaubten ';
    $Self->{Translation}->{'Attachments with the same name as the following names were already present and got deleted.'} = 'Anhänge mit den gleichen Dateinamen wie die im folgenden angezeigten wurden hochgeladen, jedoch gelöscht.';
    $Self->{Translation}->{'Disable delete functionality'} = 'Löschbarkeit deaktivieren';
    $Self->{Translation}->{'If selected, attachments can be marked as disabled but cannot be deleted.'} = 'Sofern ausgewählt, können Attachments als deaktiviert markiert aber nicht mehr gelöscht werden';
    $Self->{Translation}->{'Disable'} = 'Deaktivieren';
    $Self->{Translation}->{'You are going to disable at least one attachment. This procedure is irreversible! Are you sure you want to disable the selected attachments?'}
        = 'Sie sind im Begriff, mindestens eine Anlage zu deaktiveren. Dieser Vorgang kann nicht rückgängig gemacht werden. Sind Sie sicher, dass Sie die Anlage(n) deaktivieren möchten?';
    $Self->{Translation}->{'Are you sure you want to disable the selected attachments?'} = 'Sind Sie sicher, dass Sie die ausgewählten Anhänge deaktivieren wollen?';

    return;
}

1;

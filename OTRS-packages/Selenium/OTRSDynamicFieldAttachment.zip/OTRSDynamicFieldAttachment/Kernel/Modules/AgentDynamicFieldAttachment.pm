# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::Modules::AgentDynamicFieldAttachment;

use strict;
use warnings;

use Kernel::System::VariableCheck qw(:all);

our $ObjectManagerDisabled = 1;

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {%Param};
    bless( $Self, $Type );

    return $Self;
}

sub Run {
    my ( $Self, %Param ) = @_;

    # Ticket permission are checked inside AttachmentDownload

    # get needed objects
    my $ParamObject  = $Kernel::OM->Get('Kernel::System::Web::Request');
    my $LayoutObject = $Kernel::OM->Get('Kernel::Output::HTML::Layout');

    my %DownloadParams;
    for my $Item (qw(DynamicFieldID Object ObjectID Filename)) {
        my $Value = $ParamObject->GetParam( Param => $Item ) || '';
        if ( !$Value ) {
            return $LayoutObject->ErrorScreen(
                Message => "Need $Item!",
                Comment => 'Please contact the admin.',
            );
        }
        $DownloadParams{$Item} = $Value;
    }

    $DownloadParams{DynamicFieldConfig} = $Kernel::OM->Get('Kernel::System::DynamicField')->DynamicFieldGet(
        ID => $DownloadParams{DynamicFieldID},
    );

    # get download for attachment parameters
    return $Kernel::OM->Get('Kernel::System::DynamicField::Backend')->AttachmentDownload(
        %{$Self},
        %DownloadParams,
    );
}

1;

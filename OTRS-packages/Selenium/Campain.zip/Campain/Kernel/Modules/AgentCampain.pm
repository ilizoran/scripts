# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::Modules::AgentCampain;

use strict;
use warnings;

our $ObjectManagerDisabled = 1;

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {%Param};
    bless( $Self, $Type );

    $Self->{Debug} = $Param{Debug} || 0;

    # get form id
    $Self->{FormID} = $Kernel::OM->Get('Kernel::System::Web::Request')->GetParam( Param => 'FormID' );

    # create form id
    if ( !$Self->{FormID} ) {
        $Self->{FormID} = $Kernel::OM->Get('Kernel::System::Web::UploadCache')->FormIDCreate();
    }

    $Self->{Config} = $Kernel::OM->Get('Kernel::Config')->Get("Ticket::Frontend::$Self->{Action}");

    return $Self;

}

sub Run {
    my ( $Self, %Param ) = @_;

    # get needed objects
    my $LayoutObject      = $Kernel::OM->Get('Kernel::Output::HTML::Layout');
    my $CampainObject     = $Kernel::OM->Get('Kernel::System::Campain');
    my $QueueObject       = $Kernel::OM->Get('Kernel::System::Queue');
    my $StateObject       = $Kernel::OM->Get('Kernel::System::State');
    my $TimeObject        = $Kernel::OM->Get('Kernel::System::Time');
    my $ParamObject       = $Kernel::OM->Get('Kernel::System::Web::Request');
    my $UploadCacheObject = $Kernel::OM->Get('Kernel::System::Web::UploadCache');

    # ------------------------------------------------------------ #
    # CampainNew
    # ------------------------------------------------------------ #
    if ( $Self->{Subaction} eq 'CampainNew' ) {

        my %Error;
        my %CampainData;
        my $Signature = '';

        # get params
        for my $Parameter (
            qw(Year Month Day Hour Minute NextQueueID
            Subject Body NextStateID FormID Signature file_upload
            )
            )
        {
            $CampainData{$Parameter} = $ParamObject->GetParam( Param => "$Parameter" )
                || '';
        }

        # If is an action about attachments
        my $IsUpload = 0;

        # attachment delete
        ATTACHMENT:
        for my $Count ( 1 .. 16 ) {
            my $Delete = $ParamObject->GetParam( Param => "AttachmentDelete$Count" );
            next ATTACHMENT if !$Delete;
            $Error{AttachmentDelete} = 1;
            $UploadCacheObject->FormIDRemoveFile(
                FormID => $CampainData{FormID},
                FileID => $Count,
            );
            $IsUpload = 1;
        }

        # attachment upload
        if ( $ParamObject->GetParam( Param => 'AttachmentUpload' ) ) {
            $IsUpload                = 1;
            %Error                   = ();
            $Error{AttachmentUpload} = 1;
            my %UploadStuff = $ParamObject->GetUploadAll(
                Param  => 'FileUpload',
                Source => 'string',
            );
            $UploadCacheObject->FormIDAddFile(
                FormID => $CampainData{FormID},
                %UploadStuff,
            );
        }

        # build id string
        $Param{FormID} = $LayoutObject->Ascii2Html(
            Text => $CampainData{FormID},
        );

        my %QueueData = $QueueObject->QueueList(
            Valid => 1,
        );

        # build queue select
        $Param{Queue} = $LayoutObject->BuildSelection(
            Data       => \%QueueData,
            Name       => 'NextQueueID',
            Class      => 'Modernize',
            SelectedID => $CampainData{NextQueueID},
        );

        my $SignatureStart = $Self->_GetSignatureStart(
            QueueID => $CampainData{NextQueueID},
        );

        # build signature string
        $Param{Signature} = $LayoutObject->Ascii2Html(
            Text => $SignatureStart,
        );

        # build input field subject
        $Param{Subject} = $LayoutObject->Ascii2Html(
            Text => $CampainData{Subject},
        );

        # build text-area field body
        $Param{Body} = $LayoutObject->Ascii2Html(
            Text => $CampainData{Body},
        );

        # check for missing data
        if ( !$IsUpload ) {
            if ( !$CampainData{Subject} ) {
                $Error{SubjectInvalid} = ' ServerError';
            }

            if ( !$CampainData{Body} ) {
                $Error{BodyInvalid} = ' ServerError';
            }
        }

        my %NextStates = $StateObject->StateList(
            UserID => $Self->{UserID},
        );

        # build next states select
        $Param{NextStatesStrg} = $LayoutObject->BuildSelection(
            Data       => \%NextStates,
            Name       => 'NextStateID',
            Class      => 'Modernize',
            SelectedID => $CampainData{NextStateID},
        );

        # convert date time
        my $UYear          = $CampainData{Year};
        my $UMonth         = sprintf( "%02d", $CampainData{Month} );
        my $UDay           = sprintf( "%02d", $CampainData{Day} );
        my $UHour          = sprintf( "%02d", $CampainData{Hour} );
        my $UMinute        = sprintf( "%02d", $CampainData{Minute} );
        my $SetDateTimeOld = "$UYear-$UMonth-$UDay $UHour:$UMinute:00";
        my $SystemTimeNow  = $TimeObject->SystemTime();
        my $SetDateTime    = $TimeObject->TimeStamp2SystemTime(
            String => $SetDateTimeOld,
        );

        if ( !$SetDateTime ) {
            $SetDateTime = $SystemTimeNow;
        }

        my $WantDateTime = $SetDateTime - $SystemTimeNow;

        # get next state name
        my $StateName;

        if ( $CampainData{NextStateID} ) {
            $StateName = $StateObject->StateLookup(
                StateID => $CampainData{NextStateID},
            );
        }

        # check pending date
        if ( $StateName && $StateName =~ /^pending/i ) {

            my $CampainSystemTime = $TimeObject->Date2SystemTime(
                %CampainData,
                Second => 0,
            );

            if (
                !$CampainSystemTime
                || $CampainSystemTime < $TimeObject->SystemTime()
                )
            {
                if ( $IsUpload == 0 ) {
                    $Error{DateInvalid} = ' ServerError';
                }
            }
        }

        # pending data string
        $Param{PendingDateString} = $LayoutObject->BuildDateSelection(
            Format               => 'DateInputFormatLong',
            DiffTime             => $WantDateTime,
            Class                => $Error{DateInvalid},
            Validate             => 1,
            ValidateDateInFuture => 1,
        );

        # output campaign
        $LayoutObject->Block(
            Name => 'Campain',
            Data => {
                %Param,
                %Error,
            },
        );

        # get all attachments meta data
        my @Attachments = $UploadCacheObject->FormIDGetAllFilesData(
            FormID => $Self->{FormID},
        );

        for my $DataRef (@Attachments) {
            $LayoutObject->Block(
                Name => 'Attachment',
                Data => $DataRef,
            );
        }

        # output header
        my $Output = $LayoutObject->Header( Title => 'Campaign' );
        $Output .= $LayoutObject->NavigationBar();

        if ( !%Error ) {
            $LayoutObject->Block(
                Name => 'CampainSendHead',
                Data => {
                    %Param,
                },
            );

            my @CampainList = $CampainObject->CampainList();
            my $TicketID;
            my $BodyInsert       = $CampainData{Body};
            my $AllSend          = 0;
            my $CustomerUserName = '';
            my @CustomerIDs;

            # get needed objects
            my $TicketObject       = $Kernel::OM->Get('Kernel::System::Ticket');
            my $CustomerUserObject = $Kernel::OM->Get('Kernel::System::CustomerUser');

            if (@CampainList) {
                $LayoutObject->Block(
                    Name => 'CampainTable',
                    Data => {
                        %Param,
                    },
                );
            }

            for my $CampainSendList (@CampainList) {
                my %CampainInsert = %{$CampainSendList};

                if ( defined $CampainInsert{email} ) {
                    $AllSend++;

                    my %List = $CustomerUserObject->CustomerSearch(
                        PostMasterSearch => $CampainInsert{email},
                    );

                    for my $CustomerUserNameList ( sort keys %List ) {
                        $CustomerUserName = $CustomerUserNameList;
                        @CustomerIDs      = $CustomerUserObject->CustomerIDs(
                            User => $CustomerUserNameList,
                        );
                    }

                    my %UserListCustomer = $CustomerUserObject->CustomerUserDataGet(
                        User => $CustomerUserName,
                    );

                    # create new ticket, do db insert
                    $TicketID = $TicketObject->TicketCreate(
                        Title        => $CampainData{Subject},
                        QueueID      => $CampainData{NextQueueID},
                        Subject      => $CampainData{Subject},
                        Lock         => 'unlock',
                        StateID      => $CampainData{NextStateID},
                        OwnerID      => $CampainInsert{owner},
                        UserID       => $Self->{UserID},
                        PriorityID   => "3",
                        CustomerID   => $CustomerIDs[0],
                        CustomerUser => $UserListCustomer{UserID},
                    );

                    my $NewSalutation = '';

                    if ( $CampainInsert{salutation} =~ /Herr/ig ) {
                        $NewSalutation = "Sehr geehrter";
                    }
                    elsif ( $CampainInsert{salutation} =~ /Frau/ig ) {
                        $NewSalutation = "Sehr geehrte";
                    }
                    else {
                        $NewSalutation = "Dear";
                    }

                    $BodyInsert =~ s/\%salutation\%/$NewSalutation/g;
                    $BodyInsert
                        =~ s/\%placeholder\%/$CampainInsert{salutation} $CampainInsert{name}/g;
                    $BodyInsert .= "\n\n$CampainData{Signature}";

                    my %Adresss = $QueueObject->GetSystemAddress(
                        QueueID => $CampainData{NextQueueID},
                    );

                    # send email
                    my $ArticleID = $TicketObject->ArticleSend(
                        NoAgentNotify  => "1",
                        Attachment     => \@Attachments,
                        ArticleType    => 'email-external',
                        SenderType     => 'agent',
                        TicketID       => $TicketID,
                        From           => "$Adresss{RealName} <$Adresss{Email}>",
                        To             => "$CampainInsert{email}",
                        Cc             => "$CampainInsert{cc}",
                        Subject        => $CampainData{Subject},
                        Body           => $BodyInsert,
                        Charset        => $LayoutObject->{UserCharset},
                        UserID         => $Self->{UserID},
                        HistoryType    => "NewTicket",
                        HistoryComment => "NULL",
                        MimeType       => 'text/plain',
                    );

                    my $TicketNumber = $TicketObject->TicketNumberLookup(
                        TicketID => $TicketID,
                    );

                    # output campain row block
                    $LayoutObject->Block(
                        Name => 'CampainRow',
                        Data => {
                            Name           => "$CampainInsert{salutation} $CampainInsert{name}",
                            Email          => $CampainInsert{email},
                            TicketLinkName => "Ticket#: $TicketNumber",
                            TicketLink     => $TicketID,
                        },
                    );

                    # get current time
                    my ( $s, $m, $h, $D, $M, $Y ) = $TimeObject->SystemTime2Date(
                        SystemTime => $TimeObject->SystemTime(),
                    );

                    $D = sprintf( "%02d", $D );
                    $M = sprintf( "%02d", $M );
                    $Y = sprintf( "%02d", $Y );
                    $BodyInsert = $CampainData{Body};

                    $CampainObject->CampainUpdate(
                        Name     => $CampainInsert{name},
                        TicketID => $TicketID,
                        Owner    => $Self->{UserID},
                        DateTime => "$Y-$M-$D $h:$m:$s",
                    );
                }
            }

            # build next states string
            $Param{AllSend} = $LayoutObject->Ascii2Html(
                Text => $AllSend,
            );

            # output campain head block
            $LayoutObject->Block(
                Name => 'CampainHead',
                Data => {%Param},
            );

            # output agent campain send block
            $Output .= $LayoutObject->Output(
                TemplateFile => 'AgentCampainSend',
                Data         => \%Param,
            );
        }
        else {
            $Output .= $LayoutObject->Output(
                TemplateFile => 'AgentCampain',
                Data         => {%Param},
            );
        }

        $Output .= $LayoutObject->Footer();

        return $Output;
    }

    # ------------------------------------------------------------ #
    # AJAXUpdate
    # ------------------------------------------------------------ #
    elsif ( $Self->{Subaction} eq 'AJAXUpdate' ) {

        my $QueueID = $ParamObject->GetParam( Param => 'NextQueueID' ) || '';
        my $Signature = '';
        if ($QueueID) {
            $Signature = $Self->_GetSignature(
                QueueID => $QueueID,
            );
        }

        return $Signature;
    }

    # ------------------------------------------------------------ #
    # CSV Upload
    # ------------------------------------------------------------ #
    elsif ( $Self->{Subaction} eq 'CsvUpload' ) {

        # output header
        my $Output = $LayoutObject->Header(
            Title => 'Campaign',
        );
        $Output .= $LayoutObject->NavigationBar();

        # output overview
        $LayoutObject->Block(
            Name => 'CampainUpload',
            Data => {
                Separator => ';',
            },
        );

        $Output .= $LayoutObject->Output(
            TemplateFile => 'AgentCampainUpload',
            Data         => \%Param,
        );

        $Output .= $LayoutObject->Footer();

        return $Output;

    }

    # ------------------------------------------------------------ #
    # CSV Upload Add
    # ------------------------------------------------------------ #
    elsif ( $Self->{Subaction} eq 'CsvUploadAdd' ) {

        my %UploadData;
        my %Error;

        # get params
        for my $Parameter (
            qw( file_upload Separator )
            )
        {
            $UploadData{$Parameter} = $ParamObject->GetParam( Param => "$Parameter" ) || '';
        }

        # check for missing data
        if ( !$UploadData{file_upload} ) {
            $Error{file_uploadInvalid} = ' ServerError';
        }

        if ( !$UploadData{Separator} ) {
            $Error{SeparatorInvalid} = ' ServerError';
        }

        # output header
        my $Output = $LayoutObject->Header(
            Title => 'Campaign',
        );
        $Output .= $LayoutObject->NavigationBar();

        # CSV upload
        if ( !%Error ) {

            # output upload
            $LayoutObject->Block(
                Name => 'CampainUploadResult',
                Data => {
                    %Param,
                },
            );

            my %UploadStuff = $ParamObject->GetUploadAll(
                Param  => "file_upload",
                Source => 'string',
            );

            my $CampainUpload = $CampainObject->CampainUpload(
                String    => $UploadStuff{Content},
                Separator => $UploadData{Separator},
            );

            if ( $CampainUpload =~ /[a-z]/ig ) {

                # output upload
                $LayoutObject->Block(
                    Name => 'CampainUploadError',
                    Data => {
                        %Param,
                    },
                );

                my @CampainUploadArray = split( /\|/, $CampainUpload );

                for my $CampainUploadString (@CampainUploadArray) {
                    $LayoutObject->Block(
                        Name => 'CampainUploadErrorRow',
                        Data => {
                            LineNum => $CampainUploadString,
                        },
                    );
                }
            }
            else {

                my $LineNum = $LayoutObject->Ascii2Html(
                    Text => $CampainUpload,
                );

                # redirect
                return $LayoutObject->Redirect(
                    OP => "Action=AgentCampain;Subaction=;LineNum=$LineNum",
                );
            }

        }
        else {

            # output overview
            $LayoutObject->Block(
                Name => 'CampainUpload',
                Data => {
                    Separator  => $UploadData{Separator},
                    FileUpload => $UploadData{file_upload},
                    %Param,
                    %Error
                },
            );
        }

        $Output .= $LayoutObject->Output(
            TemplateFile => 'AgentCampainUpload',
            Data         => \%Param,
        );

        $Output .= $LayoutObject->Footer();

        return $Output;

    }

    # ------------------------------------------------------------ #
    # campaign overview
    # ------------------------------------------------------------ #
    else {

        my @CampainList = $CampainObject->CampainList();

        my $StartVol = scalar @CampainList;

        if ( $StartVol < 1 ) {

            # output campain no start block
            $LayoutObject->Block(
                Name => 'CampainNoStart',
                Data => {%Param},
            );

            # output header
            my $Output = $LayoutObject->Header(
                Title => 'Campaign',
            );
            $Output .= $LayoutObject->NavigationBar();

            $Output .= $LayoutObject->Output(
                TemplateFile => 'AgentCampain',
                Data         => \%Param,
            );

            $Output .= $LayoutObject->Footer();

            return $Output;

        }
        else {

            # build next states string
            $Param{FormID} = $LayoutObject->Ascii2Html(
                Text => $Self->{FormID},
            );

            # build next states string
            $Param{AllRecipient} = $LayoutObject->Ascii2Html(
                Text => $StartVol,
            );

            my %QueueData = $QueueObject->QueueList(
                Valid => 1,
            );

            # build next states string
            $Param{Queue} = $LayoutObject->BuildSelection(
                Data       => \%QueueData,
                Name       => 'NextQueueID',
                Class      => 'Modernize',
                SelectedID => 1,
            );

            my %NextStates = $StateObject->StateList(
                UserID => $Self->{UserID},
            );

            # build next states string
            $Param{NextStatesStrg} = $LayoutObject->BuildSelection(
                Data       => \%NextStates,
                Name       => 'NextStateID',
                Class      => 'Modernize',
                SelectedID => 4,
            );

            # build next states string
            $Param{Body} = $LayoutObject->Ascii2Html(
                Text => "%salutation% %placeholder%, ",
            );

            my $SignatureStart = $Self->_GetSignatureStart(
                QueueID => 1,
            );

            # build next states string
            $Param{Signature} = $LayoutObject->Ascii2Html(
                Text => $SignatureStart,
            );

            # pending data string
            $Param{PendingDateString} = $LayoutObject->BuildDateSelection(
                %Param,
                Format   => 'DateInputFormatLong',
                DiffTime => $Kernel::OM->Get('Kernel::Config')->Get('Ticket::Frontend::PendingDiffTime') || 0,
                Validate => 1,
                ValidateDateInFuture => 1,
            );

            # output overview
            $LayoutObject->Block(
                Name => 'Campain',
                Data => {
                    %Param,
                },
            );

            # output header
            my $Output = $LayoutObject->Header(
                Title => 'Campaign',
            );

            $Output .= $LayoutObject->NavigationBar();

            # line number notification
            my $LineNum = $ParamObject->GetParam( Param => 'LineNum' ) || '';
            if ($LineNum) {

                # notify info
                $Output .= $LayoutObject->Notify(
                    Info => 'Upload successful, ' . $LineNum . ' new recipient added.',
                );
            }

            $Output .= $LayoutObject->Output(
                TemplateFile => 'AgentCampain',
                Data         => \%Param,
            );

            $Output .= $LayoutObject->Footer();

            return $Output;
        }
    }
}

sub _GetSignature {
    my ( $Self, %Param ) = @_;

    # get needed objects
    my $LayoutObject = $Kernel::OM->Get('Kernel::Output::HTML::Layout');
    my $QueueObject  = $Kernel::OM->Get('Kernel::System::Queue');

    my $Signature = '';
    my %Queue     = $QueueObject->GetSystemAddress(
        QueueID => $Param{QueueID},
    );

    # prepare signature
    $Signature = $QueueObject->GetSignature(
        QueueID => $Param{QueueID},
    );
    $Signature = $LayoutObject->RichText2Ascii(
        String => $Signature,
    );
    $Signature =~ s/<OTRS_FIRST_NAME>/$Self->{UserFirstname}/g;
    $Signature =~ s/<OTRS_LAST_NAME>/$Self->{UserLastname}/g;

    # current user
    my %User = $Kernel::OM->Get('Kernel::System::User')->GetUserData(
        UserID => $Self->{UserID},
        Cached => 1,
    );
    for my $UserKey ( sort keys %User ) {
        if ( $User{$UserKey} ) {
            $Signature =~ s/<OTRS_Agent_$UserKey>/$User{$UserKey}/gi;
            $Signature =~ s/<OTRS_CURRENT_$UserKey>/$User{$UserKey}/gi;
        }
    }

    # replace other needed stuff
    $Signature =~ s/<OTRS_FIRST_NAME>/$Self->{UserFirstname}/g;
    $Signature =~ s/<OTRS_LAST_NAME>/$Self->{UserLastname}/g;

    # cleanup
    $Signature =~ s/<OTRS_Agent_.+?>/-/gi;
    $Signature =~ s/<OTRS_CURRENT_.+?>/-/gi;

    # replace config options
    $Signature =~ s{<OTRS_CONFIG_(.+?)>}{$Kernel::OM->Get('Kernel::Config')->Get($1)}egx;
    $Signature =~ s/<OTRS_CONFIG_.+?>/-/gi;

    my $JSON = $LayoutObject->BuildSelectionJSON(
        [
            {
                Name         => 'Signature',
                Data         => $Signature,
                Translation  => 0,
                PossibleNone => 1,
                Max          => 100,
            },
        ],
    );

    return $LayoutObject->Attachment(
        ContentType => 'application/json; charset=' . $LayoutObject->{Charset},
        Content     => $JSON,
        Type        => 'inline',
        NoCache     => 1,
    );

}

sub _GetSignatureStart {
    my ( $Self, %Param ) = @_;

    # get needed objects
    my $LayoutObject = $Kernel::OM->Get('Kernel::Output::HTML::Layout');
    my $QueueObject  = $Kernel::OM->Get('Kernel::System::Queue');

    my $SignatureStart = '';
    my %Queue          = $QueueObject->GetSystemAddress(
        QueueID => $Param{QueueID},
    );

    # prepare signature
    $SignatureStart = $QueueObject->GetSignature(
        QueueID => $Param{QueueID},
    );
    $SignatureStart = $LayoutObject->RichText2Ascii(
        String => $SignatureStart,
    );
    $SignatureStart =~ s/<OTRS_FIRST_NAME>/$Self->{UserFirstname}/g;
    $SignatureStart =~ s/<OTRS_LAST_NAME>/$Self->{UserLastname}/g;

    # current user
    my %User = $Kernel::OM->Get('Kernel::System::User')->GetUserData(
        UserID => $Self->{UserID},
        Cached => 1,
    );
    for my $UserKey ( sort keys %User ) {
        if ( $User{$UserKey} ) {
            $SignatureStart =~ s/<OTRS_Agent_$UserKey>/$User{$UserKey}/gi;
            $SignatureStart =~ s/<OTRS_CURRENT_$UserKey>/$User{$UserKey}/gi;
        }
    }

    # replace other needed stuff
    $SignatureStart =~ s/<OTRS_FIRST_NAME>/$Self->{UserFirstname}/g;
    $SignatureStart =~ s/<OTRS_LAST_NAME>/$Self->{UserLastname}/g;

    # cleanup
    $SignatureStart =~ s/<OTRS_Agent_.+?>/-/gi;
    $SignatureStart =~ s/<OTRS_CURRENT_.+?>/-/gi;

    # replace config options
    $SignatureStart =~ s{<OTRS_CONFIG_(.+?)>}{$Kernel::OM->Get('Kernel::Config')->Get($1)}egx;
    $SignatureStart =~ s/<OTRS_CONFIG_.+?>/-/gi;

    return $SignatureStart;
}

1;

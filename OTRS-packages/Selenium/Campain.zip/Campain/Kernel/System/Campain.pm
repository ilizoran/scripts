# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::System::Campain;

use strict;
use warnings;

our @ObjectDependencies = (
    'Kernel::System::DB',
    'Kernel::System::User',
    'Kernel::System::CSV',
);

=head1 NAME

Kernel::System::Campain - campaign lib

=head1 SYNOPSIS

All valid functions.

=head1 PUBLIC INTERFACE

=over 4

=cut

=item new()

create an object. Do not use it directly, instead use:

    use Kernel::System::ObjectManager;
    local $Kernel::OM = Kernel::System::ObjectManager->new();
    my $CampainObject = $Kernel::OM->Get('Kernel::System::Campain');

=cut

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {};
    bless( $Self, $Type );

    return $Self;
}

=item CampainList()

return a list of campaign recipients

    my @CampainList = $CampainObject->CampainList(
        Valid => 0,   # (optional) default 0 (0|1)
    );

=cut

sub CampainList {
    my ( $Self, %Param ) = @_;

    # check valid param
    if ( !defined( $Param{Valid} ) ) {
        $Param{Valid} = 0;
    }

    # get database object
    my $DBObject = $Kernel::OM->Get('Kernel::System::DB');

    # ask database
    return if !$DBObject->Prepare(
        SQL => '
            SELECT name, email, cc, salutation, owner
            FROM campain_recipient
            WHERE status = ?
        ',
        Bind => [ \$Param{Valid}, ],
    );

    my @CampainList;

    while ( my @Row = $DBObject->FetchrowArray() ) {
        my %CampainHash = (
            name       => $Row[0],
            email      => $Row[1],
            cc         => $Row[2],
            salutation => $Row[3],
            owner      => $Row[4]
        );
        push @CampainList, \%CampainHash;
    }

    return @CampainList;
}

=item CampainUpdate()

update the table and set the status

    my %CampainUpdate = $CampainObject->CampainUpdate(
        Valid => 0,   # (optional) default 0 (0|1)
    );

=cut

sub CampainUpdate {
    my ( $Self, %Param ) = @_;

    # check valid param
    if ( !defined( $Param{Valid} ) ) {
        $Param{Valid} = 0;
    }

    # ask database
    return if !$Kernel::OM->Get('Kernel::System::DB')->Prepare(
        SQL => '
            UPDATE campain_recipient
            SET status =1, ticket_id =?, owner =?, send =?
            WHERE status =? AND name =?
        ',
        Bind => [
            \$Param{TicketID}, \$Param{Owner}, \$Param{DateTime},
            \$Param{Valid}, \$Param{Name},
        ],
    );

    return 1;
}

=item CampainUpload()

upload new data in the table

    my $CampainUpload = $CampainObject->CampainUpload(
        String    => $String,
        Separator => ';',
    );

=cut

sub CampainUpload {
    my ( $Self, %Param ) = @_;

    # get csv object
    my $CSVObject = $Kernel::OM->Get('Kernel::System::CSV');

    my $RefArray = $CSVObject->CSV2Array(
        String    => $Param{String},
        Separator => $Param{Separator},
        Quote     => '',
    );

    # get user object
    my $UserObject = $Kernel::OM->Get('Kernel::System::User');

    my @Lines = @{$RefArray};

    my $UserError;
    my $UserErrorLine = 0;
    for my $RefLineTest (@Lines) {

        my @LineTest = @{$RefLineTest};
        $UserErrorLine++;
        my $UserID = $UserObject->UserLookup(
            UserLogin => $LineTest[4],
        );

        if ( !$UserID ) {
            $UserError .= "Line $UserErrorLine - $LineTest[1] - $LineTest[4]|";
        }
    }

    if ($UserError) {

        return $UserError;
    }
    else {

        my $LineNum = 0;
        for my $RefLine (@Lines) {

            my @Line = @{$RefLine};

            $LineNum++;

            my $UserID = $UserObject->UserLookup(
                UserLogin => $Line[4],
            );

            # ask database
            return if !$Kernel::OM->Get('Kernel::System::DB')->Prepare(
                SQL => '
                    INSERT INTO campain_recipient (name,email,cc,salutation,owner,status)
                    VALUES (?,?,?,?,?,0)
                ',
                Bind => [ \$Line[1], \$Line[2], \$Line[3], \$Line[0], \$UserID, ],
            );
        }

        return $LineNum;
    }

}

1;

=back

=head1 TERMS AND CONDITIONS

This software is part of the OTRS project (http://otrs.org/).

This software comes with ABSOLUTELY NO WARRANTY. For details, see
the enclosed file COPYING for license information (AGPL). If you
did not receive this file, see L<http://www.gnu.org/licenses/agpl.txt>.

=cut

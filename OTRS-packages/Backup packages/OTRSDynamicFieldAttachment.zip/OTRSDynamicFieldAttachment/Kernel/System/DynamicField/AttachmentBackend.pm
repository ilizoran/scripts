# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::System::DynamicField::AttachmentBackend;

use strict;
use warnings;

our @ObjectDependencies = (
    'Kernel::System::Log',
    'Kernel::Output::HTML::Layout',
    'Kernel::System::DynamicField::Backend',
    'Kernel::System::Ticket',
);

use Kernel::System::VariableCheck qw(:all);

=head1 NAME

Kernel::System::DynamicField::AttachmentBackend

=head1 SYNOPSIS

DynamicFields backend interface for attachments

=head1 PUBLIC INTERFACE

=over 4

=cut

=item AttachmentDownload()

This function is used to get the output headers for the download

    my $Value = $BackendObject->AttachmentDownload(
        ObjectID           => $DynamicFieldObjectID,
        Object             => $DynamicFieldObject,  # Ticket or Article
        DynamicFieldID     => $DynamicFieldID,
        Filename           => $AttachmentFileName,
        DynamicFieldConfig => $DynamicFieldConfig,  # complete config of the DynamicField
        TicketObject       => $TicketObject,
        LayoutObject       => $LayoutObject,
    );

    Returns $Attachment;

=cut

sub AttachmentDownload {
    my ( $Self, %Param ) = @_;

    # check needed stuff
    for my $Needed (qw(ObjectID Object DynamicFieldID Filename DynamicFieldConfig)) {
        if ( !$Param{$Needed} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Needed!"
            );
            return;
        }
    }

    # check DynamicFieldConfig (general)
    if ( !IsHashRefWithData( $Param{DynamicFieldConfig} ) ) {
        $Kernel::OM->Get('Kernel::System::Log')->Log(
            Priority => 'error',
            Message  => "The field configuration is invalid",
        );
        return;
    }

    # check DynamicFieldConfig (internally)
    for my $Needed (qw(ID FieldType ObjectType Name)) {
        if ( !$Param{DynamicFieldConfig}->{$Needed} ) {
            $Kernel::OM->Get('Kernel::System::Log')->Log(
                Priority => 'error',
                Message  => "Need $Needed in DynamicFieldConfig!"
            );
            return;
        }
    }

    # set the dynamic field specific backend
    my $DynamicFieldBackend = 'DynamicField' . $Param{DynamicFieldConfig}->{FieldType} . 'Object';

    if ( !$Self->{$DynamicFieldBackend} ) {
        $Kernel::OM->Get('Kernel::System::Log')->Log(
            Priority => 'error',
            Message  => "Backend $Param{DynamicFieldConfig}->{FieldType} is invalid!"
        );
        return;
    }

    # verify if function is available
    return if !$Self->{$DynamicFieldBackend}->can('AttachmentDownload');

    # return value from the specific backend
    return $Self->{$DynamicFieldBackend}->AttachmentDownload(%Param);
}

1;

=back

=head1 TERMS AND CONDITIONS

This software is part of the OTRS project (L<http://otrs.org/>).

This software comes with ABSOLUTELY NO WARRANTY. For details, see
the enclosed file COPYING for license information (AGPL). If you
did not receive this file, see L<http://www.gnu.org/licenses/agpl.txt>.

=cut

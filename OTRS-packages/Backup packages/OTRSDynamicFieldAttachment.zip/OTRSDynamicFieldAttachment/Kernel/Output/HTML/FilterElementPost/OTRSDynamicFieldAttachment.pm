# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::Output::HTML::FilterElementPost::OTRSDynamicFieldAttachment;

use strict;
use warnings;

our @ObjectDependencies = (
    'Kernel::Config',
    'Kernel::Output::HTML::Layout',
);

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = {};
    bless( $Self, $Type );

    return $Self;
}

sub Run {
    my ( $Self, %Param ) = @_;

    # get template name
    my $TemplateName = $Param{TemplateFile} || '';
    return 1 if !$TemplateName;

    # get valid modules
    my $ValidTemplates = $Kernel::OM->Get('Kernel::Config')->Get('Frontend::Output::FilterElementPost')
        ->{'OutputFilterOTRSDynamicFieldAttachment'}->{Templates};

    # apply only if template is valid in config
    return 1 if !$ValidTemplates->{$TemplateName};

    # add javascript text translations
    my $StartPattern = '(Core.Config.AddConfig\(\{)';

    # get layout object
    my $LayoutObject = $Kernel::OM->Get('Kernel::Output::HTML::Layout');

    if ( ${ $Param{Data} } =~ m{ $StartPattern }ixms ) {

        my $DeleteText = $LayoutObject->{LanguageObject}->Get('Delete') || 'Delete';
        my $DisableAttachmentsText = $LayoutObject->{LanguageObject}->Get('Disable Attachments')
            || 'Disable Attachments';
        my $CancelText  = $LayoutObject->{LanguageObject}->Get('Cancel')  || 'Cancel';
        my $DisableText = $LayoutObject->{LanguageObject}->Get('Disable') || 'Disable';

        my $Replace = "
// START OutputFilterOTRSDynamicFieldAttachment
        DeleteButton: '$DeleteText',
        AttachmentDialogHeadlineText: '$DisableAttachmentsText',
        AttachmentDialogCancelText: '$CancelText',
        AttachmentDialogDisableText: '$DisableText',
// END OutputFilterOTRSDynamicFieldAttachment
";

        ${ $Param{Data} } =~ s{ $StartPattern }{$1$Replace}ixms;

    }

    return 1;
}

1;

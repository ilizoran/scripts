# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::System::Console::Command::Finance::Project::Sync2TimeAccounting;

use strict;
use warnings;

use base qw(Kernel::System::Console::BaseCommand);

our @ObjectDependencies = (
    'Kernel::System::Finance'
);

sub Configure {
    my ( $Self, %Param ) = @_;

    $Self->Description('Synchronize projects to time accounting.');

    return;
}

sub Run {
    my ( $Self, %Param ) = @_;

    $Self->Print("<yellow>Starting synchronize projects to time accounting ...</yellow>\n");

    # get finance object
    my $FinanceObject = $Kernel::OM->Get('Kernel::System::Finance');

    # get all finance items
    my @ItemIDs = $FinanceObject->ItemSearch(
        UserID => 1,
    );

    for my $ItemID (@ItemIDs) {
        $FinanceObject->TimeAccountingSync(
            ItemID => $ItemID,
            UserID => 1,
        );
    }

    $Self->Print("<green>Done.</green>\n");
    return $Self->ExitCodeOk();
}

1;

=back

=head1 TERMS AND CONDITIONS

This software is part of the OTRS project (L<http://otrs.org/>).

This software comes with ABSOLUTELY NO WARRANTY. For details, see
the enclosed file COPYING for license information (AGPL). If you
did not receive this file, see L<http://www.gnu.org/licenses/agpl.txt>.

=cut

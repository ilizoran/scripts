# --
# Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
# --
# This software comes with ABSOLUTELY NO WARRANTY. For details, see
# the enclosed file COPYING for license information (AGPL). If you
# did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
# --

package Kernel::Modules::AgentFinance;

use strict;
use warnings;

use utf8;

our $ObjectManagerDisabled = 1;

sub new {
    my ( $Type, %Param ) = @_;

    # allocate new hash for object
    my $Self = \%Param;
    bless( $Self, $Type );

    # set params for cache object
    $Self->{CacheType} = 'FinanceAgent';
    $Self->{CacheTTL}  = 60 * 60 * 24 * 20;

    $Self->{StateList} = [
        'Opportunity',
        'Offer',
        'Order',
        'Software Quality Audit',
        'Delivered',
        'Invoice',
        'Closed',
        'Lost Opportunity',
        'Lost Offer',
        'Lost Order',
    ];
    for my $StateListElement ( @{ $Self->{StateList} } ) {
        $Self->{State}->{$StateListElement} = $StateListElement;
    }
    $Self->{StateDefault} = 'Opportunity';

    $Self->{NextAction} = {
        'consulting'  => 'consulting',
        'customer'    => 'customer',
        'development' => 'development',
        'sales'       => 'sales',
        'support'     => 'support',
    };
    $Self->{NextActionDefault} = 'development';

    my %Percent = ( '' => ' -' );
    for my $Count ( 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 ) {

        my $Value = $Count;

        if ( length $Value == 1 ) {
            $Value = '  ' . $Value;
        }
        elsif ( length $Value == 2 ) {
            $Value = ' ' . $Value;
        }

        $Percent{$Count} = $Value . ' %';
    }

    $Self->{Probability} = \%Percent;
    $Self->{Processed}   = \%Percent;

    return $Self;
}

sub Run {
    my ( $Self, %Param ) = @_;

    # get needed objects
    my $ConfigObject    = $Kernel::OM->Get('Kernel::Config');
    my $LayoutObject    = $Kernel::OM->Get('Kernel::Output::HTML::Layout');
    my $CacheObject     = $Kernel::OM->Get('Kernel::System::Cache');
    my $CheckItemObject = $Kernel::OM->Get('Kernel::System::CheckItem');
    my $FinanceObject   = $Kernel::OM->Get('Kernel::System::Finance');
    my $TicketObject    = $Kernel::OM->Get('Kernel::System::Ticket');
    my $TimeObject      = $Kernel::OM->Get('Kernel::System::Time');
    my $UserObject      = $Kernel::OM->Get('Kernel::System::User');
    my $ParamObject     = $Kernel::OM->Get('Kernel::System::Web::Request');

    # ---
    # item new
    # ---
    if ( $Self->{Subaction} eq 'New' ) {

        my %GetParam;
        for my $Parameter (
            qw(Title Description CustomerUserID CustomerID State NextAction Delivery SWQADate Processed Probability TicketSales TicketDevel TicketBilling)
            )
        {
            $GetParam{$Parameter} = $ParamObject->GetParam( Param => $Parameter );
        }

        my $Output = $LayoutObject->Header(
            Title => 'New',
        );
        $Output .= $LayoutObject->NavigationBar();

        TICKETNUMBER:
        for my $TicketType (qw(TicketSales TicketDevel TicketBilling)) {

            my $TicketNumber = $ParamObject->GetParam( Param => "Invalid$TicketType" );

            next TICKETNUMBER if !$TicketNumber;

            $Output .= $LayoutObject->Notify(
                Info     => "Invalid ticket number '$TicketNumber' in $TicketType field!",
                Priority => 'Error',
            );

            $GetParam{$TicketType} = $TicketNumber;
        }

        $LayoutObject->Block(
            Name => 'CustomerAutoComplete',
        );

        # build customer search auto-complete field
        my $AutoCompleteConfig = $ConfigObject->Get('Ticket::Frontend::CustomerSearchAutoComplete');
        $LayoutObject->Block(
            Name => 'CustomerSearchAutoComplete',
            Data => {
                ActiveAutoComplete  => $AutoCompleteConfig->{Active},
                minQueryLength      => $AutoCompleteConfig->{MinQueryLength} || 2,
                queryDelay          => $AutoCompleteConfig->{QueryDelay} || 100,
                typeAhead           => $AutoCompleteConfig->{TypeAhead} || 'false',
                maxResultsDisplayed => $AutoCompleteConfig->{MaxResultsDisplayed} || 20,
            },
        );

        $LayoutObject->Block(
            Name => 'CustomerCompanyAutoComplete',
        );

        # build customer company search auto-complete field
        my $CompanyAutoCompleteConfig = $ConfigObject->Get('Ticket::Frontend::CustomerCompanySearchAutoComplete');
        $LayoutObject->Block(
            Name => 'CustomerCompanySearchAutoComplete',
            Data => {
                ActiveAutoComplete  => $CompanyAutoCompleteConfig->{Active},
                minQueryLength      => $CompanyAutoCompleteConfig->{MinQueryLength} || 2,
                queryDelay          => $CompanyAutoCompleteConfig->{QueryDelay} || 100,
                typeAhead           => $CompanyAutoCompleteConfig->{TypeAhead} || 'false',
                maxResultsDisplayed => $CompanyAutoCompleteConfig->{MaxResultsDisplayed} || 20,
            },
        );

        $LayoutObject->Block(
            Name => 'Main',
            Data => {
                Head  => 'New',
                Value => $GetParam{State},
            },
        );
        $LayoutObject->Block(
            Name => 'MainMenu',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainMenuLink',
            Data => {
                Name  => 'Go to overview',
                Link  => "Action=$Self->{Action}",
                Title => 'Go to overview',
                Class => 'Back',
                Icon  => 'caret-left',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentForm',
            Data => {
                Subaction => 'NewAction',
                Type      => $GetParam{State},
                Content   => "Item",
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'Title',
                Key   => 'Title',
                Value => $GetParam{Title},
                Class => 'W50pc',
                ID    => 'Title',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemArea',
            Data => {
                Name  => 'Description',
                Key   => 'Description',
                Value => '',
                Rows  => 8,
                Cols  => 71,
                ID    => 'Description',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemArea',
            Data => {
                Name  => 'InfoBilling',
                Key   => 'InfoBilling',
                Value => '',
                Rows  => 3,
                Cols  => 71,
                ID    => 'InfoBilling',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'Customer User',
                Key   => 'CustomerUserID',
                Value => $GetParam{CustomerUserID},
                Class => 'W50pc AutocompleteOff',
                ID    => 'CustomerAutoComplete',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemHidden',
            Data => {
                Object   => 'SelectedCustomerUser',
                ObjectID => $GetParam{SelectedCustomerUser},
                ID       => 'SelectedCustomerUser',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'Customer Company',
                Key   => 'CustomerID',
                Value => $GetParam{CustomerID},
                Class => 'W50pc AutocompleteOff',
                ID    => 'CustomerCompanyAutoComplete',
            },
        );

        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'State',
                Value => $LayoutObject->BuildSelection(
                    Data           => $Self->{State},
                    SelectedID     => $Param{State} || $Self->{StateDefault},
                    Name           => 'State',
                    Class          => 'Modernize',
                    Translation    => 0,
                    Sort           => 'IndividualKey',
                    SortIndividual => $Self->{StateList},
                ),
                ID => 'State',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'Next Action',
                Value => $LayoutObject->BuildSelection(
                    Data        => $Self->{NextAction},
                    SelectedID  => $Param{NextAction} || $Self->{NextActionDefault},
                    Name        => 'NextAction',
                    Class       => 'Modernize',
                    Translation => 0,
                ),
                ID => 'NextAction',
            },
        );
        for my $Type (qw(TicketSales TicketDevel TicketBilling)) {
            $LayoutObject->Block(
                Name => 'MainContentFormItem',
                Data => {},
            );
            $LayoutObject->Block(
                Name => 'MainContentFormItemInput',
                Data => {
                    Name  => $Type,
                    Key   => $Type,
                    Value => $GetParam{$Type},
                    Class => 'W25pc',
                    ID    => $Type,
                },
            );
        }
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'SWQADate',
                Key   => 'SWQADate',
                Value => '',
                Class => 'W25pc',
                ID    => 'SWQADate',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'Delivery',
                Key   => 'Delivery',
                Value => '',
                Class => 'W25pc',
                ID    => 'Delivery',
            },
        );

        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'Probability',
                Value => $LayoutObject->BuildSelection(
                    Data           => $Self->{Probability},
                    SelectedID     => $Param{Probability},
                    Name           => 'Probability',
                    Class          => 'Modernize',
                    Sort           => 'IndividualKey',
                    SortIndividual => [ '', 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 ],
                ),
                ID => 'Probability',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'Processed',
                Value => $LayoutObject->BuildSelection(
                    Data           => $Self->{Processed},
                    SelectedID     => $Param{Processed},
                    Name           => 'Processed',
                    Class          => 'Modernize',
                    Sort           => 'IndividualKey',
                    SortIndividual => [ '', 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 ],
                ),
                ID => 'Processed',
            },
        );

        $Output .= $LayoutObject->Output(
            TemplateFile => 'AgentFinance',
            Data         => \%Param
        );
        $Output .= $LayoutObject->Footer();

        return $Output;
    }

    # ---
    # new action
    # ---
    elsif ( $Self->{Subaction} eq 'NewAction' ) {

        my %GetParam;
        for my $Parameter (
            qw(Title Description InfoBilling CustomerUserID SelectedCustomerUser CustomerID State NextAction TicketSales TicketDevel TicketBilling Processed Probability Delivery SWQADate)
            )
        {
            $GetParam{$Parameter} = $ParamObject->GetParam( Param => $Parameter );
        }

        my %InvalidTicketNumbers;

        TICKETNUMBER:
        for my $TicketType (qw(TicketSales TicketDevel TicketBilling)) {

            $CheckItemObject->StringClean(
                StringRef         => \$GetParam{$TicketType},
                TrimLeft          => 1,
                TrimRight         => 1,
                RemoveAllNewlines => 1,
                RemoveAllTabs     => 1,
                RemoveAllSpaces   => 1,
            );

            STRING:
            for my $String ( 'n/a', '-' ) {

                next STRING if $GetParam{$TicketType} ne $String;

                $GetParam{$TicketType} = '';

                last STRING;
            }

            next TICKETNUMBER if !$GetParam{$TicketType};

            # lookup ticket number
            my $TicketID = $Self->TicketIDLookup(
                TicketNumber => $GetParam{$TicketType},
            );

            next TICKETNUMBER if $TicketID;

            $InvalidTicketNumbers{$TicketType} = $GetParam{$TicketType};
            $GetParam{$TicketType}             = '';
        }

        $GetParam{CustomerUserID} = $GetParam{SelectedCustomerUser};

        my $ItemID = $FinanceObject->ItemAdd( %GetParam, UserID => $Self->{UserID} );

        if ( !$ItemID ) {

            return $LayoutObject->ErrorScreen();
        }

        my $InvalidTicketNumber = '';
        for my $TicketType ( sort keys %InvalidTicketNumbers ) {
            $InvalidTicketNumber .= ";Invalid$TicketType=$InvalidTicketNumbers{$TicketType}";
        }

        return $LayoutObject->Redirect(
            OP => "Action=$Self->{Action};Subaction=Update;ItemID=$ItemID" . $InvalidTicketNumber,
        );
    }

    # ---
    # update
    # ---
    elsif ( $Self->{Subaction} eq 'Update' ) {

        my %GetParam;
        $GetParam{ItemID} = $ParamObject->GetParam( Param => 'ItemID' );

        my %Data = $FinanceObject->ItemGet(
            ItemID => $GetParam{ItemID},
            UserID => $Self->{UserID},
        );

        my $Output = $LayoutObject->Header(
            Title => 'Update',
            Value => $Data{Number},
        );
        $Output .= $LayoutObject->NavigationBar();

        TICKETNUMBER:
        for my $TicketType (qw(TicketSales TicketDevel TicketBilling)) {

            my $TicketNumber = $ParamObject->GetParam( Param => "Invalid$TicketType" );

            next TICKETNUMBER if !$TicketNumber;

            $Output .= $LayoutObject->Notify(
                Info     => "Invalid ticket number '$TicketNumber' in $TicketType field!",
                Priority => 'Error',
            );

            $Data{$TicketType} = $TicketNumber;
        }

        $LayoutObject->Block(
            Name => 'CustomerAutoComplete',
        );

        # build customer search auto-complete field
        my $AutoCompleteConfig = $ConfigObject->Get('Ticket::Frontend::CustomerSearchAutoComplete');
        $LayoutObject->Block(
            Name => 'CustomerSearchAutoComplete',
            Data => {
                ActiveAutoComplete  => $AutoCompleteConfig->{Active},
                minQueryLength      => $AutoCompleteConfig->{MinQueryLength} || 2,
                queryDelay          => $AutoCompleteConfig->{QueryDelay} || 100,
                typeAhead           => $AutoCompleteConfig->{TypeAhead} || 'false',
                maxResultsDisplayed => $AutoCompleteConfig->{MaxResultsDisplayed} || 20,
            },
        );
        $LayoutObject->Block(
            Name => 'CustomerCompanyAutoComplete',
        );

        # build customer company search auto-complete field
        my $CompanyAutoCompleteConfig = $ConfigObject->Get('Ticket::Frontend::CustomerCompanySearchAutoComplete');
        $LayoutObject->Block(
            Name => 'CustomerCompanySearchAutoComplete',
            Data => {
                ActiveAutoComplete  => $CompanyAutoCompleteConfig->{Active},
                minQueryLength      => $CompanyAutoCompleteConfig->{MinQueryLength} || 2,
                queryDelay          => $CompanyAutoCompleteConfig->{QueryDelay} || 100,
                typeAhead           => $CompanyAutoCompleteConfig->{TypeAhead} || 'false',
                maxResultsDisplayed => $CompanyAutoCompleteConfig->{MaxResultsDisplayed} || 20,
            },
        );

        $LayoutObject->Block(
            Name => 'Main',
            Data => {
                Head  => 'Update',
                Value => $Data{State},
            },
        );
        $LayoutObject->Block(
            Name => 'MainMenu',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainMenuLink',
            Data => {
                Name  => 'Back',
                Link  => "Action=$Self->{Action};Subaction=View;ItemID=$Data{ItemID}",
                Title => 'Back',
                Class => 'Back',
                Icon  => 'caret-left',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentForm',
            Data => {
                Type      => 'Update',
                Content   => "Item #$Data{ItemID}",
                Subaction => 'UpdateAction',
                State     => $Data{State},
            },
        );

        $LayoutObject->Block(
            Name => 'MainContentFormItemHidden',
            Data => {
                Object   => 'ItemID',
                ObjectID => $Data{ItemID},
            },
        );

        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'Title',
                Key   => 'Title',
                Value => $Data{Title},
                Class => 'W50pc',
                ID    => 'Title',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemArea',
            Data => {
                Name  => 'Description',
                Key   => 'Description',
                Value => $Data{Description},
                Rows  => 8,
                Cols  => 78,
                ID    => 'Description',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemArea',
            Data => {
                Name  => 'InfoBilling',
                Key   => 'InfoBilling',
                Value => $Data{InfoBilling},
                Rows  => 3,
                Cols  => 78,
                ID    => 'InfoBilling',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'Customer User',
                Key   => 'CustomerUserID',
                Value => $Data{CustomerUserID},
                Class => 'W50pc',
                ID    => 'CustomerAutoComplete',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemHidden',
            Data => {
                Object   => 'SelectedCustomerUser',
                ObjectID => $Data{SelectedCustomerUser},
                ID       => 'SelectedCustomerUser',
            },
        );

        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'Customer Company',
                Key   => 'CustomerID',
                Value => $Data{CustomerID},
                Class => 'W50pc',
                ID    => 'CustomerCompanyAutoComplete',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'State',
                Value => $LayoutObject->BuildSelection(
                    Data           => $Self->{State},
                    SelectedID     => $Data{State} || 'open',
                    Name           => 'State',
                    Class          => 'Modernize',
                    Translation    => 0,
                    Sort           => 'IndividualKey',
                    SortIndividual => $Self->{StateList},
                ),
                ID => 'State',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'Next Action',
                Value => $LayoutObject->BuildSelection(
                    Data        => $Self->{NextAction},
                    SelectedID  => $Data{NextAction} || 'open',
                    Name        => 'NextAction',
                    Class       => 'Modernize',
                    Translation => 0,
                ),
                ID => 'NextAction',
            },
        );
        for my $Type (qw(TicketSales TicketDevel TicketBilling)) {
            $LayoutObject->Block(
                Name => 'MainContentFormItem',
                Data => {},
            );
            $LayoutObject->Block(
                Name => 'MainContentFormItemInput',
                Data => {
                    Name  => $Type,
                    Key   => $Type,
                    Value => $Data{$Type},
                    Class => 'W25pc',
                    ID    => $Type,
                },
            );
        }
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'SWQADate',
                Key   => 'SWQADate',
                Value => $Data{SWQADate},
                Class => 'W25pc',
                ID    => 'SWQADate',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemInput',
            Data => {
                Name  => 'Delivery',
                Key   => 'Delivery',
                Value => $Data{Delivery},
                Class => 'W25pc',
                ID    => 'Delivery',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'Probability',
                Value => $LayoutObject->BuildSelection(
                    Data           => $Self->{Probability},
                    SelectedID     => $Data{Probability},
                    Name           => 'Probability',
                    Class          => 'Modernize',
                    Sort           => 'IndividualKey',
                    SortIndividual => [ '', 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 ],
                ),
                ID => 'Probability',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'Processed',
                Value => $LayoutObject->BuildSelection(
                    Data           => $Self->{Processed},
                    SelectedID     => $Data{Processed},
                    Name           => 'Processed',
                    Class          => 'Modernize',
                    Sort           => 'IndividualKey',
                    SortIndividual => [ '', 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 ],
                ),
                ID => 'Processed',
            },

        );

        my %ShownUsers = $UserObject->UserList(
            Type  => 'Long',
            Valid => 1,
        );

        $ShownUsers{''} = '-';
        my $OwnerStrg = $LayoutObject->BuildSelection(
            Data       => \%ShownUsers,
            SelectedID => $Data{OwnerID},
            Name       => 'OwnerID',
            Class      => 'Modernize',
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'Job Owner',
                Value => $OwnerStrg,
                ID    => 'OwnerID',
            },
        );

        $LayoutObject->Block(
            Name => 'MainContentFormItemArticle',
            Data => {
                ArticleList => $LayoutObject->BuildSelection(
                    Data => {
                        '' => '-',
                        $FinanceObject->ArticleList(),
                    },
                    Name  => 'ArticleID',
                    Class => 'Modernize',
                    Title => $LayoutObject->{LanguageObject}->Get('Product'),
                ),
            },
        );

        my @ItemArticleIDs = $FinanceObject->ItemArticleList(
            ItemID => $Data{ItemID},
            UserID => $Self->{UserID},
        );
        my $Total        = 0;
        my $TotalInclTax = 0;
        my $Count        = 0;
        for my $ItemArticleID (@ItemArticleIDs) {
            $Count++;
            my %ItemArticle = $FinanceObject->ItemArticleGet(
                ItemArticleID => $ItemArticleID,
                UserID        => $Self->{UserID},
            );
            $Total        = $Total + $ItemArticle{Total};
            $TotalInclTax = $TotalInclTax + $ItemArticle{TotalInclTax};
            my $ArticleList = $LayoutObject->BuildSelection(
                Data => {
                    $FinanceObject->ArticleList(),
                },
                SelectedID => $ItemArticle{ArticleID},
                Name       => 'Article::ArticleID',
                Class      => 'Modernize',
                ID         => 'Article::ArticleID' . $Count,
                Title      => $LayoutObject->{LanguageObject}->Get('New Position'),
            );
            my %ShownUsers = $UserObject->UserList(
                Type  => 'Long',
                Valid => 1,
            );
            $ShownUsers{''} = '-';
            my $OwnerStrg = $LayoutObject->BuildSelection(
                Data       => \%ShownUsers,
                SelectedID => $ItemArticle{OwnerID} || '',
                Name       => 'Article::OwnerID',
                Class      => 'Modernize',
                ID         => 'Article::OwnerID::' . $Count,
                Title      => $LayoutObject->{LanguageObject}->Get('Article - Owner'),
            );
            $LayoutObject->Block(
                Name => 'MainContentFormItemArticleItem',
                Data => {
                    %ItemArticle,
                    ArticleList => $ArticleList,
                    Count       => $Count,
                    OwnerStrg   => $OwnerStrg,
                    ID          => 'Article::OwnerID::' . $Count,
                },
            );
        }
        $LayoutObject->Block(
            Name => 'MainContentFormItemArticleSum',
            Data => {
                Total        => $Total,
                TotalInclTax => $TotalInclTax,
            },
        );

        $Output .= $LayoutObject->Output(
            TemplateFile => 'AgentFinance',
            Data         => \%Param
        );
        $Output .= $LayoutObject->Footer();

        return $Output;
    }

    # ---
    # update action
    # ---
    elsif ( $Self->{Subaction} eq 'UpdateAction' ) {

        my %GetParam;
        for my $Parameter (
            qw(ItemID Title Description InfoBilling CustomerUserID SelectedCustomerUser CustomerID State NextAction TicketSales TicketDevel TicketBilling Delivery SWQADate Processed Probability OwnerID)
            )
        {
            $GetParam{$Parameter} = $ParamObject->GetParam( Param => $Parameter );
        }

        # set customer user
        $GetParam{CustomerUserID} = $GetParam{SelectedCustomerUser} || $GetParam{CustomerUserID};

        my %InvalidTicketNumbers;

        TICKETNUMBER:
        for my $TicketType (qw(TicketSales TicketDevel TicketBilling)) {

            $CheckItemObject->StringClean(
                StringRef         => \$GetParam{$TicketType},
                TrimLeft          => 1,
                TrimRight         => 1,
                RemoveAllNewlines => 1,
                RemoveAllTabs     => 1,
                RemoveAllSpaces   => 1,
            );

            STRING:
            for my $String ( 'n/a', '-' ) {

                next STRING if $GetParam{$TicketType} ne $String;

                $GetParam{$TicketType} = '';

                last STRING;
            }

            next TICKETNUMBER if !$GetParam{$TicketType};

            # lookup ticket number
            my $TicketID = $Self->TicketIDLookup(
                TicketNumber => $GetParam{$TicketType},
            );

            next TICKETNUMBER if $TicketID;

            $InvalidTicketNumbers{$TicketType} = $GetParam{$TicketType};
            $GetParam{$TicketType}             = '';
        }

        # update meta
        if ( !$FinanceObject->ItemUpdate( %GetParam, UserID => $Self->{UserID} ) ) {

            return $LayoutObject->ErrorScreen();
        }

        # update article
        my @ItemArticleIDs = $FinanceObject->ItemArticleList(
            ItemID => $GetParam{ItemID},
            UserID => $Self->{UserID},
        );

        my %GetParamArticle;
        for my $ArticleParameter (
            qw(ArticleID Number Title Situation Description Comment Discount PiceReal PicePublic Price Tax OwnerID)
            )
        {
            my @Array = $ParamObject->GetArray( Param => 'Article::' . $ArticleParameter );
            $GetParamArticle{$ArticleParameter} = \@Array;
        }

        for my $Count ( 0 .. $#{ $GetParamArticle{ArticleID} } ) {

            my %ItemArticle = $FinanceObject->ItemArticleGet(
                ItemArticleID => $ItemArticleIDs[$Count],
                UserID        => $Self->{UserID},
            );

            for my $ArticleElement (
                qw(ArticleID Number Title Situation Description Comment Discount PiceReal PicePublic Price Tax OwnerID)
                )
            {
                $ItemArticle{$ArticleElement} = $GetParamArticle{$ArticleElement}->[$Count];
            }

            $FinanceObject->ItemArticleUpdate(
                %ItemArticle,
                UserID => $Self->{UserID},
            );
        }

        # add article
        $GetParam{ArticleID} = $ParamObject->GetParam( Param => 'ArticleID' );

        if ( $GetParam{ArticleID} ) {

            my %Article = $FinanceObject->ArticleGet(
                ArticleID => $GetParam{ArticleID},
                UserID    => $Self->{UserID},
            );

            my $ArticleAdd = $FinanceObject->ItemArticleAdd(
                %Article,
                Title       => '',
                Description => '',
                OwnerID     => undef,
                PiceReal    => 0,
                PicePublic  => 0,
                ItemID      => $GetParam{ItemID},
                UserID      => $Self->{UserID},
            );
        }

        # delete article
        my @ArticleDelete;
        my $DeleteAction;
        for my $Counter ( 0 .. 100 ) {

            if ( $ParamObject->GetParam( Param => 'ArticleDelete::' . $Counter ) ) {

                $FinanceObject->ItemArticleDelete(
                    ItemArticleID => $ItemArticleIDs[ $Counter - 1 ],
                    UserID        => $Self->{UserID},
                );
                $DeleteAction = 1;
            }
        }

        if ( $DeleteAction || $GetParam{ArticleID} || %InvalidTicketNumbers ) {

            my $InvalidTicketNumber = '';
            for my $TicketType ( sort keys %InvalidTicketNumbers ) {
                $InvalidTicketNumber .= ";Invalid$TicketType=$InvalidTicketNumbers{$TicketType}";
            }

            return $LayoutObject->Redirect(
                OP => "Action=$Self->{Action};Subaction=Update;ItemID=$GetParam{ItemID}"
                    . $InvalidTicketNumber,
            );
        }

        return $LayoutObject->Redirect(
            OP => "Action=$Self->{Action};Subaction=View;ItemID=$GetParam{ItemID}",
        );
    }

    # ---
    # view
    # ---
    elsif ( $Self->{Subaction} eq 'View' ) {
        my %GetParam = ();
        $GetParam{ItemID} = $ParamObject->GetParam( Param => 'ItemID' );

        my %Data = $FinanceObject->ItemGet(
            ItemID => $GetParam{ItemID},
            UserID => $Self->{UserID},
        );

        $LayoutObject->Block(
            Name => 'Main',
            Data => {
                Head  => 'Summary',
                Value => 'Project# ' . $Data{Number},
            },
        );
        $LayoutObject->Block(
            Name => 'MainMenu',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainMenuLink',
            Data => {
                Name  => 'Go to overview',
                Link  => "Action=$Self->{Action};State=$Data{State}",
                Title => 'Go to overview',
                Class => 'Back',
                Icon  => 'caret-left',
            },
        );
        $LayoutObject->Block(
            Name => 'MainMenuLink',
            Data => {
                Name  => 'Edit',
                Link  => "Action=$Self->{Action};Subaction=Update;ItemID=$Data{ItemID}",
                Title => 'Edit',
                Class => 'Edit',
                Icon  => 'edit',
            },
        );
        $LayoutObject->Block(
            Name => 'MainMenuLink',
            Data => {
                Name  => 'Export Offer',
                Link  => "Action=$Self->{Action};Subaction=ExportOffer;ItemID=$Data{ItemID}",
                Title => 'Export Offer',
                Class => 'AsPopup Download',
                Icon  => 'download',
            },
        );
        $LayoutObject->Block(
            Name => 'MainMenuLink',
            Data => {
                Name  => 'Export Devel',
                Link  => "Action=$Self->{Action};Subaction=ExportDevel;ItemID=$Data{ItemID}",
                Title => 'Export Devel',
                Class => 'AsPopup Download',
                Icon  => 'download',
            },
        );
        $LayoutObject->Block(
            Name => 'MainMenuLink',
            Data => {
                Name  => 'Export Billing',
                Link  => "Action=$Self->{Action};Subaction=ExportBilling;ItemID=$Data{ItemID}",
                Title => 'Export Billing',
                Class => 'AsPopup Download',
                Icon  => 'download',
            },
        );

        $LayoutObject->Block(
            Name => 'MainContentView',
            Data => {
                Title => $Data{State},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'Title',
                Key   => 'Title',
                Value => $Data{Title},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemArea',
            Data => {
                Name  => 'Description',
                Key   => 'Description',
                Value => $LayoutObject->Ascii2Html(
                    Text           => $Data{Description},
                    HTMLResultMode => 1,
                    LinkFeature    => 1,
                ),
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemArea',
            Data => {
                Name  => 'InfoBilling',
                Key   => 'InfoBilling',
                Value => $LayoutObject->Ascii2Html(
                    Text           => $Data{InfoBilling},
                    HTMLResultMode => 1,
                    LinkFeature    => 1,
                ),
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'Customer User',
                Key   => 'CustomerUserID',
                Value => $Data{CustomerUserID},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'Customer Company',
                Key   => 'CustomerID',
                Value => $Data{CustomerID},
            },
        );

        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        if ( $Data{CustomerID} ) {

            $LayoutObject->Block(
                Name => 'MainContentViewItemLinkNormal',
                Data => {
                    Name => 'SupportDB',
                    Link => $LayoutObject->{Baselink}
                        . 'Action=AgentSupportDB;CustomerID='
                        . $LayoutObject->LinkEncode( $Data{CustomerID} ),
                    Value => 'SupportDB',
                },
            );
        }
        else {

            $LayoutObject->Block(
                Name => 'MainContentViewItemInputItalic',
                Data => {
                    Name  => 'SupportDB',
                    Key   => 'SupportDB',
                    Value => $LayoutObject->{LanguageObject}->Get(
                        'Please enter a customer company to make the SupportDB link available.'
                    ),
                },
            );
        }

        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'State',
                Key   => 'State',
                Value => $Data{State},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'NextAction',
                Key   => 'NextAction',
                Value => $Data{NextAction},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'Volume',
                Key   => 'Volume',
                Value => $Data{Volume},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentFormItemData',
            Data => {
                Name  => 'Next Action',
                Value => $LayoutObject->BuildSelection(
                    Data       => $Self->{NextAction},
                    SelectedID => $Data{NextAction} || 'open',
                    Name       => 'NextAction',
                    Class      => 'Modernize',
                ),
            },
        );
        for my $Type (qw(TicketSales TicketDevel TicketBilling)) {
            my %Ticket;
            if ( $Data{$Type} ) {
                my $TicketID = $Self->TicketIDLookup(
                    TicketNumber => $Data{$Type},
                    UserID       => 1,
                );
                if ($TicketID) {
                    %Ticket = $TicketObject->TicketGet(
                        TicketID => $TicketID,
                        UserID   => 1,
                    );
                }
            }
            $LayoutObject->Block(
                Name => 'MainContentViewItem',
                Data => {},
            );
            $LayoutObject->Block(
                Name => 'MainContentViewItemLink',
                Data => {
                    %Ticket,
                    Name  => $Type,
                    Key   => $Type,
                    Value => $Data{$Type},
                    Link  => $LayoutObject->{Baselink}
                        . 'Action=AgentTicketZoom;TicketNumber='
                        . $Data{$Type},
                },
            );
        }
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'SWQADate',
                Key   => 'SWQADate',
                Value => $Data{SWQADate},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'Delivery',
                Key   => 'Delivery',
                Value => $Data{Delivery},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'Probability',
                Key   => 'Probability',
                Value => $Data{Probability},
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'Processed',
                Key   => 'Processed',
                Value => $Data{Processed},
            },
        );
        my %ShownUsers = $UserObject->UserList(
            Type  => 'Long',
            Valid => 1,
        );
        my $UserOwner = $Data{OwnerID} ? $ShownUsers{ $Data{OwnerID} } : '';

        $LayoutObject->Block(
            Name => 'MainContentViewItem',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewItemInput',
            Data => {
                Name  => 'Job Owner',
                Key   => 'Job Owner',
                Value => $UserOwner || '-',
            },
        );
        for my $Type (qw(Changed Created)) {
            $LayoutObject->Block(
                Name => 'MainContentViewItem',
                Data => {},
            );
            $LayoutObject->Block(
                Name => 'MainContentViewItemInput',
                Data => {
                    Name  => $Type,
                    Key   => $Type,
                    Value => $Data{$Type},
                },
            );
        }

        # offer
        $LayoutObject->Block(
            Name => 'MainContentView',
            Data => {
                Title => 'Position',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTable',
            Data => {},
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTableRowHead',
            Data => {
                Name => 'Number',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTableRowHeadCol',
            Data => {
                Width => 'W3pc',
                Name  => '#',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTableRowHeadCol',
            Data => {
                Name => 'Title',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTableRowHeadCol',
            Data => {
                Width => 'W8pc',
                Name  => 'Effort (Real)',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTableRowHeadCol',
            Data => {
                Width => 'W10pc',
                Name  => 'Effort (Customer)',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTableRowHeadCol',
            Data => {
                Width => 'W5pc',
                Name  => 'Discount',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTableRowHeadCol',
            Data => {
                Width => 'W5pc',
                Name  => 'Tax',
            },
        );
        $LayoutObject->Block(
            Name => 'MainContentViewTableRowHeadCol',
            Data => {
                Align => 'Right',
                Width => 'W8pc',
                Name  => 'Total Net',
            },
        );
        my @ItemArticleIDs = $FinanceObject->ItemArticleList(
            ItemID => $Data{ItemID},
            UserID => $Self->{UserID},
        );
        my $Total        = 0;
        my $TotalPlanned = 0;
        my $TotalInclTax = 0;
        my $Count        = 0;
        for my $ItemArticleID (@ItemArticleIDs) {
            $Count++;
            my %ItemArticle = $FinanceObject->ItemArticleGet(
                ItemArticleID => $ItemArticleID,
                UserID        => $Self->{UserID},
            );
            if ( $ItemArticle{PiceReal} ) {
                $TotalPlanned = $TotalPlanned + ( $ItemArticle{PiceReal} * 8 );
            }
            $Total        = $Total + $ItemArticle{Total};
            $TotalInclTax = $TotalInclTax + $ItemArticle{TotalInclTax};

            # new row
            $LayoutObject->Block(
                Name => 'MainContentViewTableRow',
                Data => {},
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
                Data => {},
            );

            # position number
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColNormal',
                Data => {
                    Value => $Count,
                },
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
            );

            # title
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColBold',
                Data => {
                    Value => $ItemArticle{ArticleTitle},
                },
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
                Data => {},
            );

            # effort real
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColNormal',
                Data => {
                    Value => $ItemArticle{PiceReal} . 'd',
                },
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
                Data => {},
            );

            # effort customer
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColNormal',
                Data => {
                    Value => $ItemArticle{PicePublic} . 'd',
                },
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
                Data => {},
            );

            # discount
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColNormal',
                Data => {
                    Value => $ItemArticle{Discount} . '%',
                },
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
                Data => {},
            );

            # tax
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColNormal',
                Data => {
                    Value => $ItemArticle{Tax} . '%',
                },
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
            );

            # total netto
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColNormal',
                Data => {
                    Value => $ItemArticle{Total},
                },
            );

            # new row
            $LayoutObject->Block(
                Name => 'MainContentViewTableRow',
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
                Data => {},
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
                Data => {
                    Colspan => '5',
                },
            );

            # title
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColBold',
                Data => {
                    Value => $ItemArticle{Title},
                },
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
            );

            # new row
            $LayoutObject->Block(
                Name => 'MainContentViewTableRow',
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
                Data => {
                    Colspan => '5',
                },
            );

            if ( $ItemArticle{Situation} ) {
                $LayoutObject->Block(
                    Name => 'MainContentViewTableRowColSituation',
                    Data => {
                        Value => $LayoutObject->Ascii2Html(
                            Text           => $ItemArticle{Situation},
                            HTMLResultMode => 1,
                            LinkFeature    => 1,
                        ),
                    },
                );
            }

            if ( $ItemArticle{Description} ) {
                $LayoutObject->Block(
                    Name => 'MainContentViewTableRowColDescription',
                    Data => {
                        Value => $LayoutObject->Ascii2Html(
                            Text           => $ItemArticle{Description},
                            HTMLResultMode => 1,
                            LinkFeature    => 1,
                        ),
                    },
                );
            }

            if ( $ItemArticle{Comment} ) {
                $LayoutObject->Block(
                    Name => 'MainContentViewTableRowColIntern',
                    Data => {
                        Value => $LayoutObject->Ascii2Html(
                            Text           => $ItemArticle{Comment},
                            HTMLResultMode => 1,
                            LinkFeature    => 1,
                        ),
                    },
                );
            }

            # owner
            my $ValueOwner = '-';
            if ( $ItemArticle{OwnerID} && $ShownUsers{ $ItemArticle{OwnerID} } ) {
                $ValueOwner = $ShownUsers{ $ItemArticle{OwnerID} };
            }
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowColJobOwner',
                Data => {
                    Value => $ValueOwner,
                },
            );

            # new column
            $LayoutObject->Block(
                Name => 'MainContentViewTableRowCol',
            );
        }

        $LayoutObject->Block(
            Name => 'MainContentViewTableRowSum',
            Data => {
                Total        => $Total,
                TotalInclTax => $TotalInclTax,
            },
        );

        # get project based accounted time
        my $TimeAccountingObject = $Kernel::OM->Get('Kernel::System::TimeAccounting');

        my %ProjectData = $TimeAccountingObject->ProjectSettingsGet();
        my $ProjectID;
        my $Number = $Data{Number};
        while ( length($Number) < 4 ) {
            $Number = '0' . $Number;
        }
        my $StringMatch1 = "PROJECT#$Number";

        PROJECT:
        for my $ProjectIDTmp ( sort keys %{ $ProjectData{Project} } ) {
            if ( $ProjectData{Project}->{$ProjectIDTmp} =~ /^\Q$StringMatch1\E\s/ ) {
                $ProjectID = $ProjectIDTmp;
                last PROJECT;
            }
        }
        if ($ProjectID) {
            $LayoutObject->Block(
                Name => 'MainContentActivity',
                Data => {
                    Title => 'Activity'
                },
            );
            my $Total               = 0;
            my @ProjectHistoryArray = $TimeAccountingObject->ProjectHistory(
                ProjectID => $ProjectID,
            );
            for my $ProjectHistory (@ProjectHistoryArray) {
                $Total = $Total + $ProjectHistory->{Period};
                $ProjectHistory->{Period} =~ s/^(.+?\.\d\d).+?/$1/;
                $LayoutObject->Block(
                    Name => 'MainContentActivityItem',
                    Data => $ProjectHistory,
                );
            }
            $LayoutObject->Block(
                Name => 'MainContentActivityItem',
                Data => {
                    Period => "Sum: $Total",
                },
            );

            $LayoutObject->Block(
                Name => 'MainContentActivitySummary',
                Data => {
                    Title   => 'Activity Summary',
                    Planned => $TotalPlanned,
                    Total   => $Total,
                },
            );
        }

        my $Output = $LayoutObject->Header(
            Title => 'View',
            Value => $Data{Number},
        );
        $Output .= $LayoutObject->NavigationBar();
        $Output .= $LayoutObject->Output(
            TemplateFile => 'AgentFinance',
            Data         => \%Param
        );
        $Output .= $LayoutObject->Footer();

        return $Output;
    }

    # ---
    # export offer
    # ---
    elsif ( $Self->{Subaction} eq 'ExportOffer' ) {
        my %GetParam = ();
        $GetParam{ItemID} = $ParamObject->GetParam( Param => 'ItemID' );

        my %Data = $FinanceObject->ItemGet(
            ItemID => $GetParam{ItemID},
            UserID => $Self->{UserID},
        );

        my $Output = '';
        $Output .= "Number:      $Data{Number}\n";
        $Output .= "Title:       $Data{Title}\n";
        $Output .= "TicketSales: $Data{TicketSales}\n";
        $Output .= "Description: $Data{Description}\n";
        $Output .= "\n";
        $Output .= "\n";
        my @ItemArticleIDs = $FinanceObject->ItemArticleList(
            ItemID => $Data{ItemID},
            UserID => $Self->{UserID},
        );
        my $Total        = 0;
        my $TotalInclTax = 0;
        my $Count        = 0;
        for my $ItemArticleID (@ItemArticleIDs) {
            $Count++;
            my %ItemArticle = $FinanceObject->ItemArticleGet(
                ItemArticleID => $ItemArticleID,
                UserID        => $Self->{UserID},
            );
            $Total        = $Total + $ItemArticle{Total};
            $TotalInclTax = $TotalInclTax + $ItemArticle{TotalInclTax};
            $Output .= "$Count $ItemArticle{ArticleTitle}: $ItemArticle{Title}\n";
            my $Length = length("$Count $ItemArticle{ArticleTitle}: $ItemArticle{Title}");
            LENGTH:
            for ( 1 .. $Length ) {
                last LENGTH if $Length == 76;
                $Output .= "=";
            }
            $Output .= "\n";

            #                    %ItemArticle,
            if ( $ItemArticle{Situation} ) {
                $Output .= "\nSituation:\n";
                $Output .= "----------\n";
                $Output .= "$ItemArticle{Situation}\n";
            }
            if ( $ItemArticle{Description} ) {
                $Output .= "\nImplementation:\n";
                $Output .= "---------------\n";
                $Output .= "$ItemArticle{Description}\n";
            }
            if ( $ItemArticle{Comment} ) {
                $Output .= "\nInternal:\n";
                $Output .= "---------\n";
                $Output .= "$ItemArticle{Comment}\n";
            }
            $Output .= "\n";
            $Output .= "Services:\n";
            $Output .= "---------\n";
            $Output .= "Die Erweiterung enthält:
    o d\\\\ie implementierte Funktionalität
    o d\\\\ie Funktions- und Integrationstests
    o d\\\\ie Dokumentation (im PDF-Format)
    o d\\\\ie Bereitstellung eines Abnahme Systems (Virtuelles System)
    o d\\\\ie Remote Installationsbegleitung
    o d\\\\ie Übergabe/Lieferung in versionierten OPM-Paketen\n";
            $Output =~ s/\\\\//g;
            $Output .= "\n";
            $Output .= "Price:\n";
            $Output .= "------\n";
            $Output
                .= " $ItemArticle{PicePublic} x $ItemArticle{Price} EUR (Discount:$ItemArticle{Discount}%) = $ItemArticle{Total} EUR (zzgl. Tax $ItemArticle{Tax}%)\n";
            $Output .= "\n";
            $Output .= "\n";
        }
        my $Tax = $TotalInclTax - $Total;
        $Output .= "Price Total:\n";
        $Output .= "------------\n";
        $Output .= "  Netto:  $Total EUR\n";
        $Output .= "  Tax:     $Tax EUR\n";
        $Output .= "  ================\n";
        $Output .= "  Total:  $TotalInclTax EUR\n";
        $Output .= "  ================\n";

        return $LayoutObject->Attachment(
            ContentType => 'text/plain; charset=' . $LayoutObject->{UserCharset},
            Content     => $Output,
            Type        => 'inline'
        );
    }

    # ---
    # export devel
    # ---
    elsif ( $Self->{Subaction} eq 'ExportDevel' ) {
        my %GetParam = ();
        $GetParam{ItemID} = $ParamObject->GetParam( Param => 'ItemID' );

        my %Data = $FinanceObject->ItemGet(
            ItemID => $GetParam{ItemID},
            UserID => $Self->{UserID},
        );

        my $Output = '';
        $Output .= "Number:      $Data{Number}\n";
        $Output .= "Title:       $Data{Title}\n";
        $Output .= "TicketSales: $Data{TicketSales}\n";
        $Output .= "InfoBilling: $Data{InfoBilling}\n";
        $Output .= "\n";
        $Output .= "\n";
        my @ItemArticleIDs = $FinanceObject->ItemArticleList(
            ItemID => $Data{ItemID},
            UserID => $Self->{UserID},
        );
        my $Count = 0;
        for my $ItemArticleID (@ItemArticleIDs) {
            $Count++;
            my %ItemArticle = $FinanceObject->ItemArticleGet(
                ItemArticleID => $ItemArticleID,
                UserID        => $Self->{UserID},
            );
            $Output .= "$Count $ItemArticle{ArticleTitle}: $ItemArticle{Title}\n";
            my $Length = length("$Count $ItemArticle{ArticleTitle}: $ItemArticle{Title}");
            LENGTH:
            for ( 1 .. $Length ) {
                last LENGTH if $Length == 76;
                $Output .= "=";
            }
            $Output .= "\n";

            #                    %ItemArticle,
            if ( $ItemArticle{Situation} ) {
                $Output .= "\nSituation:\n";
                $Output .= "----------\n";
                $Output .= "$ItemArticle{Situation}\n";
            }
            if ( $ItemArticle{Description} ) {
                $Output .= "\nImplementation:\n";
                $Output .= "---------------\n";
                $Output .= "$ItemArticle{Description}\n";
            }
            if ( $ItemArticle{Comment} ) {
                $Output .= "\nInternal:\n";
                $Output .= "---------\n";
                $Output .= "$ItemArticle{Comment}\n";
            }
            $Output .= "\n";
            $Output .= "Services:\n";
            $Output .= "---------\n";
            $Output .= "Die Erweiterung enthält:
    o d\\\\ie implementierte Funktionalität
    o d\\\\ie Funktions- und Integrationstests
    o d\\\\ie Dokumentation (im PDF-Format)
    o d\\\\ie Bereitstellung eines Abnahme Systems (Virtuelles System)
    o d\\\\ie Remote Installationsbegleitung
    o d\\\\ie Übergabe/Lieferung in versionierten OPM-Paketen\n";
            $Output =~ s/\\\\//g;
            $Output .= "\n";
            $Output .= "Effort:\n";
            $Output .= "------\n";
            $Output .= " $ItemArticle{PiceReal} PT\n";
            $Output .= "\n";
            $Output .= "\n";
        }

        return $LayoutObject->Attachment(
            ContentType => 'text/plain; charset=' . $LayoutObject->{UserCharset},
            Content     => $Output,
            Type        => 'inline'
        );
    }

    # ---
    # export billing
    # ---
    elsif ( $Self->{Subaction} eq 'ExportBilling' ) {

        my %GetParam;
        $GetParam{ItemID} = $ParamObject->GetParam( Param => 'ItemID' );

        my %Data = $FinanceObject->ItemGet(
            ItemID => $GetParam{ItemID},
            UserID => $Self->{UserID},
        );

        my $Output = '';
        $Output .= "Number:      $Data{Number}\n";
        $Output .= "Title:       $Data{Title}\n";
        $Output .= "TicketSales: $Data{TicketSales}\n";
        $Output .= "TicketDevel: $Data{TicketDevel}\n";
        $Output .= "InfoBilling: $Data{InfoBilling}\n";
        $Output .= "\n";
        $Output .= "\n";

        my @ItemArticleIDs = $FinanceObject->ItemArticleList(
            ItemID => $Data{ItemID},
            UserID => $Self->{UserID},
        );

        my $Total        = 0;
        my $TotalInclTax = 0;
        my $Count        = 0;
        for my $ItemArticleID (@ItemArticleIDs) {

            $Count++;

            # get item article data
            my %ItemArticle = $FinanceObject->ItemArticleGet(
                ItemArticleID => $ItemArticleID,
                UserID        => $Self->{UserID},
            );

            my $LinePart1 = "$Count. $ItemArticle{ArticleTitle}: $ItemArticle{Title}  ";
            my $LinePart2 = "$ItemArticle{Total} EUR (zzgl. Tax $ItemArticle{Tax}%)";

            my $Length2     = length $LinePart2;
            my $SpaceLength = 80 - $Length2;
            my $SpacePart   = '';

            if ( $SpaceLength > 0 ) {
                $SpacePart = ' ' x $SpaceLength;
            }

            my $HorizontalRoler = '-' x 80;

            $Output .= $LinePart1 . "\n";
            $Output .= $SpacePart . $LinePart2 . "\n";
            $Output .= $HorizontalRoler . "\n";
            $Output .= "\n";

            $Total        += $ItemArticle{Total};
            $TotalInclTax += $ItemArticle{TotalInclTax};
        }

        my $Tax      = $TotalInclTax - $Total;
        my $PreSpace = ' ' x 62;

        $Output .= $PreSpace . "Netto:  $Total EUR\n";
        $Output .= $PreSpace . "Tax:     $Tax EUR\n";
        $Output .= $PreSpace . "=================\n";
        $Output .= $PreSpace . "Total:  $TotalInclTax EUR\n";
        $Output .= $PreSpace . "=================\n";

        return $LayoutObject->Attachment(
            ContentType => 'text/plain; charset=' . $LayoutObject->{UserCharset},
            Content     => $Output,
            Type        => 'inline'
        );
    }

    # ---
    # summary
    # ---
    elsif ( $Self->{Subaction} eq 'Summary' ) {

        # get parameter
        my $TargetYear = $ParamObject->GetParam( Param => 'Year' );

        # show main block
        $LayoutObject->Block(
            Name => 'Main',
            Data => {
                Head => 'Summary',
            },
        );

        # build list to save all available years
        my @AvailableYears    = ();
        my $TranslatedString  = $LayoutObject->{LanguageObject}->Get('All years');
        my @ItemCreationDates = $FinanceObject->ItemGetAllCreationDates();

        @AvailableYears = ( $TranslatedString, @ItemCreationDates );

        # build drop-down of available years
        my $YearsSelect = $LayoutObject->BuildSelection(
            Data         => \@AvailableYears,
            Name         => 'YearsSelectList',
            Class        => 'Modernize',
            ID           => 'YearsSelectList',
            PossibleNone => 1,
            Title        => $LayoutObject->{LanguageObject}->Translate('Years select list'),
        );

        $LayoutObject->Block(
            Name => 'SummaryMenu',
            Data => {
                YearsSelect => $YearsSelect,
            },
        );

        # hash to save the range of years to analyze
        my %ItemCreationDates;

        # verify if all available years should be shown
        if ( !$TargetYear || $TargetYear eq 'All' ) {
            %ItemCreationDates = $FinanceObject->ItemGetFirstLastCreationDates();
        }
        else {
            $ItemCreationDates{OldestYear} = $TargetYear;
            $ItemCreationDates{LatestYear} = $TargetYear;
        }

        if (%ItemCreationDates) {

            # show general content
            $LayoutObject->Block(
                Name => 'SummaryContent',
                Data => {},
            );

            # loop from corresponding year(s)
            for my $Year ( $ItemCreationDates{OldestYear} .. $ItemCreationDates{LatestYear} ) {
                my $OpportunityTotal = 0;
                my $OfferTotal       = 0;
                my $OrderTotal       = 0;
                my %ArticleSummary;
                my %Data;
                for my $Month ( 1 .. 12 ) {
                    my @Opportunity = $FinanceObject->ItemSearch(
                        UserID              => $Self->{UserID},
                        CreateTimeNewerDate => "$Year-$Month-01 00:00:00",
                        CreateTimeOlderDate => "$Year-$Month-31 23:59:59",
                    );
                    $Data{Opportunity}->{$Month} = scalar @Opportunity;
                    $OpportunityTotal = $OpportunityTotal + scalar @Opportunity;

                    # get article relation
                    for my $ItemID (@Opportunity) {
                        my @ArticleList = $FinanceObject->ItemArticleList(
                            ItemID => $ItemID,
                            UserID => $Self->{UserID},
                        );
                        for my $ArticleID (@ArticleList) {
                            my %Article = $FinanceObject->ItemArticleGet(
                                ItemArticleID => $ArticleID,
                                UserID        => $Self->{UserID},
                            );
                            if ( !$ArticleSummary{OpportunityTotalSum} ) {
                                $ArticleSummary{OpportunityTotalSum} = $Article{Total};
                            }
                            else {
                                $ArticleSummary{OpportunityTotalSum}
                                    = $ArticleSummary{OpportunityTotalSum} + $Article{Total};
                            }
                            if ( !$ArticleSummary{OpportunityTotal}->{ $Article{ArticleTitle} } ) {
                                $ArticleSummary{OpportunityTotal}->{ $Article{ArticleTitle} } = $Article{Total};
                            }
                            else {
                                $ArticleSummary{OpportunityTotal}->{ $Article{ArticleTitle} }
                                    = $ArticleSummary{OpportunityTotal}->{ $Article{ArticleTitle} }
                                    + $Article{Total};
                            }
                            if ( !$ArticleSummary{Opportunity}->{ $Article{ArticleTitle} } ) {
                                $ArticleSummary{Opportunity}->{ $Article{ArticleTitle} } = 0;
                            }
                            $ArticleSummary{Opportunity}->{ $Article{ArticleTitle} }++;
                            if ( !$ArticleSummary{OpportunityCount} ) {
                                $ArticleSummary{OpportunityCount} = 0;
                            }
                            $ArticleSummary{OpportunityCount}++;
                        }
                    }

                    my @Offer = $FinanceObject->ItemSearch(
                        State => [
                            'Offer', 'Order', 'Delivered', 'Invoice',
                            'Closed', 'Lost Offer', 'Lost Order',
                        ],
                        UserID              => $Self->{UserID},
                        CreateTimeNewerDate => "$Year-$Month-01 00:00:00",
                        CreateTimeOlderDate => "$Year-$Month-31 23:59:59",
                    );
                    $Data{Offer}->{$Month} = scalar @Offer;
                    $OfferTotal = $OfferTotal + scalar @Offer;

                    # get article relation
                    for my $ItemID (@Offer) {
                        my @ArticleList = $FinanceObject->ItemArticleList(
                            ItemID => $ItemID,
                            UserID => $Self->{UserID},
                        );
                        for my $ArticleID (@ArticleList) {
                            my %Article = $FinanceObject->ItemArticleGet(
                                ItemArticleID => $ArticleID,
                                UserID        => $Self->{UserID},
                            );
                            if ( !$ArticleSummary{OfferTotalSum} ) {
                                $ArticleSummary{OfferTotalSum} = $Article{Total};
                            }
                            else {
                                $ArticleSummary{OfferTotalSum} = $ArticleSummary{OfferTotalSum} + $Article{Total};
                            }
                            if ( !$ArticleSummary{OfferTotal}->{ $Article{ArticleTitle} } ) {
                                $ArticleSummary{OfferTotal}->{ $Article{ArticleTitle} } = $Article{Total};
                            }
                            else {
                                $ArticleSummary{OfferTotal}->{ $Article{ArticleTitle} }
                                    = $ArticleSummary{OfferTotal}->{ $Article{ArticleTitle} }
                                    + $Article{Total};
                            }
                            if ( !$ArticleSummary{Offer}->{ $Article{ArticleTitle} } ) {
                                $ArticleSummary{Offer}->{ $Article{ArticleTitle} } = 0;
                            }
                            $ArticleSummary{Offer}->{ $Article{ArticleTitle} }++;
                            if ( !$ArticleSummary{OfferCount} ) {
                                $ArticleSummary{OfferCount} = 0;
                            }
                            $ArticleSummary{OfferCount}++;
                        }
                    }

                    my @Order = $FinanceObject->ItemSearch(
                        State               => [ 'Order', 'Delivered', 'Invoice', 'Closed' ],
                        UserID              => $Self->{UserID},
                        CreateTimeNewerDate => "$Year-$Month-01 00:00:00",
                        CreateTimeOlderDate => "$Year-$Month-31 23:59:59",
                    );
                    $Data{Order}->{$Month} = scalar @Order;
                    $OrderTotal = $OrderTotal + scalar @Order;

                    # get article relation
                    for my $ItemID (@Order) {
                        my @ArticleList = $FinanceObject->ItemArticleList(
                            ItemID => $ItemID,
                            UserID => $Self->{UserID},
                        );
                        for my $ArticleID (@ArticleList) {
                            my %Article = $FinanceObject->ItemArticleGet(
                                ItemArticleID => $ArticleID,
                                UserID        => $Self->{UserID},
                            );
                            if ( !$ArticleSummary{OrderTotalSum} ) {
                                $ArticleSummary{OrderTotalSum} = $Article{Total};
                            }
                            else {
                                $ArticleSummary{OrderTotalSum} = $ArticleSummary{OrderTotalSum} + $Article{Total};
                            }
                            if ( !$ArticleSummary{OrderTotal}->{ $Article{ArticleTitle} } ) {
                                $ArticleSummary{OrderTotal}->{ $Article{ArticleTitle} } = $Article{Total};
                            }
                            else {
                                $ArticleSummary{OrderTotal}->{ $Article{ArticleTitle} }
                                    = $ArticleSummary{OrderTotal}->{ $Article{ArticleTitle} }
                                    + $Article{Total};
                            }
                            if ( !$ArticleSummary{Order}->{ $Article{ArticleTitle} } ) {
                                $ArticleSummary{Order}->{ $Article{ArticleTitle} } = 0;
                            }
                            $ArticleSummary{Order}->{ $Article{ArticleTitle} }++;
                            if ( !$ArticleSummary{OrderCount} ) {
                                $ArticleSummary{OrderCount} = 0;
                            }
                            $ArticleSummary{OrderCount}++;
                        }
                    }
                }
                $LayoutObject->Block(
                    Name => 'Summary',
                    Data => {
                        Year => $Year,
                    },
                );
                $LayoutObject->Block(
                    Name => 'SummaryItem',
                    Data => {
                        Year  => $Year,
                        Type  => 'Opportunity',
                        Total => $OpportunityTotal,
                        %{ $Data{Opportunity} },
                        TotalSum => $ArticleSummary{OpportunityTotalSum},
                    },
                );

                for my $Title ( sort keys %{ $ArticleSummary{Opportunity} } ) {
                    my $Percent = 0;
                    if ( $ArticleSummary{OpportunityCount} ) {
                        $Percent = $ArticleSummary{Opportunity}->{$Title}
                            / ( $ArticleSummary{OpportunityCount} / 100 );
                    }
                    $Percent =~ s/^(.*\...).+?$/$1/;
                    my $PercentTotal = 0;
                    if (
                        $ArticleSummary{OpportunityTotalSum}
                        && ( $ArticleSummary{OpportunityTotalSum} / 100 ) > 0
                        )
                    {
                        $PercentTotal = $ArticleSummary{OpportunityTotal}->{$Title}
                            / ( $ArticleSummary{OpportunityTotalSum} / 100 );
                    }
                    $PercentTotal =~ s/^(.*\...).+?$/$1/;
                    if ( $ArticleSummary{OpportunityTotal}->{$Title} =~ /\.(\d\d|\d)$/ ) {
                        my $Length = 1 - ( length($1) || 0 );
                        while ( $Length == 0 ) {
                            $Length = $Length - 1;
                            $ArticleSummary{OpportunityTotal}->{$Title} .= '0';
                        }
                    }
                    else {
                        $ArticleSummary{OpportunityTotal}->{$Title} .= '.00';
                    }
                    $LayoutObject->Block(
                        Name => 'SummaryItemDetail',
                        Data => {
                            Title        => $Title,
                            Count        => $ArticleSummary{Opportunity}->{$Title},
                            Percent      => $Percent,
                            Total        => $ArticleSummary{OpportunityTotal}->{$Title},
                            PercentTotal => $PercentTotal,
                        },
                    );
                }

                $LayoutObject->Block(
                    Name => 'SummaryItem',
                    Data => {
                        Year  => $Year,
                        Type  => 'Offer',
                        Total => $OfferTotal,
                        %{ $Data{Offer} },
                        TotalSum => $ArticleSummary{OfferTotalSum},
                    },
                );
                for my $Title ( sort keys %{ $ArticleSummary{Offer} } ) {
                    my $Percent = $ArticleSummary{Offer}->{$Title} / ( $ArticleSummary{OfferCount} / 100 );
                    $Percent =~ s/^(.*\...).+?$/$1/;
                    my $PercentTotal = 0;
                    if ( $ArticleSummary{OfferTotalSum} > 0 ) {
                        $PercentTotal = $ArticleSummary{OfferTotal}->{$Title}
                            / ( $ArticleSummary{OfferTotalSum} / 100 );
                    }

                    $PercentTotal =~ s/^(.*\...).+?$/$1/;
                    if ( $ArticleSummary{OfferTotal}->{$Title} =~ /\.(\d\d|\d)$/ ) {
                        my $Length = 1 - ( length($1) || 0 );
                        while ( $Length == 0 ) {
                            $Length = $Length - 1;
                            $ArticleSummary{OfferTotal}->{$Title} .= '0';
                        }
                    }
                    else {
                        $ArticleSummary{OfferTotal}->{$Title} .= '.00';
                    }
                    $LayoutObject->Block(
                        Name => 'SummaryItemDetail',
                        Data => {
                            Title        => $Title,
                            Count        => $ArticleSummary{Offer}->{$Title},
                            Percent      => $Percent,
                            Total        => $ArticleSummary{OfferTotal}->{$Title},
                            PercentTotal => $PercentTotal,
                        },
                    );
                }
                $LayoutObject->Block(
                    Name => 'SummaryItem',
                    Data => {
                        Year  => $Year,
                        Type  => 'Order',
                        Total => $OrderTotal,
                        %{ $Data{Order} },
                        TotalSum => $ArticleSummary{OrderTotalSum},
                    },
                );
                for my $Title ( sort keys %{ $ArticleSummary{Order} } ) {
                    my $Percent = $ArticleSummary{Order}->{$Title} / ( $ArticleSummary{OrderCount} / 100 );
                    $Percent =~ s/^(.*\...).+?$/$1/;
                    my $PercentTotal = $ArticleSummary{OrderTotal}->{$Title}
                        / ( $ArticleSummary{OrderTotalSum} / 100 );
                    $PercentTotal =~ s/^(.*\...).+?$/$1/;
                    if ( $ArticleSummary{OrderTotal}->{$Title} =~ /\.(\d\d|\d)$/ ) {
                        my $Length = 1 - ( length($1) || 0 );
                        while ( $Length == 0 ) {
                            $Length = $Length - 1;
                            $ArticleSummary{OrderTotal}->{$Title} .= '0';
                        }
                    }
                    else {
                        $ArticleSummary{OrderTotal}->{$Title} .= '.00';
                    }
                    $LayoutObject->Block(
                        Name => 'SummaryItemDetail',
                        Data => {
                            Title        => $Title,
                            Count        => $ArticleSummary{Order}->{$Title},
                            Percent      => $Percent,
                            Total        => $ArticleSummary{OrderTotal}->{$Title},
                            PercentTotal => $PercentTotal,
                        },
                    );
                }
            }
        }
        else {
            if ( !$TargetYear || $TargetYear eq 'All' ) {
                $TargetYear = 'All years';
            }

            $LayoutObject->Block(
                Name => 'SummaryNoDataFound',
                Data => {
                    Year => $TargetYear,
                },
            );
        }
        my $Output = $LayoutObject->Header(
            Title => 'Summary',
        );
        $Output .= $LayoutObject->NavigationBar();
        $Output .= $LayoutObject->Output(
            TemplateFile => 'AgentFinance',
            Data         => \%Param
        );
        $Output .= $LayoutObject->Footer();

        return $Output;
    }

    # ---
    # overview
    # ---
    else {

        my %GetParam;
        for my $Parameter (qw(State NextAction)) {
            $GetParam{$Parameter} = $ParamObject->GetParam( Param => $Parameter );
        }

        $LayoutObject->Block(
            Name => 'Main',
            Data => {
                Head  => 'Overview',
                Value => $GetParam{State},
            },
        );

        $LayoutObject->Block(
            Name => 'EntryFilter',
        );

        $LayoutObject->Block(
            Name => 'MainContentOverview',
        );

        for my $State ( @{ $Self->{StateList} } ) {

            my @ListID = $FinanceObject->ItemSearch(
                State  => [$State],
                UserID => $Self->{UserID},
            );

            $LayoutObject->Block(
                Name => 'MainContentOverviewFilter',
                Data => {
                    Name  => $State,
                    Count => scalar @ListID,
                },
            );

            NEXTACTION:
            for my $NextAction ( sort keys %{ $Self->{NextAction} } ) {

                my @ListID = $FinanceObject->ItemSearch(
                    State      => [$State],
                    NextAction => [$NextAction],
                    UserID     => $Self->{UserID},
                );

                next NEXTACTION if !scalar @ListID;

                $LayoutObject->Block(
                    Name => 'MainContentOverviewFilterItem',
                    Data => {
                        Name       => $NextAction,
                        NextAction => $NextAction,
                        State      => $State,
                        Count      => scalar @ListID,
                    },
                );
            }
        }

        my %Params;
        if ( $GetParam{NextAction} ) {
            $Params{NextAction} = [ $GetParam{NextAction} ];
        }
        if ( $GetParam{State} ) {
            $Params{State} = [ $GetParam{State} ];
        }

        if ( !$Params{NextAction} && !$Params{State} ) {

            $Params{State} = [
                'Opportunity',
                'Offer',
                'Order',
                'Software Quality Audit',
                'Delivered',
                'Invoice',
            ];
        }

        my @ListID = $FinanceObject->ItemSearch(
            %Params,
            UserID => $Self->{UserID},
        );

        LISTIDELEMENT:
        for my $ListIDElement (@ListID) {

            my %Data = $FinanceObject->ItemGet(
                ItemID => $ListIDElement,
                UserID => $Self->{UserID},
            );

            $LayoutObject->Block(
                Name => 'MainContentOverviewItem',
                Data => {
                    %Data,
                    Link => "Action=$Self->{Action};Subaction=View;ItemID=$ListIDElement",
                },
            );

            if ( $Data{State} !~ m{ \A Lost .* }xmsi ) {

                # check tickets
                TICKETTYPE:
                for my $TicketType (qw(Sales Devel Billing)) {

                    next TICKETTYPE if !$Data{ 'Ticket' . $TicketType };

                    # extract ticket number
                    my $TicketNumber = $Data{ 'Ticket' . $TicketType };

                    # lookup ticket number
                    my $TicketID = $Self->TicketIDLookup(
                        TicketNumber => $TicketNumber,
                    );

                    if ( !$TicketID ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => "The $TicketType ticket number is invalid!",
                            },
                        );

                        next LISTIDELEMENT;
                    }

                    # get ticket data
                    my %Ticket = $TicketObject->TicketGet(
                        TicketID => $TicketID,
                        UserID   => 1,
                    );

                    if ( $Ticket{StateType} eq 'merged' ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => "$TicketType Ticket merged! Update ticket number.",
                            },
                        );

                        next LISTIDELEMENT;
                    }
                }
            }

            # general checks: Delivery
            if ( $Data{Delivery} && $Data{Delivery} !~ /^(\d\d\d\d)-(\d\d|\d)-(\d\d|\d)/ ) {

                $LayoutObject->Block(
                    Name => 'MainContentOverviewItemIcon',
                    Data => {
                        %Data,
                        LedColor => 'redled',
                        Notice   => 'Invalid Delivery Date (use yyyy-mm-dd)!',
                    },
                );

                next LISTIDELEMENT;
            }

            # general checks: SWQADate
            elsif ( $Data{SWQADate} && $Data{SWQADate} !~ /^(\d\d\d\d)-(\d\d|\d)-(\d\d|\d)/ ) {

                $LayoutObject->Block(
                    Name => 'MainContentOverviewItemIcon',
                    Data => {
                        %Data,
                        LedColor => 'redled',
                        Notice   => 'Invalid SWQA Date (use yyyy-mm-dd)!',
                    },
                );

                next LISTIDELEMENT;
            }

            # Opportunity|Offer
            if ( $Data{State} eq 'Opportunity' || $Data{State} eq 'Offer' ) {

                if ( !$Data{TicketSales} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Need Sales Ticket!',
                        },
                    );

                    next LISTIDELEMENT;
                }
                elsif ( $Data{TicketDevel} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Devel Ticket found! Order?',
                        },
                    );

                    next LISTIDELEMENT;
                }
                else {

                    # lookup ticket number
                    my $TicketID = $Self->TicketIDLookup(
                        TicketNumber => $Data{TicketSales},
                    );

                    my %Ticket;
                    if ($TicketID) {

                        %Ticket = $TicketObject->TicketGet(
                            TicketID => $TicketID,
                            UserID   => 1,
                        );
                    }

                    if ( %Ticket && $Ticket{StateType} eq 'closed' ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => 'Sales Ticket closed! Lost Order?',
                            },
                        );

                        next LISTIDELEMENT;
                    }

                    if ( !$Data{Volume} ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'yellowled',
                                Notice   => 'Feedback from Development!',
                            },
                        );

                        next LISTIDELEMENT;
                    }
                }
            }

            # Order
            if ( $Data{State} eq 'Order' ) {

                if ( !$Data{Delivery} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Need Delivery Date!',
                        },
                    );

                    next LISTIDELEMENT;
                }
                if ( !$Data{SWQADate} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Need SWQA Date!',
                        },
                    );

                    next LISTIDELEMENT;
                }
                elsif ( !$Data{TicketDevel} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Need Devel Ticket!',
                        },
                    );

                    next LISTIDELEMENT;
                }
                else {

                    my $Now = $TimeObject->SystemTime();

                    my $DeliveryTime = $TimeObject->TimeStamp2SystemTime(
                        String => $Data{Delivery} . ' 08:00:00',
                    );
                    my $DeliveryWorkingTime = $TimeObject->WorkingTime(
                        StartTime => $Now,
                        StopTime  => $DeliveryTime,
                    );

                    my $SWQATime = $TimeObject->TimeStamp2SystemTime(
                        String => $Data{SWQADate} . ' 08:00:00',
                    );
                    my $SWQAWorkingTime = $TimeObject->WorkingTime(
                        StartTime => $Now,
                        StopTime  => $SWQATime,
                    );

                    # lookup ticket number
                    my $TicketID = $Self->TicketIDLookup(
                        TicketNumber => $Data{TicketDevel},
                    );

                    my %Ticket;
                    if ($TicketID) {

                        %Ticket = $TicketObject->TicketGet(
                            TicketID => $TicketID,
                            UserID   => 1,
                        );
                    }

                    if ( %Ticket && $Ticket{StateType} eq 'closed' ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => 'Devel Ticket closed! Lost Order?',
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    elsif ( $Now > $SWQATime ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => "SWQA date exceeded on $Data{SWQADate}!",
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    elsif ( $Now > $DeliveryTime || $DeliveryWorkingTime < ( 60 * 60 * 10 * 1 ) ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => "Need to be delivered on $Data{Delivery}!",
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    elsif ( $SWQAWorkingTime < ( 60 * 60 * 10 * 1 ) ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'yellowled',
                                Notice   => "SWQA date exceeded on $Data{SWQADate}!",
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    elsif ( $DeliveryWorkingTime < ( 60 * 60 * 10 * 2 ) ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'yellowled',
                                Notice   => "Need to be delivered on $Data{Delivery}!",
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    else {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'greenled',
                                Notice   => 'Ok!',
                            },
                        );
                    }
                }
            }

            # SWQA
            if ( $Data{State} eq 'Software Quality Audit' ) {

                if ( !$Data{SWQADate} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Need SWQA Date!',
                        },
                    );

                    next LISTIDELEMENT;
                }
                elsif ( !$Data{TicketDevel} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Need Devel Ticket!',
                        },
                    );

                    next LISTIDELEMENT;
                }
                else {

                    my $Now = $TimeObject->SystemTime();

                    my $DeliveryTime = $TimeObject->TimeStamp2SystemTime(
                        String => $Data{Delivery} . ' 08:00:00',
                    );
                    my $DeliveryWorkingTime = $TimeObject->WorkingTime(
                        StartTime => $Now,
                        StopTime  => $DeliveryTime,
                    );

                    my $SWQATime = $TimeObject->TimeStamp2SystemTime(
                        String => $Data{SWQADate} . ' 08:00:00',
                    );
                    my $SWQAWorkingTime = $TimeObject->WorkingTime(
                        StartTime => $Now,
                        StopTime  => $SWQATime,
                    );

                    # lookup ticket number
                    my $TicketID = $Self->TicketIDLookup(
                        TicketNumber => $Data{TicketDevel},
                    );

                    my %Ticket;
                    if ($TicketID) {

                        %Ticket = $TicketObject->TicketGet(
                            TicketID => $TicketID,
                            UserID   => 1,
                        );
                    }

                    if ( %Ticket && $Ticket{StateType} eq 'closed' ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => 'Devel Ticket closed! Lost Order?',
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    elsif ( $Now > $DeliveryTime || $DeliveryWorkingTime < ( 60 * 60 * 10 * 1 ) ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => "Need to be delivered on $Data{Delivery}!",
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    elsif ( $DeliveryWorkingTime < ( 60 * 60 * 10 * 2 ) ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'yellowled',
                                Notice   => "Need to be delivered on $Data{Delivery}!",
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    else {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'greenled',
                                Notice   => 'Ok!',
                            },
                        );
                    }
                }
            }

            # Delivered
            if ( $Data{State} eq 'Delivered' ) {

                if ( !$Data{Delivery} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Need Delivery Date!',
                        },
                    );
                }
                elsif ( !$Data{SWQADate} ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'redled',
                            Notice   => 'Need SWQA Date!',
                        },
                    );
                }
                elsif ( $Data{NextAction} && lc $Data{NextAction} ne 'customer' ) {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'yellowled',
                            Notice   => 'Remediation? Project not finished!',
                        },
                    );
                }
                else {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'greenled',
                            Notice   => 'Ok!',
                        },
                    );
                }
            }

            # Invoice|Closed
            if ( $Data{State} =~ /^(Invoice|Closed)/ && $Data{TicketBilling} ) {

                # lookup ticket number
                my $TicketID = $Self->TicketIDLookup(
                    TicketNumber => $Data{TicketBilling},
                );

                my %Ticket;
                if ($TicketID) {

                    %Ticket = $TicketObject->TicketGet(
                        TicketID => $TicketID,
                        UserID   => 1,
                    );
                }

                if ( %Ticket && $Ticket{StateType} ne 'closed' ) {

                    my $SystemTime = $TimeObject->TimeStamp2SystemTime(
                        String => $Ticket{Created}
                    );

                    my $Now         = $TimeObject->SystemTime();
                    my $WorkingTime = $Now - $SystemTime;

                    if ( $WorkingTime < ( 60 * 60 * 24 * 60 ) ) {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'yellowled',
                                Notice   => 'Billing Ticket not closed! Invoice open.',
                            },
                        );

                        next LISTIDELEMENT;
                    }
                    else {

                        $LayoutObject->Block(
                            Name => 'MainContentOverviewItemIcon',
                            Data => {
                                %Data,
                                LedColor => 'redled',
                                Notice   => 'Billing Ticket open since 60 days!',
                            },
                        );

                        next LISTIDELEMENT;
                    }
                }
                else {

                    $LayoutObject->Block(
                        Name => 'MainContentOverviewItemIcon',
                        Data => {
                            %Data,
                            LedColor => 'greenled',
                            Notice   => 'Billing Ticket closed! Seems to be ok!',
                        },
                    );

                    next LISTIDELEMENT;
                }
            }
        }

        # show a no data found message, if needed
        if ( !@ListID ) {
            $LayoutObject->Block(
                Name => 'MainContentOverviewNoData',
            );
        }

        # calculate value
        my $Value = '';
        if ( $GetParam{State} && $GetParam{NextAction} ) {
            $Value = $GetParam{NextAction} . ' - ' . $GetParam{State};
        }
        elsif ( $GetParam{State} ) {
            $Value = $GetParam{State};
        }
        elsif ( $GetParam{NextAction} ) {
            $Value = $GetParam{NextAction};
        }

        my $Output = $LayoutObject->Header(
            Title => 'Overview',
            Value => $Value,
        );

        $Output .= $LayoutObject->NavigationBar();
        $Output .= $LayoutObject->Output(
            TemplateFile => 'AgentFinance',
            Data         => \%Param
        );
        $Output .= $LayoutObject->Footer();

        return $Output;
    }
}

sub TicketIDLookup {
    my ( $Self, %Param ) = @_;

    return if !$Param{TicketNumber};

    # get cache object
    my $CacheObject = $Kernel::OM->Get('Kernel::System::Cache');

    # check cache
    my $CacheKey = 'TicketIDLookup-' . $Param{TicketNumber};
    my $Cache    = $CacheObject->Get(
        Type => $Self->{CacheType},
        Key  => $CacheKey,
    );
    return $Cache if $Cache;

    # lookup ticket id
    my $TicketID = $Kernel::OM->Get('Kernel::System::Ticket')->TicketIDLookup(
        TicketNumber => $Param{TicketNumber},
    );

    return if !$TicketID;

    # set cache
    $CacheObject->Set(
        Type  => $Self->{CacheType},
        TTL   => $Self->{CacheTTL},
        Key   => $CacheKey,
        Value => $TicketID,
    );

    return $TicketID;
}

1;

// --
// Copyright (C) 2001-2016 OTRS AG, http://otrs.com/\n";
// --
// This software comes with ABSOLUTELY NO WARRANTY. For details, see
// the enclosed file COPYING for license information (AGPL). If you
// did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
// --

"use strict";

var Finance = Finance || {};
Finance.Agent = Finance.Agent || {};

/**
 * @namespace
 * @exports TargetNS as Finance.Agent.Default
 * @description
 *      This namespace contains the special module functions for the edit screen.
 */
Finance.Agent.Default = (function (TargetNS) {

    function RecalculateTotal() {
        var Total = 0,
            TotalWithTax = 0;

        // go through all elements with class="Total" to add them
        $('.Total').each(function () {
            var Tax = 0,
                Value = parseFloat($(this).text());

            if (!isNaN(Value)) {
                Total += Value;

                // get tax rate
                Tax = $(this).closest('div').find('.Tax').val() || 0;

                // calculate total with tax
                TotalWithTax += (Value / 100) * (100 + parseInt(Tax, 10));
            }
        });

        $('.GrandTotal').text(Total.toFixed(0));
        $('.GrandTotalWithTax').text(TotalWithTax.toFixed(0));
    }

    function CalculatePartialTotal(ElementChanged) {
        var PartialTotal = 0,
            EffortCustomer, PricePerDay, Discount;

        // get needed values from form
        EffortCustomer = $(ElementChanged).closest('div').find('.EffortCustomer').val() || 0;
        PricePerDay = $(ElementChanged).closest('div').find('.PricePerDay').val() || 0;
        Discount = $(ElementChanged).closest('div').find('.Discount').val() || 0;

        // calculate and write partial total without taxes
        PartialTotal = ((EffortCustomer * PricePerDay) / 100) * (100 - Discount);
        $(ElementChanged).closest('div').find('.Total').text(PartialTotal.toFixed(2));
    }

    function InitPartialTotalCalculation() {
        // init calculation of partial total, after price, discount or number of days were provided
        $('.EffortCustomer, .PricePerDay, .Discount, .Tax').unbind('change.PartialTotalCalculation').bind('change.PartialTotalCalculation', function () {
           var FieldValue = $(this).val();

           // replace , with .
           FieldValue = FieldValue.replace(/,/g, ".");

            // convert value to number
           FieldValue = Number(FieldValue);

           // leave only 2 decimals
           $(this).val((FieldValue).toFixed(2));

           //calculate partial total
           CalculatePartialTotal(this);

           // now re-calculate the grand total
           RecalculateTotal();
        });
    }

    /**
     * @function
     * @return {void}
     *      This function initializes all needed JS for the Edit screen
     */
    TargetNS.Init = function () {

        // initiate partial total calculation
        InitPartialTotalCalculation();
    };

    return TargetNS;
}(Finance.Agent.Default || {}));

// --
// Copyright (C) 2001-2016 OTRS AG, http://otrs.com/
// --
// This software comes with ABSOLUTELY NO WARRANTY. For details, see
// the enclosed file COPYING for license information (AGPL). If you
// did not receive this file, see http://www.gnu.org/licenses/agpl.txt.
// --

"use strict";

var Core = Core || {};
Core.Agent = Core.Agent || {};

/**
 * @namespace
 * @exports TargetNS as Core.Agent.CustomerSearch
 * @description
 *      This namespace contains the special module functions for the customer search.
 */
Core.Agent.CustomerCompanySearch = (function (TargetNS) {

    /**
     * @function
     * @param {jQueryObject} $Element The jQuery object of the input field with autocomplete
     * @return {void}
     *      This function initializes the special module functions
     */
    TargetNS.Init = function ($Element) {

        if (!isJQueryObject($Element)) {
            return;
        }

        Core.UI.Autocomplete.Init($Element, function (Request, Response) {
            var URL = Core.Config.Get('Baselink'),
                Data = {
                    Action: 'AgentCustomerCompanySearch',
                    Term: Request.term,
                    MaxResults: Core.UI.Autocomplete.GetConfig('MaxResultsDisplayed')
                };
            $Element.data('AutoCompleteXHR', Core.AJAX.FunctionCall(URL, Data, function (Result) {
                var DataXHR = [];
                $.each(Result, function () {
                    DataXHR.push({
                        label: this.CustomerValue,
                        value: this.CustomerKey
                    });
                });
                Response(DataXHR);
            }));
        }, function (Event, UI) {
            $Element.val(UI.item.value);
            Event.preventDefault();
            return false;
        }, 'CustomerCompanySearch');

    };

    return TargetNS;
}(Core.Agent.CustomerCompanySearch || {}));
